// Production build (and dev server with --watch) powered by esbuild.
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import http from 'node:http';
import net from 'node:net';
import crypto from 'node:crypto';

const watch = process.argv.includes('--watch');
const dist = process.env.DIST_DIR || path.join('..', 'backend', 'internal', 'web', 'dist'); // собранный фронтенд встраивается в Go-бинарник

// pdf.js (просмотр PDF): воркер — отдельный файл с хэшем в имени (тот же origin), cmaps/шрифты/wasm — dist/pdfjs/ (грузятся по требованию)
const pdfRoot = 'node_modules/pdfjs-dist';
const pdfWorkerFile = path.join(pdfRoot, 'build/pdf.worker.min.mjs');
const pdfWorkerName = fs.existsSync(pdfWorkerFile) ? `pdf.worker-${crypto.createHash('sha1').update(fs.readFileSync(pdfWorkerFile)).update(fs.readFileSync('src/lib/polyfill-map.ts')).digest('hex').slice(0, 8)}.js` : '';
function emitPdfjs() {
  if (!pdfWorkerName) return;
  // воркеру нужен тот же полифил Map.getOrInsertComputed (см. src/lib/polyfill-map.ts)
  const poly = fs.readFileSync('src/lib/polyfill-map.ts', 'utf8').match(/MAP_POLYFILL = `([^`]*)`/)[1].replace(/\\n/g, '\n');
  fs.writeFileSync(path.join(dist, 'assets', pdfWorkerName), poly + fs.readFileSync(pdfWorkerFile, 'utf8'));
  for (const d of ['cmaps', 'standard_fonts', 'wasm', 'iccs']) fs.cpSync(path.join(pdfRoot, d), path.join(dist, 'pdfjs', d), { recursive: true });
}

const options = {
  entryPoints: ['src/main.tsx'],
  bundle: true,
  splitting: true,
  format: 'esm',
  outdir: path.join(dist, 'assets'),
  entryNames: '[name]-[hash]',
  chunkNames: 'chunks/[name]-[hash]',
  assetNames: '[name]-[hash]',
  minify: !watch,
  sourcemap: watch,
  target: 'es2022',
  jsx: 'automatic',
  loader: { '.woff2': 'file' },
  metafile: true,
  legalComments: 'none',
  logLevel: 'info',
  define: { 'process.env.NODE_ENV': watch ? '"development"' : '"production"', __PDF_WORKER__: JSON.stringify('/assets/' + pdfWorkerName) },
};

function emitHtml(meta) {
  let js = '', css = '';
  const preload = [];
  for (const [file, info] of Object.entries(meta.outputs)) {
    const url = '/' + path.relative(dist, file).split(path.sep).join('/');
    if (info.entryPoint === 'src/main.tsx') js = url;
    if (file.endsWith('.css') && path.basename(file).startsWith('main-')) css = url;
  }
  // chunks statically imported by the entry are preloaded; lazy ones are fetched on navigation
  const entry = Object.entries(meta.outputs).find(([, i]) => i.entryPoint === 'src/main.tsx');
  for (const imp of entry[1].imports) {
    if (imp.kind === 'import-statement') preload.push('/' + path.relative(dist, imp.path).split(path.sep).join('/'));
  }
  const tags = [
    css && `<link rel="stylesheet" href="${css}">`,
    ...preload.map((p) => `<link rel="modulepreload" href="${p}">`),
    `<script type="module" src="${js}"></script>`,
  ].filter(Boolean).join('\n');
  fs.writeFileSync(path.join(dist, 'index.html'), fs.readFileSync('index.html', 'utf8').replace('<!--ASSETS-->', tags));
}

function copyPublic() {
  if (!fs.existsSync('public')) return;
  fs.cpSync('public', dist, { recursive: true }); // файлы и подкаталоги (public/fonts — шрифты для PDF)
  emitSw();
}

// Service Worker: подставляем версию сборки и список файлов для предкэширования (главный бандл, css, предзагружаемые чанки, woff2)
function emitSw() {
  const f = path.join(dist, 'sw.js');
  const idx = path.join(dist, 'index.html');
  if (!fs.existsSync(f) || !fs.existsSync(idx)) return;
  const html = fs.readFileSync(idx, 'utf8');
  const list = [...html.matchAll(/(?:href|src)="(\/assets\/[^"]+)"/g)].map((m) => m[1]);
  const assetsDir = path.join(dist, 'assets');
  for (const n of fs.readdirSync(assetsDir)) if (n.endsWith('.woff2')) list.push('/assets/' + n);
  const build = crypto.createHash('sha1').update(html).update(list.join()).digest('hex').slice(0, 10);
  fs.writeFileSync(f, fs.readFileSync(f, 'utf8').replace("'__BUILD__'", JSON.stringify(build)).replace('__PRECACHE__;', JSON.stringify([...new Set(list)]) + ';'));
}

function precompress() {
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]));
  let n = 0, raw = 0, gz = 0, br = 0;
  for (const f of walk(dist)) {
    if (!/\.(js|css|html|svg|json|txt|map|wasm|bcmap|ttf|pfb|icc)$/.test(f)) continue;
    const src = fs.readFileSync(f);
    if (src.length < 512) continue; // совсем мелкие не сжимаем: выигрыша нет
    const g = zlib.gzipSync(src, { level: 9 });
    // brotli q11 — для приложения (его качает каждый); тяжёлые справочники pdf.js — q9, чтобы сборка не тянулась минутами
    const q = f.includes(path.sep + 'pdfjs' + path.sep) ? 9 : 11;
    const b = zlib.brotliCompressSync(src, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: q, [zlib.constants.BROTLI_PARAM_SIZE_HINT]: src.length } });
    fs.writeFileSync(f + '.gz', g);
    fs.writeFileSync(f + '.br', b);
    n++; raw += src.length; gz += g.length; br += b.length;
  }
  console.log(`precompressed ${n} files: ${(raw / 1024).toFixed(0)} KB → gzip ${(gz / 1024).toFixed(0)} KB, brotli ${(br / 1024).toFixed(0)} KB (Go-сервер отдаёт .br/.gz предсжатыми)`);
}

fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(path.join(dist, 'assets'), { recursive: true });
emitPdfjs();

if (!watch) {
  const res = await esbuild.build(options);
  emitHtml(res.metafile);
  copyPublic();
  precompress();
  const sizes = Object.entries(res.metafile.outputs).filter(([f]) => /\.(js|css)$/.test(f)).map(([f, i]) => [f.replace(dist + '/', ''), i.bytes]);
  sizes.sort((a, b) => b[1] - a[1]);
  console.log(sizes.slice(0, 12).map(([f, b]) => `${(b / 1024).toFixed(1).padStart(7)} KB  ${f}`).join('\n'));
} else {
  // ---- dev: rebuild on change + serve dist + proxy API to the Go backend
  const backend = new URL(process.env.BACKEND_URL || 'http://127.0.0.1:8080');
  const port = Number(process.env.PORT || 5173);
  const ctx = await esbuild.context({
    ...options,
    plugins: [{ name: 'html', setup(b) { b.onEnd((r) => { if (r.metafile) { emitHtml(r.metafile); copyPublic(); } }); } }],
  });
  await ctx.watch();
  const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.map': 'application/json' };
  const proxied = (u) => /^\/(api|media|files|healthz)(\/|$|\?)/.test(u);
  const server = http.createServer((req, res) => {
    if (proxied(req.url)) {
      const p = http.request({ host: backend.hostname, port: backend.port, path: req.url, method: req.method, headers: req.headers }, (r) => {
        res.writeHead(r.statusCode, r.headers);
        r.pipe(res);
      });
      p.on('error', () => { res.writeHead(502); res.end('backend unavailable'); });
      return req.pipe(p);
    }
    let f = path.join(dist, decodeURIComponent(req.url.split('?')[0]));
    if (!f.startsWith(dist) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) f = path.join(dist, 'index.html');
    res.writeHead(200, { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    fs.createReadStream(f).pipe(res);
  });
  server.on('upgrade', (req, socket, head) => {
    const t = net.connect(backend.port, backend.hostname, () => {
      t.write(`${req.method} ${req.url} HTTP/1.1\r\n` + Object.entries(req.headers).map(([k, v]) => `${k}: ${v}`).join('\r\n') + '\r\n\r\n');
      t.write(head);
      socket.pipe(t);
      t.pipe(socket);
    });
    t.on('error', () => socket.destroy());
    socket.on('error', () => t.destroy());
  });
  server.listen(port, () => console.log(`dev server: http://localhost:${port}  (backend: ${backend.origin})`));
}
