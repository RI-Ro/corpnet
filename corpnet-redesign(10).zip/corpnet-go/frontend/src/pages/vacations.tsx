import React, { useMemo, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { Link, useTitle } from '../lib/router';
import { toast } from '../lib/store';
import { usePersist } from '../lib/persist';
import { cx, plural, useDebounced } from '../lib/util';
import { Avatar, Badge, Btn, Check, Empty, ErrorBox, Field, Input, Loading, Modal, Textarea, UserPicker, useConfirm } from '../ui';
import type { UserLite } from '../ui';
import { DeptSelect, useDepartments } from '../ui/DeptSelect';
import './vacations.css';

interface Cal { id: number; name: string; description: string; color: string; is_default: boolean; visibility: 'company' | 'restricted'; owner_id: number | null; owner: string | null; level: number }
interface Vac {
  id: number; calendar_id: number; user_id: number; name: string; job_title: string; avatar: string; department: string | null;
  starts_on: string; ends_on: string; deputy_id: number | null; deputy: string | null; deputy_title: string | null;
  city: string; note: string; active_now: boolean;
}

// ---------------------------------------------------------------- dates (всё в UTC, чтобы часовой пояс не сдвигал день)
const DAY = 86400000;
const parse = (s: string) => Date.parse(s.slice(0, 10) + 'T00:00:00Z');
const iso = (t: number) => new Date(t).toISOString().slice(0, 10);
const dmy = (s: string) => s.slice(8, 10) + '.' + s.slice(5, 7) + '.' + s.slice(0, 4);
const dm = (s: string) => s.slice(8, 10) + '.' + s.slice(5, 7);
const daysOf = (v: Vac) => Math.round((parse(v.ends_on) - parse(v.starts_on)) / DAY) + 1;
const todayIso = () => new Date().toISOString().slice(0, 10);
const monthRange = (ym: string) => {
  const [y, m] = ym.split('-').map(Number);
  return { from: iso(Date.UTC(y, m - 1, 1)), to: iso(Date.UTC(y, m, 0)) };
};
const MONTHS = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
const monthLabel = (ym: string) => { const [y, m] = ym.split('-').map(Number); return MONTHS[m - 1] + ' ' + y; };
const shiftMonth = (ym: string, d: number) => { const [y, m] = ym.split('-').map(Number); const t = new Date(Date.UTC(y, m - 1 + d, 1)); return t.toISOString().slice(0, 7); };

type Mode = 'month' | 'year' | 'range';

// ---------------------------------------------------------------- Gantt
function Gantt({ items, from, to, colors }: { items: Vac[]; from: string; to: string; colors: Map<number, string> }) {
  const t0 = parse(from), t1 = parse(to);
  const span = Math.round((t1 - t0) / DAY) + 1;
  const pct = (t: number) => ((t - t0) / DAY / span) * 100;
  const today = Date.parse(todayIso() + 'T00:00:00Z');
  // подписи шкалы: дни (если период ≤ 40 дней) или начала месяцев
  const ticks: { left: number; label: string; major?: boolean }[] = [];
  if (span <= 40) {
    for (let t = t0; t <= t1; t += DAY) { const d = new Date(t); ticks.push({ left: pct(t), label: String(d.getUTCDate()), major: d.getUTCDay() === 1 }); }
  } else {
    for (let t = t0; t <= t1; t += DAY) { const d = new Date(t); if (d.getUTCDate() === 1 || t === t0) ticks.push({ left: pct(t), label: MONTHS[d.getUTCMonth()].slice(0, 3), major: true }); }
  }
  const todayLeft = today >= t0 && today <= t1 ? pct(today) + 100 / span / 2 : null;
  // одна строка на сотрудника
  const rows = useMemo(() => {
    const m = new Map<number, { u: Vac; list: Vac[] }>();
    for (const v of items) { if (!m.has(v.user_id)) m.set(v.user_id, { u: v, list: [] }); m.get(v.user_id)!.list.push(v); }
    return [...m.values()];
  }, [items]);
  return (
    <div className="gantt" role="img" aria-label="Диаграмма отпусков">
      <div className="gRow gHead">
        <div className="gName" />
        <div className="gTrack">{ticks.map((t, i) => <span key={i} className={cx('gTick', t.major && 'maj')} style={{ left: t.left + '%' }}>{t.label}</span>)}</div>
      </div>
      {rows.map(({ u, list }) => (
        <div className="gRow" key={u.user_id}>
          <div className="gName"><Link to={`/people/${u.user_id}`} className="clip">{u.name}</Link></div>
          <div className="gTrack">
            {todayLeft != null && <span className="gToday" style={{ left: todayLeft + '%' }} />}
            {list.map((v) => {
              const a = Math.max(parse(v.starts_on), t0), b = Math.min(parse(v.ends_on), t1);
              return <span key={v.id} className={cx('gBar', v.active_now && 'now')} style={{ ['--c' as any]: colors.get(v.calendar_id), left: pct(a) + '%', width: ((b - a) / DAY + 1) / span * 100 + '%' }}
                title={`${dmy(v.starts_on)} — ${dmy(v.ends_on)}${v.deputy ? '\nЗамещает: ' + v.deputy : ''}${v.city ? '\n' + v.city : ''}`} />;
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------- form
function VacModal({ v, cals, initialCal, onClose, onSaved }: { v: Vac | null; cals: Cal[]; initialCal: number; onClose: () => void; onSaved: () => void }) {
  const [calId, setCalId] = useState(v?.calendar_id ?? initialCal);
  const cal = cals.find((c) => c.id === calId);
  const [user, setUser] = useState<UserLite[]>(v ? [{ id: v.user_id, name: v.name, job_title: v.job_title, avatar: v.avatar }] : []);
  const [deputy, setDeputy] = useState<UserLite[]>(v?.deputy_id ? [{ id: v.deputy_id, name: v.deputy || '', job_title: v.deputy_title || '' }] : []);
  const [f, setF] = useState({ starts_on: v?.starts_on || '', ends_on: v?.ends_on || '', city: v?.city || '', note: v?.note || '' });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const bad = !calId || !user.length || !f.starts_on || !f.ends_on || f.ends_on < f.starts_on;
  async function submit() {
    setBusy(true); setErr('');
    const body = { calendar_id: calId, user_id: user[0].id, starts_on: f.starts_on, ends_on: f.ends_on, deputy_id: deputy[0]?.id ?? null, city: f.city.trim(), note: f.note.trim() };
    try {
      if (v) await api.put('/api/vacations/' + v.id, body); else await api.post('/api/vacations', body);
      toast({ title: v ? 'Отпуск обновлён' : 'Отпуск добавлен', kind: 'success' }, 2000);
      onSaved(); onClose();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title={v ? 'Изменить отпуск' : 'Добавить отпуск'} size="lg" onClose={onClose}
      footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={bad} onClick={submit}><I.Check size={16} /> Сохранить</Btn></>}>
      {cals.length > 1 && (
        <Field label="Календарь"><select className="sel" value={calId} onChange={(e) => setCalId(+e.target.value)}>{cals.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Field>
      )}
      <div className="field"><label>{cal?.is_default ? 'Сотрудник (руководитель)' : 'Сотрудник'}</label><UserPicker single value={user} onChange={setUser} placeholder={cal?.is_default ? 'Найти руководителя…' : 'Найти сотрудника…'} /></div>
      <div className="formGrid">
        <Field label="Начало отпуска"><Input type="date" value={f.starts_on} onChange={(e) => setF({ ...f, starts_on: e.target.value, ends_on: f.ends_on && f.ends_on >= e.target.value ? f.ends_on : e.target.value })} /></Field>
        <Field label="Окончание" hint={f.starts_on && f.ends_on && f.ends_on >= f.starts_on ? plural(Math.round((parse(f.ends_on) - parse(f.starts_on)) / DAY) + 1, ['день', 'дня', 'дней']) : undefined}><Input type="date" min={f.starts_on} value={f.ends_on} onChange={(e) => setF({ ...f, ends_on: e.target.value })} /></Field>
      </div>
      <div className="field"><label>Кто замещает</label><UserPicker single value={deputy} onChange={setDeputy} exclude={user.map((u) => u.id)} placeholder="Найти заместителя…" /></div>
      <Field label="Город / где будет"><Input maxLength={100} value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })} placeholder="Например: Сочи" /></Field>
      <Field label="Комментарий"><Textarea rows={3} maxLength={500} value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} /></Field>
      {err && <div className="err">{err}</div>}
    </Modal>
  );
}


// ---------------------------------------------------------------- calendars
const PALETTE = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#64748b'];

function CalModal({ cal, onClose, onSaved }: { cal: Cal | null; onClose: () => void; onSaved: (id: number) => void }) {
  const [f, setF] = useState({ name: cal?.name || '', description: cal?.description || '', color: cal?.color || PALETTE[0], visibility: cal?.visibility || 'restricted' });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function submit() {
    setBusy(true); setErr('');
    try {
      const r = cal ? await api.put<{ id: number }>('/api/vacation-calendars/' + cal.id, f) : await api.post<{ id: number }>('/api/vacation-calendars', f);
      toast({ title: cal ? 'Календарь обновлён' : 'Календарь создан', kind: 'success' }, 2000);
      onSaved(r.id); onClose();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <Modal title={cal ? 'Настройки календаря' : 'Новый календарь отпусков'} onClose={onClose}
      footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={!f.name.trim()} onClick={submit}><I.Check size={16} /> {cal ? 'Сохранить' : 'Создать'}</Btn></>}>
      <Field label="Название"><Input autoFocus maxLength={100} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="Например: Отдел продаж" /></Field>
      <Field label="Описание"><Textarea rows={2} maxLength={500} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
      <div className="field"><label>Цвет</label>
        <div className="vPalette" role="radiogroup" aria-label="Цвет календаря">
          {PALETTE.map((c) => <button key={c} type="button" role="radio" aria-checked={f.color === c} aria-label={c} className={cx('vSw', f.color === c && 'on')} style={{ ['--c' as any]: c }} onClick={() => setF({ ...f, color: c })} />)}
        </div>
      </div>
      {!cal?.is_default && <div className="small muted">Кому виден календарь, настраивается в разделе «Доступ» после создания.</div>}
      {err && <div className="err">{err}</div>}
    </Modal>
  );
}

interface AclRow { subject_type: 'user' | 'group' | 'department'; subject_id: number; level: 1 | 2; name: string }

function AccessModal({ cal, onClose, onSaved }: { cal: Cal; onClose: () => void; onSaved: () => void }) {
  const { data, error } = useQuery<{ visibility: 'company' | 'restricted'; is_default: boolean; entries: AclRow[] }>('vacacl:' + cal.id, () => api.get(`/api/vacation-calendars/${cal.id}/access`), { stale: 0 });
  const groups = useQuery<any[]>('wiki:groups', () => api.get('/api/groups'), { stale: 60000 });
  const depts = useDepartments();
  const [vis, setVis] = useState<'company' | 'restricted' | null>(null);
  const [rows, setRows] = useState<AclRow[] | null>(null);
  const [lvl, setLvl] = useState<1 | 2>(1);
  const [tab, setTab] = useState<'user' | 'group' | 'department'>('user');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const cur = rows ?? data?.entries ?? [];
  const visibility = vis ?? data?.visibility ?? 'restricted';
  const locked = !!data?.is_default;
  const has = (t: string, id: number) => cur.some((r) => r.subject_type === t && r.subject_id === id);
  const add = (r: Omit<AclRow, 'level'>) => { if (!has(r.subject_type, r.subject_id)) setRows([...cur, { ...r, level: lvl }]); };
  async function save() {
    setBusy(true); setErr('');
    try {
      await api.put(`/api/vacation-calendars/${cal.id}/access`, { visibility, entries: cur.map((r) => ({ subject_type: r.subject_type, subject_id: r.subject_id, level: r.level })) });
      toast({ title: 'Доступ обновлён', kind: 'success' }, 2000);
      invalidate('vacacl'); onSaved(); onClose();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  const ICON = { user: I.UserCheck, group: I.Users, department: I.Building } as const;
  return (
    <Modal title={<>Доступ: {cal.name}</>} size="lg" onClose={onClose}
      footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} disabled={!data} onClick={save}><I.Check size={16} /> Сохранить</Btn></>}>
      {error && !data ? <div className="err">{errMsg(error)}</div> : !data ? <Loading /> : (
        <>
          <div className="vVis" role="radiogroup" aria-label="Кому виден календарь">
            <button type="button" role="radio" aria-checked={visibility === 'company'} className={cx(visibility === 'company' && 'on')} disabled={locked} onClick={() => setVis('company')}>
              <I.Building size={18} /><span><b>Вся компания</b><span className="small muted">Все сотрудники видят записи</span></span>
            </button>
            <button type="button" role="radio" aria-checked={visibility === 'restricted'} className={cx(visibility === 'restricted' && 'on')} disabled={locked} onClick={() => setVis('restricted')}>
              <I.Users size={18} /><span><b>Выбранные</b><span className="small muted">Только перечисленные ниже</span></span>
            </button>
          </div>
          {locked && <div className="small muted">Общий график руководящего состава виден всем сотрудникам. Здесь можно выдать право ведения записей.</div>}
          <div className="vAclAdd">
            <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
              <div className="viewSw" role="tablist" aria-label="Кого добавить">
                {([['user', 'Сотрудник'], ['group', 'Группа'], ['department', 'Подразделение']] as const).map(([k, l]) => (
                  <button key={k} type="button" role="tab" aria-selected={tab === k} className={cx(tab === k && 'on')} onClick={() => setTab(k)} style={{ width: 'auto', padding: '0 12px' }}>{l}</button>
                ))}
              </div>
              <span className="sp" />
              <label className="small muted row" style={{ gap: 8 }}>Права
                <select className="sel" style={{ width: 'auto', minHeight: 34, padding: '4px 10px' }} value={lvl} onChange={(e) => setLvl(+e.target.value as 1 | 2)}>
                  <option value={1}>Просмотр</option><option value={2}>Ведение записей</option>
                </select>
              </label>
            </div>
            {tab === 'user' && <UserPicker value={[]} onChange={(v) => v[0] && add({ subject_type: 'user', subject_id: v[0].id, name: v[0].name })} exclude={cur.filter((r) => r.subject_type === 'user').map((r) => r.subject_id)} placeholder="Найти сотрудника…" />}
            {tab === 'group' && (
              <div className="vPickList">
                {(groups.data || []).filter((g) => !has('group', g.id)).map((g) => <button key={g.id} type="button" className="vPickItem" onClick={() => add({ subject_type: 'group', subject_id: g.id, name: g.name })}><I.Users size={16} />{g.name}</button>)}
                {groups.data && !groups.data.filter((g) => !has('group', g.id)).length && <div className="small muted" style={{ padding: 10 }}>Нет доступных групп</div>}
              </div>
            )}
            {tab === 'department' && (
              <DeptSelect value={null} allowEmpty={false} emptyLabel="Выберите подразделение…" onChange={(id) => { const d = (depts.data || []).find((x) => x.id === id); if (d) add({ subject_type: 'department', subject_id: d.id, name: d.name }); }} />
            )}
          </div>
          <div className="vAcl">
            {cur.length === 0 && <div className="small muted" style={{ padding: '6px 2px' }}>{visibility === 'company' ? 'Доступ открыт всем сотрудникам. Добавьте тех, кто сможет вести записи.' : 'Пока видит только владелец. Добавьте сотрудников или группы.'}</div>}
            {cur.map((r) => { const Ic = ICON[r.subject_type]; return (
              <div className="vAclRow" key={r.subject_type + r.subject_id}>
                <span className="vAclIc"><Ic size={16} /></span>
                <span className="clip bold small">{r.name}<span className="tiny muted"> · {r.subject_type === 'user' ? 'сотрудник' : r.subject_type === 'group' ? 'группа' : 'подразделение'}</span></span>
                <span className="sp" />
                <select className="sel" style={{ width: 'auto', minHeight: 32, padding: '2px 8px' }} value={r.level} aria-label="Права"
                  onChange={(e) => setRows(cur.map((x) => (x === r ? { ...x, level: +e.target.value as 1 | 2 } : x)))}>
                  <option value={1}>Просмотр</option><option value={2}>Ведение записей</option>
                </select>
                <button type="button" className="btn ghost icon sm" aria-label="Убрать" onClick={() => setRows(cur.filter((x) => x !== r))}><I.X size={15} /></button>
              </div>
            ); })}
          </div>
        </>
      )}
      {err && <div className="err">{err}</div>}
    </Modal>
  );
}

// ---------------------------------------------------------------- page
export function VacationsPage() {
  useTitle('График отпусков');
  const nowYm = todayIso().slice(0, 7);
  const [mode, setMode] = usePersist<Mode>('vac.mode', 'month');
  const [ym, setYm] = useState(nowYm);
  const [year, setYear] = useState(+nowYm.slice(0, 4));
  const [rng, setRng] = useState({ from: todayIso(), to: iso(Date.now() + 90 * DAY) });
  const [dept, setDept] = usePersist<number | null>('vac.dept', null);
  const [nowOnly, setNowOnly] = usePersist<boolean>('vac.now', false);
  const [q, setQ] = useState('');
  const dq = useDebounced(q.trim(), 300);
  const [ganttOpen, setGanttOpen] = usePersist<boolean>('vac.gantt', true);
  const [edit, setEdit] = useState<Vac | 'new' | null>(null);
  const [calId, setCalId] = usePersist<number>('vac.cal', 0); // 0 — все доступные календари
  const [calEdit, setCalEdit] = useState<Cal | 'new' | null>(null);
  const [aclFor, setAclFor] = useState<Cal | null>(null);
  const [confirm, node] = useConfirm();

  const { from, to } = useMemo(() => {
    if (mode === 'month') return monthRange(ym);
    if (mode === 'year') return { from: `${year}-01-01`, to: `${year}-12-31` };
    return rng.from && rng.to && rng.to >= rng.from ? rng : { from: todayIso(), to: todayIso() };
  }, [mode, ym, year, rng]);

  const qs = new URLSearchParams({ from, to });
  if (dept) qs.set('department', String(dept));
  if (dq) qs.set('q', dq);
  if (calId) qs.set('calendar', String(calId));
  const { data, error, refetch } = useQuery<{ items: Vac[]; can_manage: boolean; calendars: Cal[] }>('vacations:' + qs, () => api.get('/api/vacations?' + qs), { stale: 15000, keepPrevious: true });
  const items = useMemo(() => (data?.items || []).filter((v) => !nowOnly || v.active_now), [data, nowOnly]);
  const cals = data?.calendars || [];
  const colors = useMemo(() => new Map(cals.map((c) => [c.id, c.color])), [cals]);
  const calById = (id: number) => cals.find((c) => c.id === id);
  const sel = calId ? calById(calId) : undefined;
  const editable = cals.filter((c) => c.level >= 2);
  const can = editable.length > 0 && (!sel || sel.level >= 2);
  const canRow = (v: Vac) => (calById(v.calendar_id)?.level || 0) >= 2;
  // ссылка из уведомления: /vacations?calendar=ID
  React.useEffect(() => { const q = Number(new URLSearchParams(location.search).get('calendar')); if (q > 0) setCalId(q); }, []); // eslint-disable-line
  // выбранный календарь пропал или недоступен — показываем все
  React.useEffect(() => { if (data && calId && !data.calendars.some((c) => c.id === calId)) setCalId(0); }, [data, calId]); // eslint-disable-line
  const reload = () => { invalidate('vacations'); refetch(); };
  async function removeCal(c: Cal) {
    if (!(await confirm('Удалить календарь?', { text: `«${c.name}» и все его записи об отпусках будут удалены`, ok: 'Удалить' }))) return;
    try { await api.del('/api/vacation-calendars/' + c.id); toast({ title: 'Календарь удалён', kind: 'success' }, 2000); setCalId(0); reload(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }

  async function remove(v: Vac) {
    if (!(await confirm('Удалить отпуск?', { text: `${v.name}: ${dmy(v.starts_on)} — ${dmy(v.ends_on)}`, ok: 'Удалить' }))) return;
    try { await api.del('/api/vacations/' + v.id); toast({ title: 'Отпуск удалён', kind: 'success' }, 2000); reload(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }

  return (
    <div className="stack">
      <div className="pageH">
        <h1>График отпусков</h1>
        <span className="sub">{sel ? sel.name : 'все календари'}</span>
        <span className="sp" />
        {can && <Btn kind="pri" onClick={() => setEdit('new')}><I.Plus size={17} /> Добавить отпуск</Btn>}
      </div>

      {data && (cals.length > 1 || data.can_manage) && (
        <div className="vCals" role="tablist" aria-label="Календари отпусков">
          <button type="button" role="tab" aria-selected={!calId} className={cx('vCal', !calId && 'on')} onClick={() => setCalId(0)}>Все календари</button>
          {cals.map((c) => (
            <button key={c.id} type="button" role="tab" aria-selected={calId === c.id} className={cx('vCal', calId === c.id && 'on')} style={{ ['--c' as any]: c.color }} onClick={() => setCalId(c.id)}>
              <i className="vDot" />{c.name}{c.visibility === 'restricted' && <I.Lock size={13} />}
            </button>
          ))}
          {data.can_manage && <button type="button" className="vCal add" onClick={() => setCalEdit('new')}><I.Plus size={15} /> Новый календарь</button>}
        </div>
      )}
      {sel && (
        <div className="vCalInfo card padS">
          <span className="vDot" style={{ ['--c' as any]: sel.color }} />
          <div style={{ minWidth: 0 }}>
            <div className="small">{sel.description || (sel.is_default ? 'Общий график руководящего состава' : 'Календарь отпусков')}</div>
            <div className="tiny muted">{sel.visibility === 'company' ? 'Виден всем сотрудникам' : 'Виден выбранным сотрудникам и группам'}{sel.owner ? ` · владелец: ${sel.owner}` : ''}</div>
          </div>
          <span className="sp" />
          {sel.level >= 3 && <>
            <Btn size="sm" onClick={() => setAclFor(sel)}><I.Users size={15} /> Доступ</Btn>
            <Btn size="sm" onClick={() => setCalEdit(sel)}><I.Edit size={15} /> Изменить</Btn>
            {!sel.is_default && <button type="button" className="btn ghost icon sm" onClick={() => removeCal(sel)} aria-label="Удалить календарь"><I.Trash size={16} /></button>}
          </>}
        </div>
      )}

      <div className="vFilters card pad">
        <div className="vPeriod">
          <div className="viewSw" role="group" aria-label="Период">
            {([['month', 'Месяц'], ['year', 'Год'], ['range', 'Период']] as [Mode, string][]).map(([m, l]) => (
              <button key={m} type="button" className={cx(mode === m && 'on')} onClick={() => setMode(m)} style={{ width: 'auto', padding: '0 12px' }}>{l}</button>
            ))}
          </div>
          {mode === 'month' && (
            <div className="row vNav">
              <button type="button" className="btn ghost icon sm" onClick={() => setYm(shiftMonth(ym, -1))} aria-label="Предыдущий месяц"><I.ChevronLeft size={18} /></button>
              <b className="vMonth">{monthLabel(ym)}</b>
              <button type="button" className="btn ghost icon sm" onClick={() => setYm(shiftMonth(ym, 1))} aria-label="Следующий месяц"><I.ChevronRight size={18} /></button>
              {ym !== nowYm && <Btn size="sm" onClick={() => setYm(nowYm)}>Сегодня</Btn>}
            </div>
          )}
          {mode === 'year' && (
            <div className="row vNav">
              <button type="button" className="btn ghost icon sm" onClick={() => setYear(year - 1)} aria-label="Предыдущий год"><I.ChevronLeft size={18} /></button>
              <b className="vMonth">{year}</b>
              <button type="button" className="btn ghost icon sm" onClick={() => setYear(year + 1)} aria-label="Следующий год"><I.ChevronRight size={18} /></button>
            </div>
          )}
          {mode === 'range' && (
            <div className="row vNav" style={{ flexWrap: 'wrap' }}>
              <Input type="date" style={{ width: 'auto' }} value={rng.from} max={rng.to} onChange={(e) => setRng({ ...rng, from: e.target.value })} aria-label="С" />
              <span className="muted">—</span>
              <Input type="date" style={{ width: 'auto' }} value={rng.to} min={rng.from} onChange={(e) => setRng({ ...rng, to: e.target.value })} aria-label="По" />
            </div>
          )}
        </div>
        <div className="vRow2">
          <div className="fSearch"><Input placeholder="Поиск по сотруднику…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <div className="fDept"><DeptSelect value={dept} onChange={setDept} emptyLabel="Все подразделения" /></div>
          <Check checked={nowOnly} onChange={setNowOnly} label="Сейчас в отпуске" />
        </div>
      </div>

      {error && !data ? <ErrorBox error={error} retry={refetch} /> : !data ? <Loading /> : items.length === 0 ? (
        <div className="card"><Empty icon={I.Clock} title="Отпусков не найдено">{nowOnly || dept || dq ? 'Измените фильтры' : 'В выбранном периоде отпусков нет'}</Empty></div>
      ) : (
        <>
          <section className="card ganttCard">
            <button type="button" className="ganttHead" aria-expanded={ganttOpen} onClick={() => setGanttOpen(!ganttOpen)}>
              <span className="chev"><I.ChevronRight size={18} /></span><b>Диаграмма</b>
              <span className="muted small">{dmy(from)} — {dmy(to)}</span>
            </button>
            {ganttOpen && <div className="ganttBody"><Gantt items={items} from={from} to={to} colors={colors} /></div>}
          </section>

          <div className="card vTable">
            <table className="vTbl">
              <thead><tr><th>Сотрудник</th>{!calId && cals.length > 1 && <th>Календарь</th>}<th>Подразделение</th><th>Период</th><th>Замещает</th><th>Город</th>{items.some(canRow) && <th />}</tr></thead>
              <tbody>
                {items.map((v) => (
                  <tr key={v.id} className={cx(v.active_now && 'now')}>
                    <td data-l="Сотрудник">
                      <Link to={`/people/${v.user_id}`} className="vWho">
                        <Avatar name={v.name} src={v.avatar} size={38} userId={v.user_id} />
                        <span style={{ minWidth: 0 }}><span className="bold">{v.name}</span><span className="small muted vJob">{v.job_title}</span></span>
                      </Link>
                    </td>
                    {!calId && cals.length > 1 && <td data-l="Календарь" className="small"><span className="vTag" style={{ ['--c' as any]: colors.get(v.calendar_id) }}><i className="vDot" />{calById(v.calendar_id)?.name}</span></td>}
                    <td data-l="Подразделение" className="small">{v.department || '—'}</td>
                    <td data-l="Период">
                      <div className="bold nowrap">{dm(v.starts_on)} — {dmy(v.ends_on)}</div>
                      <div className="small muted">{plural(daysOf(v), ['день', 'дня', 'дней'])}{v.active_now && <> · <Badge kind="lime">сейчас в отпуске</Badge></>}</div>
                    </td>
                    <td data-l="Замещает">{v.deputy_id ? <Link to={`/people/${v.deputy_id}`} className="vDep"><span className="bold small">{v.deputy}</span>{v.deputy_title && <span className="tiny muted">{v.deputy_title}</span>}</Link> : <span className="muted">—</span>}</td>
                    <td data-l="Город" className="small">{v.city || '—'}{v.note && <div className="tiny muted">{v.note}</div>}</td>
                    {items.some(canRow) && <td className="vAct">{canRow(v) && <><button type="button" className="btn ghost icon sm" onClick={() => setEdit(v)} aria-label="Изменить"><I.Edit size={16} /></button><button type="button" className="btn ghost icon sm" onClick={() => remove(v)} aria-label="Удалить"><I.Trash size={16} /></button></>}</td>}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="small muted">Всего записей: {items.length}</div>
        </>
      )}
      {edit && <VacModal v={edit === 'new' ? null : edit} cals={editable} initialCal={sel && sel.level >= 2 ? sel.id : (editable.find((c) => c.is_default) || editable[0])?.id || 0} onClose={() => setEdit(null)} onSaved={reload} />}
      {calEdit && <CalModal cal={calEdit === 'new' ? null : calEdit} onClose={() => setCalEdit(null)} onSaved={(id) => { setCalId(id); reload(); }} />}
      {aclFor && <AccessModal cal={aclFor} onClose={() => setAclFor(null)} onSaved={reload} />}
      {node}
    </div>
  );
}
