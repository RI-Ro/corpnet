import { useEffect, useRef } from 'react';
import { trackNewsImpressions, trackNewsRead } from './analytics';

/**
 * Глубина прочтения и активное время чтения статьи. Глубина — доля статьи, прокрученная до нижнего края окна;
 * время считается только пока вкладка видима и в фокусе. Отправка: каждые 15 с, при скрытии вкладки и уходе со страницы.
 */
export function useReadTracking(id: number, target: React.RefObject<HTMLElement>, enabled: boolean) {
  useEffect(() => {
    if (!enabled) return;
    let depth = 0, sent = 0, active = 0, lastSentDepth = -1, opened = false;
    const measure = () => {
      const el = target.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const total = Math.max(r.height, 1);
      const seen = Math.min(Math.max(window.innerHeight - r.top, 0), total);
      depth = Math.max(depth, Math.round((seen / total) * 100));
    };
    const flush = () => {
      measure();
      const delta = active - sent;
      if (opened && delta <= 0 && depth === lastSentDepth) return;
      trackNewsRead(id, depth, delta);
      sent = active; lastSentDepth = depth; opened = true;
    };
    const tick = window.setInterval(() => {
      if (document.visibilityState === 'visible' && document.hasFocus()) active += 1;
      if (active - sent >= 15) flush();
    }, 1000);
    const onScroll = () => measure();
    const onHide = () => { if (document.visibilityState === 'hidden') flush(); };
    window.addEventListener('scroll', onScroll, { passive: true });
    document.addEventListener('visibilitychange', onHide);
    window.addEventListener('pagehide', flush);
    const t0 = window.setTimeout(flush, 800); // «открытие» + стартовая глубина короткой статьи
    return () => {
      clearTimeout(t0); clearInterval(tick);
      window.removeEventListener('scroll', onScroll);
      document.removeEventListener('visibilitychange', onHide);
      window.removeEventListener('pagehide', flush);
      flush();
    };
  }, [id, enabled]); // eslint-disable-line
}

/** Показы карточек: карточка считается показанной, если ≥60% её площади было в окне; отправка пачкой. */
export function useImpressions(root: React.RefObject<HTMLElement>, dep: unknown) {
  const seen = useRef(new Set<number>());
  useEffect(() => {
    const el = root.current;
    if (!el || typeof IntersectionObserver === 'undefined') return;
    let queue: number[] = [];
    let timer = 0;
    const send = () => { timer = 0; if (queue.length) { trackNewsImpressions(queue); queue = []; } };
    const io = new IntersectionObserver((es) => {
      for (const e of es) {
        if (!e.isIntersecting) continue;
        const id = +((e.target as HTMLElement).dataset.nid || 0);
        if (id && !seen.current.has(id)) { seen.current.add(id); queue.push(id); io.unobserve(e.target); }
      }
      if (queue.length && !timer) timer = window.setTimeout(send, 1500);
    }, { threshold: 0.6 });
    el.querySelectorAll<HTMLElement>('[data-nid]').forEach((n) => io.observe(n));
    return () => { io.disconnect(); clearTimeout(timer); send(); };
  }, [dep]); // eslint-disable-line
}
