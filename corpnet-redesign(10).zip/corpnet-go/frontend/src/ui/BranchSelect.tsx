import React from 'react';
import { api } from '../lib/api';
import { useQuery } from '../lib/query';
import { Select } from './index';

export interface Branch { id: number; name: string }

export function useBranches(): Branch[] {
  const { data } = useQuery<{ items: Branch[] }>('branches', () => api.get('/api/branches'), { stale: 120000 });
  return data?.items || [];
}

/** Выбор филиала (форма сотрудника, редактор новости). */
export function BranchSelect({ value, onChange, emptyLabel = 'Не выбран' }: { value: number | null | undefined; onChange: (id: number | null) => void; emptyLabel?: string }) {
  const list = useBranches();
  return (
    <Select value={value ?? ''} onChange={(e) => onChange(e.target.value ? +e.target.value : null)}>
      <option value="">{emptyLabel}</option>
      {list.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
    </Select>
  );
}
