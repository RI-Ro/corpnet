// Применить сохранённую тему и настройку фона до первой отрисовки (без «мигания»). Вынесено из index.html: CSP запрещает inline-скрипты.
// применить сохранённую тему до первой отрисовки (без «мигания»): тема последнего пользователя cn:<id>:theme, иначе cn_theme
  try {
    var ls = localStorage, t = null, uid = ls.getItem('cn_last_uid');
    if (uid) { try { t = JSON.parse(ls.getItem('cn:' + uid + ':theme')); } catch (e) {} }
    var ok = function (v) { return typeof v === 'string' && /^[a-z]{3,16}$/.test(v); };
    if (!ok(t)) t = ls.getItem('cn_theme');
    if (!ok(t)) t = 'glassl';
    if (t === 'system') t = matchMedia('(prefers-color-scheme: dark)').matches ? 'glass' : 'glassl';
    document.documentElement.dataset.theme = t;
    // слабый компьютер → «лёгкий» режим (без blur и анимаций); можно переопределить: localStorage.cn_perf = 'lite' | 'full'
    var pf = ls.getItem('cn_perf'), nav = navigator;
    if (pf !== 'lite' && pf !== 'full') pf = ((nav.hardwareConcurrency && nav.hardwareConcurrency <= 4) || (nav.deviceMemory && nav.deviceMemory <= 4)) ? 'lite' : 'full';
    document.documentElement.dataset.perf = pf;
  } catch (e) {}
// Запрос /api/bootstrap стартует сразу, не дожидаясь загрузки и разбора основного бандла (lib/api.ts подхватывает его из window.__boot).
try {
  if (!/^\/(login|verify)(\/|$)/.test(location.pathname)) window.__boot = fetch('/api/bootstrap', { credentials: 'same-origin' });
} catch (e) {}
