// Service Worker «Вместе»: кэш статики и публичных картинок в браузере. API и приватные файлы (/files) НЕ кэшируются —
// их отдаёт сервер с авторизацией (так на общем компьютере после выхода ничего чужого не остаётся).
// Версию сборки и список предкэша подставляет build.mjs (при каждой сборке файл меняется — браузер ставит новую версию).
const BUILD = '__BUILD__';
const PRECACHE = __PRECACHE__;
const SHELL = 'cn-shell-' + BUILD;      // оболочка (index.html) — по сборкам
const ASSETS = 'cn-assets';              // файлы с хэшем в имени, шрифты, pdf.js — живут между сборками
const MEDIA = 'cn-media';                // публичные картинки /media/* (аватары, обложки)
const LIMIT = { [ASSETS]: 400, [MEDIA]: 300 };

self.addEventListener('install', (e) => {
  e.waitUntil((async () => {
    const c = await caches.open(ASSETS);
    // главный бандл, предзагружаемые чанки, css и шрифты — сразу, чтобы второй визит (и офлайн) был мгновенным
    await Promise.all(PRECACHE.map((u) => c.match(u).then((hit) => hit || c.add(u))).map((p) => p.catch(() => {})));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k.startsWith('cn-shell-') && k !== SHELL) await caches.delete(k);
    await self.clients.claim();
  })());
});

async function trim(name) {
  const c = await caches.open(name), keys = await c.keys(), over = keys.length - LIMIT[name];
  for (let i = 0; i < over; i++) await c.delete(keys[i]); // самые старые по порядку добавления
}

async function cacheFirst(req, name) {
  const c = await caches.open(name);
  const hit = await c.match(req);
  if (hit) return hit;
  const res = await fetch(req);
  if (res.ok && res.status === 200) { c.put(req, res.clone()).then(() => trim(name)).catch(() => {}); }
  return res;
}

self.addEventListener('fetch', (e) => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin || req.headers.has('range')) return;
  const p = url.pathname;
  if (p.startsWith('/assets/') || p.startsWith('/fonts/') || p.startsWith('/pdfjs/')) return void e.respondWith(cacheFirst(req, ASSETS));
  if (p.startsWith('/media/')) return void e.respondWith(cacheFirst(req, MEDIA));
  if (req.mode === 'navigate') { // страницы: сеть, а при обрыве — последняя оболочка
    e.respondWith((async () => {
      try {
        const res = await fetch(req);
        if (res.ok && (res.headers.get('content-type') || '').includes('text/html')) (await caches.open(SHELL)).put('/shell', res.clone());
        return res;
      } catch (err) {
        const hit = await (await caches.open(SHELL)).match('/shell');
        if (hit) return hit;
        throw err;
      }
    })());
  }
});
