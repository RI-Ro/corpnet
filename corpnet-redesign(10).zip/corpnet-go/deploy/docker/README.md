# Docker-стенд: площадка A и площадка B на одном ПК

Поднимает всё, что нужно для проверки работы на двух площадках: у каждой свой PostgreSQL (A — основная БД, B — реплика
со слотом), своё приложение и свой диск с файлами. Порты на хосте **разные**, чтобы не пересекаться.

| Сервис | Адрес по умолчанию | Что это |
|---|---|---|
| Сайт A | http://localhost:18080 | приложение, `DC_ID=msk`, пишет и читает основную БД |
| Сайт B | http://localhost:18090 | приложение, `DC_ID=spb`, пишет в БД A, читает с реплики B |
| PostgreSQL A | localhost:15432 | основная БД (`corpnet` / пароль из `.env`) |
| PostgreSQL B | localhost:15433 | реплика (только чтение) |

Nginx и Redis стенду не нужны: приложение отдаёт HTTP само, сессии и кэши лежат в PostgreSQL, а в каждом контейнере работает prefork (`PREFORK=2` — два рабочих процесса на общем порту). Redis можно подключить необязательно: `REDIS_A=redis://redis-a:6379/0 REDIS_B=redis://redis-b:6379/0 docker compose --profile redis up -d`. Порты меняются в `.env` (`PORT_A`, `PORT_B`, `PG_PORT_A`, `PG_PORT_B`).

## Запуск
```bash
cd deploy/docker
cp .env.example .env        # впишите AUTHOR (имя автора, вшивается при сборке)
docker compose up -d --build
docker compose ps           # дождитесь healthy у app-a и app-b
./test-sync.sh              # сквозная проверка
```
Вход: `ADMIN_EMAIL` / `ADMIN_PASSWORD` из `.env` (по умолчанию `admin@corp.example` / `Passw0rd!x1`), одинаковый на обеих площадках — сессии общие.

Порядок старта сделан автоматически: PG A → миграции (`deploy/db/migrate.sh`, включая 002–005) и первый администратор → реплика PG B (`pg_basebackup`) → приложения.

## Что проверить руками
1. Откройте A и B в двух окнах. Войдите на A — на B вход уже выполнен (общие сессии).
2. Загрузите фото и видео на A (раздел «Файлы»): превью появляется сразу, видео конвертируется в фоне; через ~5–10 с файлы есть и на B.
3. Удалите файл на B — через несколько секунд он исчезает с диска A (и наоборот).
4. Чат/уведомления: сообщение с A приходит на B без перезагрузки (события идут через БД).
5. Репликация: `docker compose exec pg-a psql -U corpnet -c "select client_addr,state,sent_lsn,replay_lsn from pg_stat_replication"`.
6. Файлы на дисках: `docker compose exec app-a ls -l /data/prv`, `docker compose exec app-b ls -l /data/prv`.
7. Prefork: `docker compose exec app-a ps` — мастер и два рабочих; `docker compose kill -s HUP app-a` — плавный перезапуск рабочих; `docker compose exec app-a kill -9 <pid рабочего>` — мастер поднимет его заново.
8. Домены: «Админ-панель → Каталоги LDAP»: у каталога поле «Домен». Логины `ivanov@domain1.local` и `ivanov@domain2.local` — разные пользователи.
9. Отказ связи: `docker compose stop app-b` → поработайте на A → `docker compose start app-b`: B догонит файлы и удаления.

## Остановка и очистка
```bash
docker compose down        # остановить, данные сохраняются в томах
docker compose down -v     # остановить и удалить все данные стенда
```

## Замечания
- Стенд работает по http (`COOKIE_SECURE=false`), поэтому Service Worker работает только на `localhost`.
- Настройки PostgreSQL тут маленькие, для теста; боевые значения считает `deploy/two-sites/scripts/pg-tune.sh`.
- `FILE_SYNC_INTERVAL_SEC=5` — для наглядности; в бою 30.
- В `.env.example` лежат тестовые пароли и токен — в боевой среде замените на свои.
- Образы `postgres:16`, `redis:7-alpine` (только с профилем redis), `node:22-alpine`, `golang:1.24-alpine`, `alpine:3.20` скачиваются с Docker Hub при первом запуске.
