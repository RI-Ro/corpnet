#!/usr/bin/env bash
# Сквозная проверка стенда: репликация PG, общие сессии, синхронизация загрузки и УДАЛЕНИЯ файлов в обе стороны.
#   ./test-sync.sh            (запускать из deploy/docker после docker compose up -d)
set -uo pipefail
cd "$(dirname "$0")"
[ -f .env ] && set -a && . ./.env && set +a
A=http://localhost:${PORT_A:-18080}; B=http://localhost:${PORT_B:-18090}
EMAIL=${ADMIN_EMAIL:-admin@corp.example}; PASS=${ADMIN_PASSWORD:-Passw0rd!x1}
RC=0; ok(){ printf '  [ ok ] %s\n' "$*"; }; bad(){ printf '  [FAIL] %s\n' "$*"; RC=1; }
dc(){ docker compose exec -T "$@"; }
wait_for(){ # wait_for "<описание>" <сек> команда…  — ждёт, пока команда вернёт 0
  local d="$1" t="$2"; shift 2; for ((i=0;i<t;i++)); do "$@" >/dev/null 2>&1 && { ok "$d"; return 0; }; sleep 1; done; bad "$d (не дождались за ${t} с)"; return 1; }
has(){ dc "$1" sh -c "ls /data/prv | grep -qx '$2'"; }
gone(){ ! has "$1" "$2"; }
J=$(mktemp -d); trap 'rm -rf "$J"' EXIT

echo "== Репликация PostgreSQL"
[ "$(dc pg-a psql -U corpnet -d corpnet -tAc 'select count(*) from pg_stat_replication where state=$$streaming$$' | tr -d '\r ')" = 1 ] && ok "A: реплика подключена (streaming)" || bad "A: реплика не подключена"
[ "$(dc pg-b psql -U corpnet -d corpnet -tAc 'select pg_is_in_recovery()' | tr -d '\r ')" = t ] && ok "B: PostgreSQL в режиме standby" || bad "B: не standby"

echo "== Приложения и вход"
curl -fsS "$A/healthz" >/dev/null && ok "A отвечает" || bad "A не отвечает"
curl -fsS "$B/healthz" >/dev/null && ok "B отвечает" || bad "B не отвечает"
login(){ curl -s -c "$J/$1" -H 'Content-Type: application/json' -d "{\"login\":\"$EMAIL\",\"password\":\"$PASS\"}" "$2/api/auth/login" -o /dev/null -w '%{http_code}'; }
[ "$(login a "$A")" = 200 ] && ok "вход на A" || bad "вход на A"
# общая сессия: cookie, выданный A, должен приниматься на B
code=$(curl -s -o /dev/null -w '%{http_code}' -b "$J/a" "$B/api/bootstrap"); [ "$code" = 200 ] && ok "сессия с A принята на B (общие сессии)" || bad "сессия с A не принята на B (HTTP $code)"
[ "$(login b "$B")" = 200 ] || bad "вход на B"
CA="X-CSRF-Token: $(awk '$6=="cn_csrf"{print $7}' "$J/a")"; CB="X-CSRF-Token: $(awk '$6=="cn_csrf"{print $7}' "$J/b")"

echo "== Файлы: загрузка"
FID=$(curl -s -b "$J/a" -H "$CA" -H 'Content-Type: application/json' -d '{"name":"sync-test","kind":"documents"}' "$A/api/folders" | grep -o '"id":[0-9]*' | head -1 | cut -d: -f2)
[ -n "$FID" ] && ok "папка создана (id $FID)" || { bad "не создана папка"; exit 1; }
head -c 300000 /dev/urandom > "$J/f1.bin"; head -c 200000 /dev/urandom > "$J/f2.bin"
up(){ curl -s -b "$J/$1" -H "$2" -F "files=@$3" "$4/api/folders/$FID/files"; }
R1=$(up a "$CA" "$J/f1.bin" "$A"); R2=$(up a "$CA" "$J/f2.bin" "$A")
ID1=$(echo "$R1" | grep -o '"id":[0-9]*' | head -1 | cut -d: -f2); ID2=$(echo "$R2" | grep -o '"id":[0-9]*' | head -1 | cut -d: -f2)
N1=$(dc app-a sh -c 'ls -t /data/prv | grep -v "\.[tv]\." | sed -n 2p' | tr -d '\r'); N2=$(dc app-a sh -c 'ls -t /data/prv | grep -v "\.[tv]\." | sed -n 1p' | tr -d '\r')
[ -n "$ID1" ] && [ -n "$ID2" ] && ok "на A загружено два файла (id $ID1, $ID2)" || { bad "загрузка не удалась"; exit 1; }
wait_for "файл 1 появился на диске B" 40 has app-b "$N1"
wait_for "файл 2 появился на диске B" 40 has app-b "$N2"

echo "== Файлы: удаление синхронизируется"
c=$(curl -s -o /dev/null -w '%{http_code}' -b "$J/b" -H "$CB" -X DELETE "$B/api/files/$ID1"); [ "$c" = 200 ] && ok "файл 1 удалён через B" || bad "удаление через B: HTTP $c"
wait_for "файл 1 исчез с диска A" 40 gone app-a "$N1"
c=$(curl -s -o /dev/null -w '%{http_code}' -b "$J/a" -H "$CA" -X DELETE "$A/api/files/$ID2"); [ "$c" = 200 ] && ok "файл 2 удалён через A" || bad "удаление через A: HTTP $c"
wait_for "файл 2 исчез с диска B" 40 gone app-b "$N2"
sleep 12
gone app-a "$N1" && gone app-b "$N1" && gone app-a "$N2" && gone app-b "$N2" && ok "после нескольких кругов синхронизации файлы не «воскресли»" || bad "удалённый файл вернулся"
echo
[ $RC = 0 ] && echo "ИТОГ: всё работает" || echo "ИТОГ: есть замечания"
exit $RC
