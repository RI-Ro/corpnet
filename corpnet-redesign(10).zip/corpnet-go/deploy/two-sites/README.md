# Две (и более) площадки

Готовый набор для развёртывания «Вместе» на двух площадках. Подробная инструкция с рисунками: `Vmeste_two_sites.docx`.

| Файл | Назначение |
|---|---|
| `scripts/pg-tune.sh` | параметры PostgreSQL под железо → `conf.d/99-vmeste.conf` (`--role primary\|replica`) |
| `scripts/pg-primary-init.sh` | роль `replicator`, слот, правила `pg_hba.conf` (на основной БД) |
| `scripts/pg-replica-init.sh` | заливка реплики `pg_basebackup -R` со слотом |
| `scripts/check-two-sites.sh` | проверка БД, репликации, приложений и файлов |
| `scripts/add-site.sh` | подготовка основной БД к новой площадке (слот + pg_hba) |
| `site-a/`, `site-b/` | `portal.env`, `portal.service`, `99-vmeste.conf` (nginx и Redis не нужны) |

Порядок: A (pg-tune → pg-primary-init → `deploy/db/migrate.sh --seed` → portal), затем B (pg-tune --role replica → pg-replica-init → portal), затем `check-two-sites.sh`.
Миграции и seed запускаются только на A. `INTERNAL_TOKEN` и `SECRET_KEY` одинаковы на всех площадках.

Третья площадка: `REPL_PASSWORD=… scripts/add-site.sh --name site_c --net <подсеть C>`, затем шаги из вывода скрипта (FILE_PEERS на всех площадках, `PEER_ALLOW` по желанию).

Удаление файлов синхронизируется через журнал `file_tombstones` (миграция 003; хранится 90 дней). Автоматического failover нет (`pg_ctl promote` вручную).

## Без nginx и без обязательного Redis

* Приложение само отдаёт HTTPS (`TLS_CERT`/`TLS_KEY`, HTTP/2 включается сам), редиректит `:80 → :443` (`HTTP_REDIRECT_ADDR`) и само ограничивает `/metrics` и `/internal/*` по сетям (`INTERNAL_ALLOW`, `PEER_ALLOW`).
* Сессии, кэши, счётчики и блокировки лежат в PostgreSQL (таблица `kv_store`, UNLOGGED). Redis подключается только если задан `REDIS_URL`.
* `PREFORK=N` (или `auto`) запускает N рабочих процессов под одним мастером на общем порту; `systemctl reload portal` — плавный перезапуск. `PG_POOL_MAX` — общий предел и делится между рабочими.
* Пользователи разных доменов — разные пользователи: у каждого каталога LDAP задаётся «Домен» (миграция 005), логин в портале — `логин@домен`.
