#!/usr/bin/env bash
# Подключение ТРЕТЬЕЙ (и следующих) площадок. Шаг на главной БД: слот репликации + доступ по pg_hba.conf.
# Запускать на сервере БД площадки A от postgres (после этого на новой площадке выполняют остальные шаги руководства):
#   REPL_PASSWORD='...' ./add-site.sh --name site_c --net 10.30.0.0/24
set -euo pipefail
NAME=""; NET=""
while [ $# -gt 0 ]; do case "$1" in --name) NAME="$2"; shift 2 ;; --net) NET="$2"; shift 2 ;; *) echo "аргумент? $1" >&2; exit 2 ;; esac; done
: "${NAME:?--name site_c}"; : "${NET:?--net <подсеть новой площадки>}"
here="$(cd "$(dirname "$0")" && pwd)"
"$here/pg-primary-init.sh" --replica-net "$NET" --slot "$NAME"
cat <<TXT

Дальше (на НОВОЙ площадке):
  1) postgresql: pg-tune.sh --role replica > conf.d/99-vmeste.conf; pg-replica-init.sh --primary <IP A> --slot $NAME ...
  2) /etc/portal/portal.env: DC_ID=<новое имя>, INSTANCE_ID=..., DATABASE_URL -> основная БД на A, DATABASE_REPLICA_URL -> локальная реплика,
     FILE_PEERS=<адреса ВСЕХ остальных площадок через запятую>, те же INTERNAL_TOKEN и SECRET_KEY.
  3) На ВСЕХ существующих площадках добавьте адрес новой в FILE_PEERS и перезапустите portal (systemctl restart portal);
     при необходимости добавьте адрес новой площадки в PEER_ALLOW (/internal/* и так закрыт токеном).
  4) Проверка: scripts/check-two-sites.sh (для трёх площадок запускайте попарно).
TXT
