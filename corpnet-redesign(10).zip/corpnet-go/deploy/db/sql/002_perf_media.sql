-- 002: фоновая конвертация медиа и индексы под частые запросы.
-- media_state: 0 — ждёт обработки, 1 — в работе, 2 — не удалось (после 3 попыток), 3 — готово / не требуется.
ALTER TABLE files ADD COLUMN IF NOT EXISTS media_state smallint NOT NULL DEFAULT 0;
ALTER TABLE files ADD COLUMN IF NOT EXISTS media_tries smallint NOT NULL DEFAULT 0;
ALTER TABLE files ADD COLUMN IF NOT EXISTS media_at    timestamptz;

-- уже обработанные и не-медиа файлы очереди не требуют
UPDATE files SET media_state = 3
 WHERE thumb <> '' OR external_url <> '' OR storage = ''
    OR NOT (mime LIKE 'image/%' OR mime LIKE 'video/%');

-- очередь воркера выбирает только ждущие файлы — индекс частичный и крошечный
CREATE INDEX IF NOT EXISTS files_media_pending ON files (id) WHERE media_state IN (0, 1);

-- проверка «файл ещё нужен» при синхронизации между площадками (filesync.go)
CREATE INDEX IF NOT EXISTS files_storage_idx ON files (storage) WHERE storage <> '';
CREATE INDEX IF NOT EXISTS files_thumb_idx   ON files (thumb)   WHERE thumb <> '';
CREATE INDEX IF NOT EXISTS files_view_idx    ON files (view)    WHERE view <> '';
