-- ============================================================================
-- CorpNet: единый файл схемы БД (PostgreSQL 14+).
-- Все миграции сведены сюда (бывшие 001–018). Тестовые данные — в deploy/db/seed.sql.
-- Файл применяется один раз целиком (учёт в schema_migrations, версия 001_schema).
-- ============================================================================


-- ############################################################################
-- ## 001_init.sql
-- ############################################################################

-- CorpNet: initial schema
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE departments (
    id          bigserial PRIMARY KEY,
    parent_id   bigint REFERENCES departments(id) ON DELETE SET NULL,
    name        text NOT NULL,
    description text NOT NULL DEFAULT '',
    image       text NOT NULL DEFAULT '',
    head_id     bigint,
    sort        int NOT NULL DEFAULT 0,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX departments_parent ON departments(parent_id);

CREATE TABLE users (
    id            bigserial PRIMARY KEY,
    email         text NOT NULL,
    password_hash text NOT NULL,
    first_name    text NOT NULL,
    last_name     text NOT NULL,
    job_title     text NOT NULL DEFAULT '',
    department_id bigint REFERENCES departments(id) ON DELETE SET NULL,
    role          text NOT NULL DEFAULT 'user' CHECK (role IN ('admin','editor','user')),
    avatar        text NOT NULL DEFAULT '',
    phone         text NOT NULL DEFAULT '',
    birthday      date,
    about         text NOT NULL DEFAULT '',
    blocked       boolean NOT NULL DEFAULT false,
    last_seen     timestamptz,
    settings      jsonb NOT NULL DEFAULT '{}',
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX users_email_uq ON users (lower(email));
CREATE INDEX users_dept ON users(department_id);
CREATE INDEX users_name_trgm ON users USING gin (lower(first_name || ' ' || last_name) gin_trgm_ops);
CREATE INDEX users_bday ON users ((extract(month FROM birthday)::int), (extract(day FROM birthday)::int)) WHERE birthday IS NOT NULL;
ALTER TABLE departments ADD CONSTRAINT departments_head_fk FOREIGN KEY (head_id) REFERENCES users(id) ON DELETE SET NULL;

CREATE TABLE categories (
    id    serial PRIMARY KEY,
    name  text NOT NULL,
    color text NOT NULL DEFAULT '#286b9e',
    sort  int NOT NULL DEFAULT 0
);

CREATE TABLE directions (
    id          bigserial PRIMARY KEY,
    parent_id   bigint REFERENCES directions(id) ON DELETE CASCADE,
    name        text NOT NULL,
    description text NOT NULL DEFAULT '',
    cover       text NOT NULL DEFAULT '',
    sort        int NOT NULL DEFAULT 0,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX directions_parent ON directions(parent_id);

CREATE TABLE news (
    id            bigserial PRIMARY KEY,
    title         text NOT NULL,
    summary       text NOT NULL DEFAULT '',
    body          text NOT NULL DEFAULT '',
    category_id   int REFERENCES categories(id) ON DELETE SET NULL,
    author_id     bigint REFERENCES users(id) ON DELETE SET NULL,
    cover         text NOT NULL DEFAULT '',
    important     boolean NOT NULL DEFAULT false,
    pinned        boolean NOT NULL DEFAULT false,
    status        text NOT NULL DEFAULT 'published' CHECK (status IN ('draft','published')),
    department_id bigint REFERENCES departments(id) ON DELETE SET NULL,
    direction_id  bigint REFERENCES directions(id) ON DELETE SET NULL,
    likes_count    int NOT NULL DEFAULT 0,
    comments_count int NOT NULL DEFAULT 0,
    views_count    int NOT NULL DEFAULT 0,
    published_at  timestamptz NOT NULL DEFAULT now(),
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now(),
    search        tsvector GENERATED ALWAYS AS (
        setweight(to_tsvector('russian', coalesce(title, '')), 'A') ||
        setweight(to_tsvector('russian', coalesce(summary, '')), 'B') ||
        setweight(to_tsvector('russian', coalesce(body, '')), 'C')
    ) STORED
);
CREATE INDEX news_feed ON news (status, pinned DESC, published_at DESC);
CREATE INDEX news_important ON news (published_at DESC) WHERE important AND status = 'published';
CREATE INDEX news_category ON news (category_id, published_at DESC);
CREATE INDEX news_direction ON news (direction_id) WHERE direction_id IS NOT NULL;
CREATE INDEX news_department ON news (department_id) WHERE department_id IS NOT NULL;
CREATE INDEX news_search ON news USING gin (search);

CREATE TABLE folders (
    id          bigserial PRIMARY KEY,
    kind        text NOT NULL CHECK (kind IN ('documents','photos','videos')),
    parent_id   bigint REFERENCES folders(id) ON DELETE CASCADE,
    name        text NOT NULL,
    description text NOT NULL DEFAULT '',
    cover       text NOT NULL DEFAULT '',
    visibility  text NOT NULL DEFAULT 'company' CHECK (visibility IN ('company','restricted')),
    owner_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX folders_parent ON folders (kind, parent_id);

CREATE TABLE files (
    id           bigserial PRIMARY KEY,
    folder_id    bigint REFERENCES folders(id) ON DELETE CASCADE,
    owner_id     bigint REFERENCES users(id) ON DELETE SET NULL,
    name         text NOT NULL,
    mime         text NOT NULL DEFAULT 'application/octet-stream',
    size         bigint NOT NULL DEFAULT 0,
    storage      text NOT NULL DEFAULT '',
    thumb        text NOT NULL DEFAULT '',
    external_url text NOT NULL DEFAULT '',
    width        int NOT NULL DEFAULT 0,
    height       int NOT NULL DEFAULT 0,
    context      text NOT NULL DEFAULT 'folder' CHECK (context IN ('folder','chat','news')),
    created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX files_folder ON files (folder_id, id DESC) WHERE folder_id IS NOT NULL;
CREATE INDEX files_name_trgm ON files USING gin (lower(name) gin_trgm_ops);

CREATE TABLE news_files (
    news_id bigint NOT NULL REFERENCES news(id) ON DELETE CASCADE,
    file_id bigint NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    PRIMARY KEY (news_id, file_id)
);

-- Generic ACL for folders and calendars. level: 1=view 2=add 3=edit 4=owner
CREATE TABLE acl (
    resource_type text NOT NULL CHECK (resource_type IN ('folder','calendar')),
    resource_id   bigint NOT NULL,
    subject_type  text NOT NULL CHECK (subject_type IN ('user','department')),
    subject_id    bigint NOT NULL,
    level         smallint NOT NULL CHECK (level BETWEEN 1 AND 4),
    PRIMARY KEY (resource_type, resource_id, subject_type, subject_id)
);
CREATE INDEX acl_subject ON acl (subject_type, subject_id);

CREATE TABLE likes (
    entity_type text NOT NULL CHECK (entity_type IN ('news','post')),
    entity_id   bigint NOT NULL,
    user_id     bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (entity_type, entity_id, user_id)
);
CREATE INDEX likes_user ON likes (user_id, entity_type);

CREATE TABLE comments (
    id          bigserial PRIMARY KEY,
    entity_type text NOT NULL CHECK (entity_type IN ('news','post')),
    entity_id   bigint NOT NULL,
    user_id     bigint REFERENCES users(id) ON DELETE SET NULL,
    parent_id   bigint REFERENCES comments(id) ON DELETE CASCADE,
    body        text NOT NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    deleted_at  timestamptz
);
CREATE INDEX comments_entity ON comments (entity_type, entity_id, id);

CREATE TABLE chats (
    id              bigserial PRIMARY KEY,
    kind            text NOT NULL CHECK (kind IN ('direct','group')),
    title           text NOT NULL DEFAULT '',
    avatar          text NOT NULL DEFAULT '',
    created_by      bigint REFERENCES users(id) ON DELETE SET NULL,
    group_id        bigint,
    direct_key      text UNIQUE,
    last_message_id bigint,
    last_message_at timestamptz NOT NULL DEFAULT now(),
    created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE chat_members (
    chat_id      bigint NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    user_id      bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    last_read_id bigint NOT NULL DEFAULT 0,
    muted        boolean NOT NULL DEFAULT false,
    joined_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (chat_id, user_id)
);
CREATE INDEX chat_members_user ON chat_members (user_id);

CREATE TABLE messages (
    id         bigserial PRIMARY KEY,
    chat_id    bigint NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    user_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    body       text NOT NULL DEFAULT '',
    file_id    bigint REFERENCES files(id) ON DELETE SET NULL,
    reply_to   bigint,
    client_id  text,
    created_at timestamptz NOT NULL DEFAULT now(),
    edited_at  timestamptz,
    deleted_at timestamptz
);
CREATE INDEX messages_chat ON messages (chat_id, id DESC);
CREATE UNIQUE INDEX messages_client ON messages (chat_id, user_id, client_id) WHERE client_id IS NOT NULL;
ALTER TABLE chats ADD CONSTRAINT chats_last_msg_fk FOREIGN KEY (last_message_id) REFERENCES messages(id) ON DELETE SET NULL;

CREATE TABLE user_groups (
    id          bigserial PRIMARY KEY,
    name        text NOT NULL,
    description text NOT NULL DEFAULT '',
    cover       text NOT NULL DEFAULT '',
    visibility  text NOT NULL DEFAULT 'public' CHECK (visibility IN ('public','closed')),
    owner_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    chat_id     bigint REFERENCES chats(id) ON DELETE SET NULL,
    created_at  timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE chats ADD CONSTRAINT chats_group_fk FOREIGN KEY (group_id) REFERENCES user_groups(id) ON DELETE CASCADE;

CREATE TABLE group_members (
    group_id  bigint NOT NULL REFERENCES user_groups(id) ON DELETE CASCADE,
    user_id   bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role      text NOT NULL DEFAULT 'member' CHECK (role IN ('owner','member','pending')),
    joined_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (group_id, user_id)
);
CREATE INDEX group_members_user ON group_members (user_id);

CREATE TABLE group_posts (
    id             bigserial PRIMARY KEY,
    group_id       bigint NOT NULL REFERENCES user_groups(id) ON DELETE CASCADE,
    user_id        bigint REFERENCES users(id) ON DELETE SET NULL,
    body           text NOT NULL,
    image          text NOT NULL DEFAULT '',
    likes_count    int NOT NULL DEFAULT 0,
    comments_count int NOT NULL DEFAULT 0,
    created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX group_posts_group ON group_posts (group_id, id DESC);

CREATE TABLE calendars (
    id          bigserial PRIMARY KEY,
    name        text NOT NULL,
    description text NOT NULL DEFAULT '',
    kind        text NOT NULL DEFAULT 'custom' CHECK (kind IN ('personal','birthdays','conference','rooms','custom')),
    color       text NOT NULL DEFAULT '#286b9e',
    owner_id    bigint REFERENCES users(id) ON DELETE CASCADE,
    visibility  text NOT NULL DEFAULT 'company' CHECK (visibility IN ('company','restricted')),
    open_add    boolean NOT NULL DEFAULT false,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX calendars_owner ON calendars (owner_id);

CREATE TABLE events (
    id          bigserial PRIMARY KEY,
    calendar_id bigint NOT NULL REFERENCES calendars(id) ON DELETE CASCADE,
    title       text NOT NULL,
    description text NOT NULL DEFAULT '',
    location    text NOT NULL DEFAULT '',
    starts_at   timestamptz NOT NULL,
    ends_at     timestamptz NOT NULL,
    all_day     boolean NOT NULL DEFAULT false,
    video_url   text NOT NULL DEFAULT '',
    creator_id  bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    CHECK (ends_at >= starts_at)
);
CREATE INDEX events_cal_time ON events (calendar_id, starts_at);
CREATE INDEX events_time ON events (starts_at);

CREATE TABLE event_attendees (
    event_id bigint NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    user_id  bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status   text NOT NULL DEFAULT 'invited' CHECK (status IN ('invited','accepted','declined')),
    PRIMARY KEY (event_id, user_id)
);
CREATE INDEX event_attendees_user ON event_attendees (user_id);

CREATE TABLE notifications (
    id         bigserial PRIMARY KEY,
    user_id    bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind       text NOT NULL,
    title      text NOT NULL,
    body       text NOT NULL DEFAULT '',
    link       text NOT NULL DEFAULT '',
    created_at timestamptz NOT NULL DEFAULT now(),
    read_at    timestamptz
);
CREATE INDEX notifications_user ON notifications (user_id, id DESC);
CREATE INDEX notifications_unread ON notifications (user_id) WHERE read_at IS NULL;

CREATE TABLE resources (
    id          bigserial PRIMARY KEY,
    name        text NOT NULL,
    description text NOT NULL DEFAULT '',
    url         text NOT NULL,
    icon        text NOT NULL DEFAULT 'link',
    sort        int NOT NULL DEFAULT 0
);

CREATE TABLE company (
    id         int PRIMARY KEY CHECK (id = 1),
    name       text NOT NULL DEFAULT 'ООО «КорпНэт»',
    tagline    text NOT NULL DEFAULT 'Корпоративная информационная система',
    about      text NOT NULL DEFAULT '',
    address    text NOT NULL DEFAULT '',
    phone      text NOT NULL DEFAULT '',
    email      text NOT NULL DEFAULT '',
    logo       text NOT NULL DEFAULT '',
    founded    int NOT NULL DEFAULT 2026
);
INSERT INTO company (id) VALUES (1);

CREATE TABLE audit_log (
    id         bigserial PRIMARY KEY,
    user_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    action     text NOT NULL,
    entity     text NOT NULL DEFAULT '',
    entity_id  bigint,
    data       jsonb NOT NULL DEFAULT '{}',
    ip         text NOT NULL DEFAULT '',
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_created ON audit_log (id DESC);


-- ############################################################################
-- ## 002_users_org.sql
-- ############################################################################

-- 002: пользователи (ФИО, логин, телефоны, руководитель), подразделения, направления, права редакторов

-- ---- users ---------------------------------------------------------------
ALTER TABLE users
    ADD COLUMN login          text,
    ADD COLUMN middle_name    text    NOT NULL DEFAULT '',
    ADD COLUMN extra_info     text    NOT NULL DEFAULT '',
    ADD COLUMN phone2         text    NOT NULL DEFAULT '',
    ADD COLUMN phone3         text    NOT NULL DEFAULT '',
    ADD COLUMN phone4         text    NOT NULL DEFAULT '',
    ADD COLUMN is_head        boolean NOT NULL DEFAULT false,   -- руководитель подразделения
    ADD COLUMN can_vacations  boolean NOT NULL DEFAULT false,   -- может вести график отпусков
    ADD COLUMN company_news   boolean NOT NULL DEFAULT false,   -- редактор может публиковать новости «для всей компании»
    ADD COLUMN ldap_server_id bigint,                           -- источник правды (FK добавляется в 005)
    ADD COLUMN ldap_dn        text    NOT NULL DEFAULT '',
    ADD COLUMN ldap_uid       text    NOT NULL DEFAULT '';
ALTER TABLE users RENAME COLUMN phone TO phone1;
ALTER TABLE users DROP COLUMN about;

UPDATE users u SET login = x.l FROM (
    SELECT id, lower(split_part(email, '@', 1)) ||
           CASE WHEN row_number() OVER (PARTITION BY lower(split_part(email, '@', 1)) ORDER BY id) > 1
                THEN '.' || id::text ELSE '' END AS l
    FROM users) x WHERE x.id = u.id;
ALTER TABLE users ALTER COLUMN login SET NOT NULL;
CREATE UNIQUE INDEX users_login_uq ON users (lower(login));

-- email необязателен (LDAP-пользователи могут быть без почты)
ALTER TABLE users ALTER COLUMN email SET DEFAULT '';
DROP INDEX users_email_uq;
CREATE UNIQUE INDEX users_email_uq ON users (lower(email)) WHERE email <> '';

-- Фамилия Имя Отчество одной строкой + строка для поиска (триграммы)
ALTER TABLE users
    ADD COLUMN full_name text GENERATED ALWAYS AS (
        last_name || ' ' || first_name || CASE WHEN middle_name <> '' THEN ' ' || middle_name ELSE '' END) STORED,
    ADD COLUMN search_text text GENERATED ALWAYS AS (
        lower(last_name || ' ' || first_name || ' ' || middle_name || ' ' || login || ' ' || email || ' ' || job_title)) STORED;
DROP INDEX users_name_trgm;
CREATE INDEX users_search_trgm ON users USING gin (search_text gin_trgm_ops);
-- алфавитный порядок: фамилия, имя, отчество
CREATE INDEX users_alpha ON users (lower(last_name), lower(first_name), lower(middle_name), id);
CREATE INDEX users_dept_alpha ON users (department_id, lower(last_name), lower(first_name), id) WHERE NOT blocked;
CREATE INDEX users_last_prefix ON users (lower(last_name) text_pattern_ops);
CREATE INDEX users_ldap ON users (ldap_server_id, ldap_uid) WHERE ldap_server_id IS NOT NULL;
CREATE INDEX users_heads ON users (id) WHERE is_head AND NOT blocked;

-- ---- departments -----------------------------------------------------------
-- description хранит markdown; sort — индекс сортировки (при равенстве — по алфавиту)
CREATE INDEX departments_tree ON departments (parent_id, sort, lower(name), id);

-- Дополнительные подразделения, которыми может управлять редактор (помимо своего).
-- Область управления редактора = поддерево своего подразделения + поддеревья этих.
CREATE TABLE editor_departments (
    user_id       bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id bigint NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, department_id)
);
CREATE INDEX editor_departments_dept ON editor_departments (department_id);

-- ---- directions (направления деятельности) ---------------------------------
-- department_id — подразделение-владелец: его редакторы управляют направлением и всеми дочерними.
ALTER TABLE directions ADD COLUMN department_id bigint REFERENCES departments(id) ON DELETE SET NULL;
CREATE INDEX directions_tree ON directions (parent_id, sort, lower(name), id);
CREATE INDEX directions_dept ON directions (department_id) WHERE department_id IS NOT NULL;


-- ############################################################################
-- ## 003_news.sql
-- ############################################################################

-- 003: новости — окно показа, скрытие, галереи, поиск без стемминга, индексы под миллионы записей

ALTER TABLE news
    ADD COLUMN visible_until timestamptz,                    -- NULL = показывать бессрочно
    ADD COLUMN hidden        boolean NOT NULL DEFAULT false, -- «скрыть с публикации»
    ADD COLUMN announced     boolean NOT NULL DEFAULT true;  -- разослано ли уведомление о публикации

-- Старый индекс по русской морфологии давал ложные совпадения («иии» находил что угодно).
-- Новый: конфигурация 'simple' (без стемминга и стоп-слов) + триграммы по заголовку.
ALTER TABLE news DROP COLUMN search;
ALTER TABLE news ADD COLUMN search_simple tsvector GENERATED ALWAYS AS (
    to_tsvector('simple', coalesce(title, '') || ' ' || coalesce(summary, '') || ' ' || coalesce(body, ''))) STORED;

DROP INDEX IF EXISTS news_feed, news_important, news_category, news_direction, news_department;
CREATE INDEX news_stream    ON news (published_at DESC, id DESC) WHERE status = 'published' AND NOT hidden;
CREATE INDEX news_pinned    ON news (published_at DESC, id DESC) WHERE pinned AND status = 'published' AND NOT hidden;
CREATE INDEX news_important ON news (published_at DESC, id DESC) WHERE important AND status = 'published' AND NOT hidden;
CREATE INDEX news_cat       ON news (category_id, published_at DESC, id DESC) WHERE status = 'published' AND NOT hidden;
CREATE INDEX news_dir       ON news (direction_id, published_at DESC, id DESC) WHERE direction_id IS NOT NULL;
CREATE INDEX news_dept      ON news (department_id, published_at DESC, id DESC);
CREATE INDEX news_author    ON news (author_id, id DESC);
CREATE INDEX news_announce  ON news (published_at) WHERE NOT announced AND status = 'published' AND NOT hidden;
CREATE INDEX news_title_trgm ON news USING gin (lower(title) gin_trgm_ops);
CREATE INDEX news_fts       ON news USING gin (search_simple);

-- ссылки на фото/видео галереи внутри новости
CREATE TABLE news_galleries (
    id        bigserial PRIMARY KEY,
    news_id   bigint NOT NULL REFERENCES news(id) ON DELETE CASCADE,
    folder_id bigint NOT NULL REFERENCES folders(id) ON DELETE CASCADE,
    title     text   NOT NULL DEFAULT '',
    sort      int    NOT NULL DEFAULT 0
);
CREATE INDEX news_galleries_news ON news_galleries (news_id, sort, id);
CREATE INDEX news_galleries_folder ON news_galleries (folder_id);

-- ---- комментарии: вложенность до 5 уровней и вложения ------------------------
ALTER TABLE comments DROP CONSTRAINT comments_entity_type_check;
ALTER TABLE comments ADD CONSTRAINT comments_entity_type_check CHECK (entity_type IN ('news','post','idea'));
ALTER TABLE likes DROP CONSTRAINT likes_entity_type_check;
ALTER TABLE likes ADD CONSTRAINT likes_entity_type_check CHECK (entity_type IN ('news','post','idea'));
ALTER TABLE comments
    ADD COLUMN depth   smallint NOT NULL DEFAULT 0 CHECK (depth BETWEEN 0 AND 5),
    ADD COLUMN root_id bigint;
UPDATE comments SET root_id = id WHERE parent_id IS NULL;
UPDATE comments SET root_id = parent_id WHERE parent_id IS NOT NULL AND root_id IS NULL;
DROP INDEX comments_entity;
CREATE INDEX comments_roots ON comments (entity_type, entity_id, id) WHERE parent_id IS NULL;
CREATE INDEX comments_root  ON comments (root_id, id);
CREATE INDEX comments_user  ON comments (user_id, id DESC);

ALTER TABLE files DROP CONSTRAINT files_context_check;
ALTER TABLE files ADD CONSTRAINT files_context_check CHECK (context IN ('folder','chat','news','comment'));
CREATE TABLE comment_files (
    comment_id bigint NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
    file_id    bigint NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    PRIMARY KEY (comment_id, file_id)
);
CREATE INDEX comment_files_file ON comment_files (file_id);
CREATE INDEX files_owner_ctx ON files (owner_id, context, id DESC) WHERE context <> 'folder';

-- ---- уведомления: страницы по непрочитанным / прочитанным ---------------------
DROP INDEX notifications_user, notifications_unread;
CREATE INDEX notifications_unread ON notifications (user_id, id DESC) WHERE read_at IS NULL;
CREATE INDEX notifications_read   ON notifications (user_id, id DESC) WHERE read_at IS NOT NULL;
CREATE INDEX notifications_old    ON notifications (created_at) WHERE read_at IS NOT NULL;


-- ############################################################################
-- ## 004_features.sql
-- ############################################################################

-- 004: группы (открытые/закрытые/скрытые), чаты (очистка «для себя», голосования), календари (повторы),
--      баннеры, график отпусков, «Есть идея»

-- ---- группы --------------------------------------------------------------------
ALTER TABLE user_groups DROP CONSTRAINT user_groups_visibility_check;
ALTER TABLE user_groups ADD CONSTRAINT user_groups_visibility_check CHECK (visibility IN ('public','closed','secret'));
ALTER TABLE group_members DROP CONSTRAINT group_members_role_check;
ALTER TABLE group_members ADD CONSTRAINT group_members_role_check CHECK (role IN ('owner','admin','member','pending'));
CREATE INDEX user_groups_name ON user_groups (lower(name), id);
CREATE INDEX user_groups_listed ON user_groups (lower(name)) WHERE visibility <> 'secret';
CREATE INDEX group_members_role ON group_members (group_id, role);
CREATE INDEX group_posts_user ON group_posts (user_id);

-- ---- чаты ------------------------------------------------------------------------
-- cleared_before_id: «очистить у меня» (сообщения с id <= значения скрыты только для этого участника)
-- hidden: «удалить у меня» (чат исчезает из списка до следующего сообщения)
ALTER TABLE chat_members
    ADD COLUMN cleared_before_id bigint  NOT NULL DEFAULT 0,
    ADD COLUMN hidden            boolean NOT NULL DEFAULT false;
CREATE INDEX chat_members_visible ON chat_members (user_id) WHERE NOT hidden;

ALTER TABLE messages ADD COLUMN kind text NOT NULL DEFAULT 'text' CHECK (kind IN ('text','poll'));
CREATE TABLE polls (
    id         bigserial PRIMARY KEY,
    chat_id    bigint NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    message_id bigint REFERENCES messages(id) ON DELETE CASCADE,
    question   text   NOT NULL,
    multiple   boolean NOT NULL DEFAULT false,
    created_by bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    closed_at  timestamptz,
    closed_by  bigint REFERENCES users(id) ON DELETE SET NULL
);
CREATE UNIQUE INDEX polls_message ON polls (message_id);
CREATE INDEX polls_chat ON polls (chat_id);
CREATE TABLE poll_options (
    id      bigserial PRIMARY KEY,
    poll_id bigint NOT NULL REFERENCES polls(id) ON DELETE CASCADE,
    text    text   NOT NULL,
    sort    int    NOT NULL DEFAULT 0
);
CREATE INDEX poll_options_poll ON poll_options (poll_id, sort, id);
CREATE TABLE poll_votes (
    poll_id   bigint NOT NULL REFERENCES polls(id) ON DELETE CASCADE,
    option_id bigint NOT NULL REFERENCES poll_options(id) ON DELETE CASCADE,
    user_id   bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    voted_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (poll_id, option_id, user_id)
);
CREATE INDEX poll_votes_user ON poll_votes (poll_id, user_id);

-- ---- календари --------------------------------------------------------------------
DELETE FROM calendars WHERE kind = 'rooms';
ALTER TABLE calendars DROP CONSTRAINT calendars_kind_check;
ALTER TABLE calendars ADD CONSTRAINT calendars_kind_check CHECK (kind IN ('personal','birthdays','conference','custom'));
CREATE UNIQUE INDEX calendars_personal_uq ON calendars (owner_id) WHERE kind = 'personal';
UPDATE calendars SET name = 'Мероприятия' WHERE name = 'Корпоративные мероприятия';
UPDATE categories SET name = 'Мероприятия' WHERE name = 'Корпоративные мероприятия';

-- повторяющиеся события (день города, день Победы и т.п.)
ALTER TABLE events
    ADD COLUMN rec_freq     text NOT NULL DEFAULT 'none' CHECK (rec_freq IN ('none','daily','weekly','monthly','yearly')),
    ADD COLUMN rec_interval int  NOT NULL DEFAULT 1 CHECK (rec_interval BETWEEN 1 AND 100),
    ADD COLUMN rec_until    timestamptz;
CREATE INDEX events_recurring ON events (starts_at) WHERE rec_freq <> 'none';
CREATE INDEX events_ends ON events (ends_at) WHERE rec_freq = 'none';

-- ---- баннеры на главной --------------------------------------------------------------
CREATE TABLE banners (
    id         bigserial PRIMARY KEY,
    title      text NOT NULL,
    text       text NOT NULL DEFAULT '',
    image      text NOT NULL DEFAULT '',
    video_url  text NOT NULL DEFAULT '',
    link       text NOT NULL DEFAULT '',      -- внутренний путь (/news/5, /groups/2 …) или https://…
    link_label text NOT NULL DEFAULT 'Подробнее',
    sort       int  NOT NULL DEFAULT 0,
    active     boolean NOT NULL DEFAULT true,
    starts_at  timestamptz,
    ends_at    timestamptz,
    created_by bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX banners_active ON banners (sort, id) WHERE active;

-- ---- график отпусков руководящего состава ----------------------------------------------
CREATE TABLE vacations (
    id         bigserial PRIMARY KEY,
    user_id    bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    starts_on  date   NOT NULL,
    ends_on    date   NOT NULL,
    deputy_id  bigint REFERENCES users(id) ON DELETE SET NULL,
    city       text   NOT NULL DEFAULT '',
    note       text   NOT NULL DEFAULT '',
    created_by bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (ends_on >= starts_on)
);
CREATE INDEX vacations_period ON vacations (ends_on, starts_on);
CREATE INDEX vacations_user ON vacations (user_id, starts_on DESC);

-- ---- «Есть идея» -----------------------------------------------------------------------
CREATE TABLE ideas (
    id             bigserial PRIMARY KEY,
    title          text NOT NULL,
    body           text NOT NULL DEFAULT '',
    author_id      bigint REFERENCES users(id) ON DELETE SET NULL,
    status         text NOT NULL DEFAULT 'new' CHECK (status IN ('new','review','accepted','done','declined')),
    likes_count    int NOT NULL DEFAULT 0,
    comments_count int NOT NULL DEFAULT 0,
    views_count    int NOT NULL DEFAULT 0,
    created_at     timestamptz NOT NULL DEFAULT now(),
    updated_at     timestamptz NOT NULL DEFAULT now(),
    search_simple  tsvector GENERATED ALWAYS AS (to_tsvector('simple', coalesce(title, '') || ' ' || coalesce(body, ''))) STORED
);
CREATE INDEX ideas_stream ON ideas (id DESC);
CREATE INDEX ideas_status ON ideas (status, id DESC);
CREATE INDEX ideas_popular ON ideas (likes_count DESC, id DESC);
CREATE INDEX ideas_author ON ideas (author_id, id DESC);
CREATE INDEX ideas_fts ON ideas USING gin (search_simple);
CREATE INDEX ideas_title_trgm ON ideas USING gin (lower(title) gin_trgm_ops);
CREATE INDEX departments_name_trgm ON departments USING gin (lower(name) gin_trgm_ops);
CREATE INDEX user_groups_name_trgm ON user_groups USING gin (lower(name) gin_trgm_ops);


-- ############################################################################
-- ## 005_ldap_multidc.sql
-- ############################################################################

-- 005: LDAP-источники, сессии и блокировки в PostgreSQL, outbox для realtime между ЦОДами

CREATE TABLE ldap_servers (
    id               bigserial PRIMARY KEY,
    name             text    NOT NULL,                 -- название в выпадающем списке на странице входа
    enabled          boolean NOT NULL DEFAULT true,
    url              text    NOT NULL,                 -- ldap://host:389 | ldaps://host:636
    start_tls        boolean NOT NULL DEFAULT false,
    skip_verify      boolean NOT NULL DEFAULT false,
    bind_dn          text    NOT NULL DEFAULT '',      -- сервисная учётка для поиска
    bind_password    text    NOT NULL DEFAULT '',      -- AES-GCM (ключ SECRET_KEY), в API не отдаётся
    base_dn          text    NOT NULL,
    user_filter      text    NOT NULL DEFAULT '(&(objectClass=person)(sAMAccountName=%s))', -- %s — логин
    sync_filter      text    NOT NULL DEFAULT '(&(objectClass=person)(sAMAccountName=*))',  -- кого загружать при синхронизации
    attr_login       text    NOT NULL DEFAULT 'sAMAccountName',
    attr_uid         text    NOT NULL DEFAULT 'objectGUID', -- неизменяемый идентификатор (для переименований)
    attr_first_name  text    NOT NULL DEFAULT 'givenName',
    attr_last_name   text    NOT NULL DEFAULT 'sn',
    attr_middle_name text    NOT NULL DEFAULT '',
    attr_email       text    NOT NULL DEFAULT 'mail',
    attr_title       text    NOT NULL DEFAULT 'title',
    attr_phone1      text    NOT NULL DEFAULT 'telephoneNumber',
    attr_phone2      text    NOT NULL DEFAULT 'mobile',
    attr_phone3      text    NOT NULL DEFAULT '',
    attr_phone4      text    NOT NULL DEFAULT '',
    attr_birthday    text    NOT NULL DEFAULT '',
    attr_department  text    NOT NULL DEFAULT 'department', -- сопоставляется с названием подразделения
    attr_disabled    text    NOT NULL DEFAULT 'userAccountControl', -- AD: бит 2 = учётка отключена
    default_role     text    NOT NULL DEFAULT 'user' CHECK (default_role IN ('user','editor')),
    auto_create      boolean NOT NULL DEFAULT true,     -- создавать пользователя при первом входе
    deactivate_missing boolean NOT NULL DEFAULT true,   -- блокировать тех, кого больше нет в каталоге
    sync_minutes     int     NOT NULL DEFAULT 0 CHECK (sync_minutes >= 0), -- 0 = только вручную
    sort             int     NOT NULL DEFAULT 0,
    last_sync_at     timestamptz,
    last_sync_status text    NOT NULL DEFAULT '',
    created_at       timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE users ADD COLUMN ldap_blocked boolean NOT NULL DEFAULT false; -- заблокирован синхронизацией (а не вручную)
ALTER TABLE users ADD CONSTRAINT users_ldap_fk FOREIGN KEY (ldap_server_id) REFERENCES ldap_servers(id) ON DELETE SET NULL;

-- Сессии в БД: работают между ЦОДами (Redis остаётся локальным кэшем каждого ЦОДа)
CREATE TABLE sessions (
    token      text PRIMARY KEY,
    user_id    bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    ip         text NOT NULL DEFAULT ''
);
CREATE INDEX sessions_user ON sessions (user_id);
CREATE INDEX sessions_expires ON sessions (expires_at);

-- Глобальные блокировки фоновых задач (работают в любом числе ЦОДов, т.к. живут в основной БД)
CREATE TABLE job_locks (
    name       text PRIMARY KEY,
    holder     text NOT NULL,
    locked_until timestamptz NOT NULL
);

-- Outbox для событий реального времени между ЦОДами.
-- Пишется в основную БД; читается каждым экземпляром со своей реплики.
-- xid — номер транзакции: читаем только строки, чьи транзакции уже завершены (см. hub_pg.go).
CREATE TABLE realtime_events (
    id         bigserial PRIMARY KEY,
    xid        bigint NOT NULL DEFAULT (pg_current_xact_id()::text::bigint),
    topic      text   NOT NULL,
    payload    text   NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX realtime_events_pos ON realtime_events (xid, id);
CREATE INDEX realtime_events_created ON realtime_events (created_at);


-- ############################################################################
-- ## 006_media_misc.sql
-- ############################################################################

-- 006: размеры изображений (оригинал / просмотр / превью), идеи без статуса «рассмотрение», индексы для доступа к фото из новостей

-- имя файла «просмотра» (<имя>.v.jpg, ширина 1728 px); пусто — отдаётся оригинал
ALTER TABLE files ADD COLUMN view text NOT NULL DEFAULT '';

-- статус идеи «review» убран
ALTER TABLE ideas DROP CONSTRAINT IF EXISTS ideas_status_check;
UPDATE ideas SET status = 'new' WHERE status = 'review';
ALTER TABLE ideas ADD CONSTRAINT ideas_status_check CHECK (status IN ('new','accepted','done','declined'));


-- ############################################################################
-- ## 007_learning.sql
-- ############################################################################

-- 007: раздел «Обучение» — материалы (папки, права, файлы, прогресс) и тесты (вопросы, попытки)

-- вложения материалов и картинки вопросов хранятся в files с context = 'learning'
DO $$
DECLARE d text;
BEGIN
    SELECT pg_get_constraintdef(oid) INTO d FROM pg_constraint WHERE conrelid = 'files'::regclass AND conname = 'files_context_check';
    IF d IS NOT NULL AND d NOT LIKE '%''learning''%' THEN
        ALTER TABLE files DROP CONSTRAINT files_context_check;
        EXECUTE 'ALTER TABLE files ADD CONSTRAINT files_context_check ' || replace(d, '''comment''::text', '''comment''::text, ''learning''::text');
    END IF;
END $$;

-- ---- папки (общие для материалов и тестов; дерево любой вложенности) ------------------------------
CREATE TABLE learn_folders (
    id          bigserial PRIMARY KEY,
    kind        text   NOT NULL CHECK (kind IN ('materials', 'tests')),
    parent_id   bigint REFERENCES learn_folders(id) ON DELETE CASCADE,
    name        text   NOT NULL,
    description text   NOT NULL DEFAULT '',
    visibility  text   NOT NULL DEFAULT 'company' CHECK (visibility IN ('company', 'restricted')),
    owner_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    sort        int    NOT NULL DEFAULT 0,
    items_count int    NOT NULL DEFAULT 0,   -- материалов / тестов прямо в папке (поддерживается триггером)
    pub_count   int    NOT NULL DEFAULT 0,   -- из них видимых всем (опубликованные тесты)
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX learn_folders_parent ON learn_folders (kind, parent_id, sort, lower(name));
CREATE INDEX learn_folders_parent_id ON learn_folders (parent_id);
CREATE INDEX learn_folders_owner ON learn_folders (owner_id) WHERE owner_id IS NOT NULL;

-- права на папку: уровень 1 просмотр, 3 редактирование (материалы, тесты, результаты), 4 управление (права, удаление)
-- действуют на всю поддерево; для подразделений — на сотрудников подразделения и всех дочерних
CREATE TABLE learn_acl (
    folder_id    bigint   NOT NULL REFERENCES learn_folders(id) ON DELETE CASCADE,
    subject_type text     NOT NULL CHECK (subject_type IN ('user', 'department')),
    subject_id   bigint   NOT NULL,
    level        smallint NOT NULL CHECK (level BETWEEN 1 AND 4),
    PRIMARY KEY (folder_id, subject_type, subject_id)
);
CREATE INDEX learn_acl_subject ON learn_acl (subject_type, subject_id);

-- Эффективный уровень доступа пользователя к папке (0 — нет доступа).
--   • администратор — 4;
--   • «ограниченная» папка задаёт свой список доступа для себя и всех вложенных «общих» папок
--     (ближайшая ограниченная папка вверх по цепочке); если такой нет — видно всем (уровень 1);
--   • права редактирования/управления (>=3) и владение папкой передаются вниз по всему поддереву.
CREATE FUNCTION learn_level(fid bigint, uid bigint, dept bigint, adm boolean) RETURNS int
LANGUAGE sql STABLE AS $$
WITH RECURSIVE up AS (
    SELECT id, parent_id, visibility, owner_id, 0 AS d FROM learn_folders WHERE id = fid
    UNION ALL
    SELECT p.id, p.parent_id, p.visibility, p.owner_id, up.d + 1 FROM learn_folders p JOIN up ON p.id = up.parent_id
), dc AS (
    SELECT id, parent_id FROM departments WHERE id = dept
    UNION ALL
    SELECT x.id, x.parent_id FROM departments x JOIN dc ON x.id = dc.parent_id
), n AS (
    SELECT up.d, up.visibility, greatest(
        coalesce((SELECT max(a.level) FROM learn_acl a WHERE a.folder_id = up.id AND
            ((a.subject_type = 'user' AND a.subject_id = uid) OR (a.subject_type = 'department' AND a.subject_id IN (SELECT id FROM dc)))), 0),
        CASE WHEN up.owner_id = uid THEN 4 ELSE 0 END) AS own
    FROM up
)
SELECT CASE WHEN NOT EXISTS (SELECT 1 FROM up) THEN 0
            WHEN adm THEN 4
            ELSE greatest(coalesce((SELECT max(own) FROM n WHERE own >= 3), 0),
                          coalesce((SELECT own FROM n WHERE visibility = 'restricted' ORDER BY d LIMIT 1), 1)) END
$$;

-- ---- материалы -----------------------------------------------------------------------------------
CREATE TABLE learn_items (
    id          bigserial PRIMARY KEY,
    folder_id   bigint NOT NULL REFERENCES learn_folders(id) ON DELETE CASCADE,
    kind        text   NOT NULL DEFAULT 'text' CHECK (kind IN ('text', 'file', 'video', 'link')),
    title       text   NOT NULL,
    description text   NOT NULL DEFAULT '',
    body        text   NOT NULL DEFAULT '',       -- markdown
    url         text   NOT NULL DEFAULT '',       -- внешняя ссылка / видео по ссылке
    tags        text[] NOT NULL DEFAULT '{}',
    sort        int    NOT NULL DEFAULT 0,
    views_count int    NOT NULL DEFAULT 0,
    author_id   bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX learn_items_folder ON learn_items (folder_id, sort, id);
CREATE INDEX learn_items_folder_new ON learn_items (folder_id, id DESC);
CREATE INDEX learn_items_folder_title ON learn_items (folder_id, lower(title), id);
CREATE INDEX learn_items_title_trgm ON learn_items USING gin (lower(title) gin_trgm_ops);
CREATE INDEX learn_items_title_c ON learn_items ((lower(title) COLLATE "C"), id);   -- короткий поиск: префикс + порядок по индексу
CREATE INDEX learn_items_tags ON learn_items USING gin (tags);

CREATE TABLE learn_item_files (
    item_id bigint NOT NULL REFERENCES learn_items(id) ON DELETE CASCADE,
    file_id bigint NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    sort    int    NOT NULL DEFAULT 0,
    PRIMARY KEY (item_id, file_id)
);
CREATE INDEX learn_item_files_file ON learn_item_files (file_id);

-- прогресс пользователя: когда открывал, когда отметил «изучено»
CREATE TABLE learn_progress (
    user_id   bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    item_id   bigint NOT NULL REFERENCES learn_items(id) ON DELETE CASCADE,
    folder_id bigint NOT NULL,
    opened_at timestamptz NOT NULL DEFAULT now(),
    done_at   timestamptz,
    PRIMARY KEY (user_id, item_id)
);
CREATE INDEX learn_progress_recent ON learn_progress (user_id, opened_at DESC);
CREATE INDEX learn_progress_done ON learn_progress (user_id, folder_id) WHERE done_at IS NOT NULL;
CREATE INDEX learn_progress_item ON learn_progress (item_id);

-- ---- тесты ---------------------------------------------------------------------------------------
CREATE TABLE learn_tests (
    id                bigserial PRIMARY KEY,
    folder_id         bigint NOT NULL REFERENCES learn_folders(id) ON DELETE CASCADE,
    title             text   NOT NULL,
    description       text   NOT NULL DEFAULT '',
    status            text   NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
    pass_percent      int    NOT NULL DEFAULT 70 CHECK (pass_percent BETWEEN 0 AND 100),
    time_limit_min    int    CHECK (time_limit_min IS NULL OR time_limit_min > 0),
    max_attempts      int    CHECK (max_attempts IS NULL OR max_attempts > 0),
    shuffle_questions boolean NOT NULL DEFAULT false,
    shuffle_answers   boolean NOT NULL DEFAULT false,
    partial_credit    boolean NOT NULL DEFAULT false,   -- частичные баллы в вопросах с несколькими ответами
    show_answers      text   NOT NULL DEFAULT 'after_attempt' CHECK (show_answers IN ('never', 'after_attempt', 'after_finish')),
    available_from    timestamptz,
    available_to      timestamptz,
    sort              int    NOT NULL DEFAULT 0,
    questions_count   int    NOT NULL DEFAULT 0,
    max_score         numeric(8,2) NOT NULL DEFAULT 0,
    attempts_count    int    NOT NULL DEFAULT 0,        -- завершённых попыток
    passed_count      int    NOT NULL DEFAULT 0,
    sum_percent       double precision NOT NULL DEFAULT 0,
    author_id         bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX learn_tests_folder ON learn_tests (folder_id, sort, id);
CREATE INDEX learn_tests_title_trgm ON learn_tests USING gin (lower(title) gin_trgm_ops);
CREATE INDEX learn_tests_title_c ON learn_tests ((lower(title) COLLATE "C"), id);

CREATE TABLE learn_questions (
    id          bigserial PRIMARY KEY,
    test_id     bigint NOT NULL REFERENCES learn_tests(id) ON DELETE CASCADE,
    sort        int    NOT NULL DEFAULT 0,
    type        text   NOT NULL CHECK (type IN ('single', 'multiple', 'text')),
    text        text   NOT NULL,
    file_id     bigint REFERENCES files(id) ON DELETE SET NULL,
    data        jsonb  NOT NULL DEFAULT '{}',    -- {"options":[{"id":1,"text":"…","correct":true}]} | {"answers":["…"]}
    weight      numeric(6,2) NOT NULL DEFAULT 1 CHECK (weight > 0),
    explanation text   NOT NULL DEFAULT ''
);
CREATE INDEX learn_questions_test ON learn_questions (test_id, sort, id);
CREATE INDEX learn_questions_file ON learn_questions (file_id) WHERE file_id IS NOT NULL;

-- попытка: ответы и результат по вопросам лежат компактно в jsonb одной строки
CREATE TABLE learn_attempts (
    id           bigserial PRIMARY KEY,
    test_id      bigint NOT NULL REFERENCES learn_tests(id) ON DELETE CASCADE,
    user_id      bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    dept_id      bigint,                              -- подразделение пользователя на момент попытки
    no           int    NOT NULL,                     -- номер попытки пользователя в тесте
    seed         bigint NOT NULL,                     -- из него детерминированно строится порядок вопросов/ответов
    started_at   timestamptz NOT NULL DEFAULT now(),
    deadline     timestamptz,
    finished_at  timestamptz,
    expired      boolean NOT NULL DEFAULT false,      -- завершена по истечении времени
    answers      jsonb  NOT NULL DEFAULT '{}',        -- {"<id вопроса>": 3 | [1,2] | "текст"}
    details      jsonb,                               -- {"<id вопроса>": {"p": баллы, "m": максимум, "s": 0|1|2}}
    score        numeric(8,2),
    max_score    numeric(8,2),
    percent      numeric(5,1),
    passed       boolean,
    duration_sec int
);
CREATE UNIQUE INDEX learn_attempts_no ON learn_attempts (test_id, user_id, no);
CREATE UNIQUE INDEX learn_attempts_open ON learn_attempts (test_id, user_id) WHERE finished_at IS NULL;
CREATE INDEX learn_attempts_user ON learn_attempts (user_id, started_at DESC);
CREATE INDEX learn_attempts_test_done ON learn_attempts (test_id, finished_at DESC) WHERE finished_at IS NOT NULL;
CREATE INDEX learn_attempts_deadline ON learn_attempts (deadline) WHERE finished_at IS NULL AND deadline IS NOT NULL;

-- счётчики материалов/тестов в папке (items_count — всего, pub_count — видимых всем)
CREATE FUNCTION learn_count_items() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP = 'UPDATE' AND OLD.folder_id = NEW.folder_id THEN RETURN NULL; END IF;
    IF TG_OP IN ('DELETE', 'UPDATE') THEN
        UPDATE learn_folders SET items_count = items_count - 1, pub_count = pub_count - 1 WHERE id = OLD.folder_id;
    END IF;
    IF TG_OP IN ('INSERT', 'UPDATE') THEN
        UPDATE learn_folders SET items_count = items_count + 1, pub_count = pub_count + 1 WHERE id = NEW.folder_id;
    END IF;
    RETURN NULL;
END $$;
CREATE TRIGGER learn_items_cnt AFTER INSERT OR DELETE OR UPDATE OF folder_id ON learn_items FOR EACH ROW EXECUTE FUNCTION learn_count_items();

CREATE FUNCTION learn_count_tests() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE pn int := 0; po int := 0;
BEGIN
    IF TG_OP IN ('INSERT', 'UPDATE') AND NEW.status = 'published' THEN pn := 1; END IF;
    IF TG_OP IN ('DELETE', 'UPDATE') AND OLD.status = 'published' THEN po := 1; END IF;
    IF TG_OP = 'UPDATE' AND OLD.folder_id = NEW.folder_id AND pn = po THEN RETURN NULL; END IF;
    IF TG_OP IN ('DELETE', 'UPDATE') THEN
        UPDATE learn_folders SET items_count = items_count - 1, pub_count = pub_count - po WHERE id = OLD.folder_id;
    END IF;
    IF TG_OP IN ('INSERT', 'UPDATE') THEN
        UPDATE learn_folders SET items_count = items_count + 1, pub_count = pub_count + pn WHERE id = NEW.folder_id;
    END IF;
    RETURN NULL;
END $$;
CREATE TRIGGER learn_tests_cnt AFTER INSERT OR DELETE OR UPDATE OF folder_id, status ON learn_tests FOR EACH ROW EXECUTE FUNCTION learn_count_tests();

-- доступ к файлу обучения: владелец загрузки, вложение видимого материала, картинка вопроса доступного теста
CREATE FUNCTION learn_file_ok(fid bigint, uid bigint, dept bigint, adm boolean) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT adm
    OR EXISTS (SELECT 1 FROM files f WHERE f.id = fid AND f.owner_id = uid)
    OR EXISTS (SELECT 1 FROM learn_item_files lf JOIN learn_items i ON i.id = lf.item_id
               WHERE lf.file_id = fid AND learn_level(i.folder_id, uid, dept, adm) > 0)
    OR EXISTS (SELECT 1 FROM learn_questions q JOIN learn_tests t ON t.id = q.test_id
               WHERE q.file_id = fid AND (learn_level(t.folder_id, uid, dept, adm) >= 3
                  OR (t.status = 'published' AND learn_level(t.folder_id, uid, dept, adm) > 0)))
$$;


-- ############################################################################
-- ## 008_ui_misc.sql
-- ############################################################################

-- 008: «Есть идея» без статусов. Колонка ideas.status оставлена для совместимости, но нигде не используется.
DROP INDEX IF EXISTS ideas_status;
-- «Телефон 4» → «Видеотелефон»: колонка users.phone4 не переименовывается (внутреннее имя), меняются только подписи.

-- Поиск людей: в строку поиска добавляются телефоны (в т. ч. «Видеотелефон»).
DROP INDEX IF EXISTS users_search_trgm;
ALTER TABLE users DROP COLUMN search_text;
ALTER TABLE users ADD COLUMN search_text text GENERATED ALWAYS AS (
    lower(last_name || ' ' || first_name || ' ' || middle_name || ' ' || login || ' ' || email || ' ' || job_title || ' ' ||
          phone1 || ' ' || phone2 || ' ' || phone3 || ' ' || phone4)) STORED;
CREATE INDEX users_search_trgm ON users USING gin (search_text gin_trgm_ops);


-- ############################################################################
-- ## 009_social.sql
-- ############################################################################

-- 009: смайлы/реакции, закладки, упоминания @.

-- ---- реакции -----------------------------------------------------------------
-- entity_type: news | idea | post | comment | message (список расширяемый: registerReactionTarget в Go; CHECK не ставим).
-- emoji: юникод-эмодзи либо шорткод анимированного стикера «:имя:».
CREATE TABLE reactions (
    entity_type text   NOT NULL,
    entity_id   bigint NOT NULL,
    user_id     bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    emoji       text   NOT NULL CHECK (char_length(emoji) BETWEEN 1 AND 48),
    created_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (entity_type, entity_id, user_id, emoji)
);
-- агрегаты страницы списка (count по emoji + «моя») читаются index-only; PK ведёт список «кто поставил»
CREATE INDEX reactions_entity ON reactions (entity_type, entity_id) INCLUDE (emoji, user_id);
CREATE INDEX reactions_user ON reactions (user_id);

-- Лайки становятся реакцией 👍. Счётчики likes_count (новости/идеи/посты) остаются денормализованным числом именно 👍:
-- по нему сортируется «популярные идеи» (keyset), а карточки ленты не делают агрегат на каждую новость.
INSERT INTO reactions (entity_type, entity_id, user_id, emoji, created_at)
    SELECT entity_type, entity_id, user_id, '👍', created_at FROM likes ON CONFLICT DO NOTHING;
UPDATE news n SET likes_count = c.n FROM (SELECT entity_id, count(*)::int AS n FROM reactions WHERE entity_type = 'news' AND emoji = '👍' GROUP BY 1) c
    WHERE c.entity_id = n.id AND n.likes_count <> c.n;
UPDATE ideas n SET likes_count = c.n FROM (SELECT entity_id, count(*)::int AS n FROM reactions WHERE entity_type = 'idea' AND emoji = '👍' GROUP BY 1) c
    WHERE c.entity_id = n.id AND n.likes_count <> c.n;
UPDATE group_posts n SET likes_count = c.n FROM (SELECT entity_id, count(*)::int AS n FROM reactions WHERE entity_type = 'post' AND emoji = '👍' GROUP BY 1) c
    WHERE c.entity_id = n.id AND n.likes_count <> c.n;
DROP TABLE likes;

-- ---- закладки -----------------------------------------------------------------
-- entity_type: news | idea | file | post | event | message | learn_item | wiki_page | … (резолверы регистрируются в Go)
CREATE TABLE bookmarks (
    user_id     bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    entity_type text   NOT NULL,
    entity_id   bigint NOT NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    note        text NOT NULL DEFAULT '' CHECK (char_length(note) <= 500),
    PRIMARY KEY (user_id, entity_type, entity_id)
);
CREATE INDEX bookmarks_user_time ON bookmarks (user_id, created_at DESC);
CREATE INDEX bookmarks_entity ON bookmarks (entity_type, entity_id);

-- ---- упоминания @логин ----------------------------------------------------------
-- entity_type: comment | message | post | idea. Строка = «пользователь уже уведомлён об упоминании в этом объекте» (без дублей при правке).
CREATE TABLE mentions (
    entity_type text   NOT NULL,
    entity_id   bigint NOT NULL,
    user_id     bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (entity_type, entity_id, user_id)
);
CREATE INDEX mentions_user ON mentions (user_id, created_at DESC);

-- быстрый префиксный поиск логина/имени для автодополнения (lower(...) LIKE 'abc%' при любой локали)
CREATE INDEX users_login_prefix ON users (lower(login) text_pattern_ops);
CREATE INDEX users_first_prefix ON users (lower(first_name) text_pattern_ops);

-- ---- уборка при удалении объектов (в т.ч. каскадом) ----------------------------------
CREATE FUNCTION social_cleanup() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM reactions WHERE entity_type = TG_ARGV[0] AND entity_id = OLD.id;
    DELETE FROM bookmarks WHERE entity_type = TG_ARGV[0] AND entity_id = OLD.id;
    DELETE FROM mentions  WHERE entity_type = TG_ARGV[0] AND entity_id = OLD.id;
    RETURN NULL;
END $$;
CREATE FUNCTION social_cleanup_bm() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM bookmarks WHERE entity_type = TG_ARGV[0] AND entity_id = OLD.id;
    RETURN NULL;
END $$;
CREATE TRIGGER news_social_del     AFTER DELETE ON news        FOR EACH ROW EXECUTE FUNCTION social_cleanup('news');
CREATE TRIGGER ideas_social_del    AFTER DELETE ON ideas       FOR EACH ROW EXECUTE FUNCTION social_cleanup('idea');
CREATE TRIGGER posts_social_del    AFTER DELETE ON group_posts FOR EACH ROW EXECUTE FUNCTION social_cleanup('post');
CREATE TRIGGER comments_social_del AFTER DELETE ON comments    FOR EACH ROW EXECUTE FUNCTION social_cleanup('comment');
CREATE TRIGGER messages_social_del AFTER DELETE ON messages    FOR EACH ROW EXECUTE FUNCTION social_cleanup('message');
CREATE TRIGGER events_social_del   AFTER DELETE ON events      FOR EACH ROW EXECUTE FUNCTION social_cleanup_bm('event');
CREATE TRIGGER files_social_del    AFTER DELETE ON files       FOR EACH ROW EXECUTE FUNCTION social_cleanup_bm('file');
CREATE TRIGGER learn_items_social_del AFTER DELETE ON learn_items FOR EACH ROW EXECUTE FUNCTION social_cleanup_bm('learn_item');


-- ############################################################################
-- ## 010_file_search.sql
-- ############################################################################

-- 010: полнотекстовый поиск по содержимому файлов.
-- file_texts — очередь извлечения текста и сам индекс: одна строка на файл (files.id). Воркер (filesearch.go) берёт
-- пачки через FOR UPDATE SKIP LOCKED, поэтому любое число экземпляров/ЦОДов работает без дублей.
-- Конфигурация 'simple' (без стемминга), как и поиск по новостям; запросы — префиксные (слово:*).
CREATE TABLE file_texts (
    file_id      bigint PRIMARY KEY REFERENCES files(id) ON DELETE CASCADE,
    status       text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','done','failed','unsupported')),
    text         text NOT NULL DEFAULT '',            -- извлечённый текст (до ~1 МБ), нужен для сниппетов ts_headline
    tsv          tsvector,                            -- to_tsvector('simple', text); NULL, пока текста нет
    size         int NOT NULL DEFAULT 0,              -- длина text в байтах
    attempts     int NOT NULL DEFAULT 0,
    next_try_at  timestamptz NOT NULL DEFAULT now(),  -- не раньше (ретраи с backoff)
    locked_until timestamptz,                         -- аренда задачи воркером (защита от падения посреди работы)
    extracted_at timestamptz,
    error        text NOT NULL DEFAULT ''
);
CREATE INDEX file_texts_tsv ON file_texts USING gin (tsv);
CREATE INDEX file_texts_queue ON file_texts (next_try_at, file_id) WHERE status = 'pending';
CREATE INDEX file_texts_failed ON file_texts (file_id DESC) WHERE status = 'failed';

-- любой новый файл (документы, вложения новостей/комментариев/чатов, обучение, галереи …) попадает в очередь;
-- изображения/видео/аудио сразу помечаются как не поддерживаемые (в них нечего извлекать)
CREATE FUNCTION file_texts_enqueue() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.storage <> '' AND NEW.external_url = '' THEN
        INSERT INTO file_texts (file_id, status)
        VALUES (NEW.id, CASE WHEN NEW.mime LIKE 'image/%' OR NEW.mime LIKE 'video/%' OR NEW.mime LIKE 'audio/%' THEN 'unsupported' ELSE 'pending' END)
        ON CONFLICT (file_id) DO NOTHING;
    END IF;
    RETURN NULL;
END $$;
CREATE TRIGGER files_enqueue_text AFTER INSERT ON files FOR EACH ROW EXECUTE FUNCTION file_texts_enqueue();


-- ############################################################################
-- ## 011_requests.sql
-- ############################################################################

-- 011: раздел «Заявки» — конструктор форм (типы, версии схем, маршруты согласования), заявки, шаги, исполнители, журнал.
--
-- Модель:
--   req_types          тип заявки (метаданные, маска нумерации, SLA по умолчанию, область: подразделение-владелец)
--   req_type_versions  НЕИЗМЕНЯЕМЫЕ версии схемы формы и маршрута; заявка ссылается на версию, на которую подана (снимок)
--   req_acl            кто подаёт / владеет (редактирует тип) / ответственные / наблюдатели (subject: все, пользователь, подразделение
--                      с наследованием вниз, группа, роль)
--   req_counters       независимые счётчики нумерации (type_id, период) — инкремент атомарным UPDATE … RETURNING
--   req_requests       заявки; req_steps — активированные шаги маршрута; req_assignees — исполнители шагов («на мне»)
--   req_events         журнал: решения, комментарии, переходы; req_files — вложения заявки и комментариев

-- вложения заявок хранятся в files с context = 'request'
DO $$
DECLARE d text;
BEGIN
    SELECT pg_get_constraintdef(oid) INTO d FROM pg_constraint WHERE conrelid = 'files'::regclass AND conname = 'files_context_check';
    IF d IS NOT NULL AND d NOT LIKE '%''request''%' THEN
        ALTER TABLE files DROP CONSTRAINT files_context_check;
        EXECUTE 'ALTER TABLE files ADD CONSTRAINT files_context_check ' || replace(d, '''comment''::text', '''comment''::text, ''request''::text');
    END IF;
END $$;

CREATE TABLE req_categories (
    id         bigserial PRIMARY KEY,
    name       text NOT NULL,
    icon       text NOT NULL DEFAULT 'file',
    color      text NOT NULL DEFAULT '#286b9e',
    sort       int  NOT NULL DEFAULT 0,
    created_by bigint REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE req_types (
    id            bigserial PRIMARY KEY,
    category_id   bigint REFERENCES req_categories(id) ON DELETE SET NULL,
    code          text   NOT NULL DEFAULT '',
    name          text   NOT NULL,
    description   text   NOT NULL DEFAULT '',        -- markdown
    icon          text   NOT NULL DEFAULT 'file',
    color         text   NOT NULL DEFAULT '#286b9e',
    number_mask   text   NOT NULL DEFAULT 'ЗАЯ-{YYYY}-{NNNNNN}',
    sla_value     int    NOT NULL DEFAULT 0 CHECK (sla_value >= 0),     -- SLA шага по умолчанию (0 — без срока)
    sla_unit      text   NOT NULL DEFAULT 'wd' CHECK (sla_unit IN ('h', 'wh', 'd', 'wd')),
    remind_before_h int  NOT NULL DEFAULT 4 CHECK (remind_before_h >= 0),
    active        boolean NOT NULL DEFAULT true,      -- опубликован: можно подавать
    archived      boolean NOT NULL DEFAULT false,
    department_id bigint REFERENCES departments(id) ON DELETE SET NULL,   -- область редакторов (scope.go)
    created_by    bigint REFERENCES users(id) ON DELETE SET NULL,
    cur_version   bigint,
    sort          int    NOT NULL DEFAULT 0,
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX req_types_cat ON req_types (category_id, sort, lower(name)) WHERE NOT archived;
CREATE INDEX req_types_dept ON req_types (department_id) WHERE department_id IS NOT NULL;
CREATE INDEX req_types_creator ON req_types (created_by);

CREATE TABLE req_type_versions (
    id         bigserial PRIMARY KEY,
    type_id    bigint NOT NULL REFERENCES req_types(id) ON DELETE CASCADE,
    version    int    NOT NULL,
    schema     jsonb  NOT NULL,
    workflow   jsonb  NOT NULL,
    note       text   NOT NULL DEFAULT '',
    created_by bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (type_id, version)
);
ALTER TABLE req_types ADD CONSTRAINT req_types_cur_version_fk FOREIGN KEY (cur_version) REFERENCES req_type_versions(id) DEFERRABLE INITIALLY DEFERRED;

-- kind: submit — кто подаёт; owner — кто редактирует тип; responsible — ответственные (видят все заявки, исполнители шагов
-- «ответственные типа»); watcher — наблюдатели (видят все заявки типа).
-- subject_type: all | user | department (со всеми дочерними) | group | role (subject_key: admin|editor|user|head)
CREATE TABLE req_acl (
    type_id      bigint NOT NULL REFERENCES req_types(id) ON DELETE CASCADE,
    kind         text   NOT NULL CHECK (kind IN ('submit', 'owner', 'responsible', 'watcher')),
    subject_type text   NOT NULL CHECK (subject_type IN ('all', 'user', 'department', 'group', 'role')),
    subject_id   bigint NOT NULL DEFAULT 0,
    subject_key  text   NOT NULL DEFAULT '',
    PRIMARY KEY (type_id, kind, subject_type, subject_id, subject_key)
);
CREATE INDEX req_acl_user ON req_acl (subject_type, subject_id) WHERE subject_type <> 'all';

CREATE TABLE req_counters (
    type_id bigint NOT NULL REFERENCES req_types(id) ON DELETE CASCADE,
    period  text   NOT NULL DEFAULT '',
    value   bigint NOT NULL DEFAULT 0,
    PRIMARY KEY (type_id, period)
);

CREATE TABLE req_requests (
    id           bigserial PRIMARY KEY,
    type_id      bigint NOT NULL REFERENCES req_types(id) ON DELETE RESTRICT,
    version_id   bigint NOT NULL REFERENCES req_type_versions(id) ON DELETE RESTRICT,
    number       text,                         -- присваивается при подаче (у черновика нет)
    client_id    text,                         -- идемпотентность подачи (двойной клик)
    author_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    dept_id      bigint,                       -- подразделение заявителя на момент подачи
    status       text   NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'pending', 'rework', 'rejected', 'approved', 'in_progress', 'done', 'cancelled')),
    title        text   NOT NULL DEFAULT '',
    search_text  text   NOT NULL DEFAULT '',
    data         jsonb  NOT NULL DEFAULT '{}',
    cur_step     int    NOT NULL DEFAULT -1,   -- индекс шага маршрута (по версии)
    round        int    NOT NULL DEFAULT 1,    -- номер круга согласования (растёт после доработки)
    decisions    int    NOT NULL DEFAULT 0,    -- решений согласующих/исполнителей (отмена заявителем — только при 0)
    info_by      bigint,                       -- кто запросил информацию у заявителя (ожидается ответ)
    due_at       timestamptz,
    created_at   timestamptz NOT NULL DEFAULT now(),
    submitted_at timestamptz,
    updated_at   timestamptz NOT NULL DEFAULT now(),
    closed_at    timestamptz
);
CREATE UNIQUE INDEX req_requests_number ON req_requests (number) WHERE number IS NOT NULL;
CREATE UNIQUE INDEX req_requests_client ON req_requests (author_id, client_id) WHERE client_id IS NOT NULL;
CREATE INDEX req_requests_type_status ON req_requests (type_id, status, created_at DESC, id DESC);
CREATE INDEX req_requests_type_created ON req_requests (type_id, created_at DESC, id DESC);
CREATE INDEX req_requests_author ON req_requests (author_id, created_at DESC, id DESC) INCLUDE (status, type_id);
CREATE INDEX req_requests_version ON req_requests (version_id);
CREATE INDEX req_requests_search ON req_requests USING gin (search_text gin_trgm_ops);

CREATE TABLE req_steps (
    id          bigserial PRIMARY KEY,
    request_id  bigint NOT NULL REFERENCES req_requests(id) ON DELETE CASCADE,
    idx         int    NOT NULL,
    round       int    NOT NULL DEFAULT 1,
    key         text   NOT NULL DEFAULT '',
    name        text   NOT NULL,
    kind        text   NOT NULL CHECK (kind IN ('approve', 'execute', 'inform')),
    state       text   NOT NULL DEFAULT 'active' CHECK (state IN ('active', 'done', 'rejected', 'returned', 'skipped')),
    started_at  timestamptz NOT NULL DEFAULT now(),
    finished_at timestamptz
);
CREATE INDEX req_steps_req ON req_steps (request_id, round, idx);

CREATE TABLE req_assignees (
    id              bigserial PRIMARY KEY,
    request_id      bigint NOT NULL REFERENCES req_requests(id) ON DELETE CASCADE,
    step_id         bigint NOT NULL REFERENCES req_steps(id) ON DELETE CASCADE,
    branch          smallint NOT NULL DEFAULT 0,
    mode            text   NOT NULL DEFAULT 'any' CHECK (mode IN ('any', 'all', 'majority')),
    user_id         bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    state           text   NOT NULL DEFAULT 'pending' CHECK (state IN ('pending', 'approved', 'rejected', 'done', 'acked', 'returned', 'skipped', 'delegated')),
    via             text   NOT NULL DEFAULT 'direct',     -- direct | deputy | fallback | delegate | escalation | assigned
    orig_user_id    bigint,                                -- кого замещает / кто передал
    due_at          timestamptz,
    remind_at       timestamptz,
    remind_sent_at  timestamptz,
    overdue_sent_at timestamptz,
    escalated_at    timestamptz,
    esc_to          jsonb,                                 -- правило эскалации шага (копия)
    decided_at      timestamptz,
    comment         text   NOT NULL DEFAULT '',
    created_at      timestamptz NOT NULL DEFAULT now(),
    UNIQUE (step_id, user_id)
);
-- «На мне»: только ожидающие решения — индекс крошечный даже при миллионах заявок
CREATE INDEX req_assignees_inbox ON req_assignees (user_id, due_at NULLS LAST, request_id) WHERE state = 'pending';
CREATE INDEX req_assignees_user ON req_assignees (user_id, request_id DESC);
CREATE INDEX req_assignees_req ON req_assignees (request_id);
CREATE INDEX req_assignees_step ON req_assignees (step_id);
CREATE INDEX req_assignees_remind ON req_assignees (remind_at) WHERE state = 'pending' AND remind_sent_at IS NULL AND remind_at IS NOT NULL;
CREATE INDEX req_assignees_overdue ON req_assignees (due_at) WHERE state = 'pending' AND overdue_sent_at IS NULL AND due_at IS NOT NULL;

CREATE TABLE req_events (
    id         bigserial PRIMARY KEY,
    request_id bigint NOT NULL REFERENCES req_requests(id) ON DELETE CASCADE,
    step_id    bigint,
    actor_id   bigint REFERENCES users(id) ON DELETE SET NULL,
    kind       text   NOT NULL,
    text       text   NOT NULL DEFAULT '',
    data       jsonb  NOT NULL DEFAULT '{}',
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX req_events_req ON req_events (request_id, id);

CREATE TABLE req_files (
    file_id    bigint PRIMARY KEY REFERENCES files(id) ON DELETE CASCADE,
    request_id bigint NOT NULL REFERENCES req_requests(id) ON DELETE CASCADE,
    event_id   bigint REFERENCES req_events(id) ON DELETE CASCADE,
    field_key  text   NOT NULL DEFAULT ''
);
CREATE INDEX req_files_req ON req_files (request_id);

-- ---- права ----------------------------------------------------------------------------------------------------

-- пользователь uid входит в список k типа tid (подразделения — с наследованием вниз: достаточно, чтобы подразделение
-- пользователя лежало в поддереве указанного)
CREATE FUNCTION req_in_acl(tid bigint, k text, uid bigint) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT EXISTS (
    SELECT 1 FROM req_acl a, users u
    WHERE a.type_id = tid AND a.kind = k AND u.id = uid AND NOT u.blocked AND (
        a.subject_type = 'all'
        OR (a.subject_type = 'user' AND a.subject_id = uid)
        OR (a.subject_type = 'role' AND (a.subject_key = u.role OR (a.subject_key = 'head' AND u.is_head)))
        OR (a.subject_type = 'group' AND EXISTS (SELECT 1 FROM group_members m WHERE m.group_id = a.subject_id AND m.user_id = uid AND m.role <> 'pending'))
        OR (a.subject_type = 'department' AND u.department_id IS NOT NULL AND EXISTS (
            WITH RECURSIVE up AS (SELECT id, parent_id FROM departments WHERE id = u.department_id
                                  UNION ALL SELECT d.id, d.parent_id FROM departments d JOIN up ON d.id = up.parent_id)
            SELECT 1 FROM up WHERE up.id = a.subject_id))
    ))
$$;

-- заявку видит: автор; ответственные и наблюдатели типа; исполнители, на чей шаг она приходила; администратор (кроме чужих черновиков)
CREATE FUNCTION req_can_view(rid bigint, uid bigint, adm boolean) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT EXISTS (SELECT 1 FROM req_requests r WHERE r.id = rid AND (
    r.author_id = uid
    OR (r.status <> 'draft' AND (adm
        OR EXISTS (SELECT 1 FROM req_assignees a WHERE a.request_id = r.id AND a.user_id = uid)
        OR req_in_acl(r.type_id, 'responsible', uid) OR req_in_acl(r.type_id, 'watcher', uid)))))
$$;

-- доступ к файлу заявки: загрузивший; либо файл привязан к заявке, которую пользователь вправе видеть
CREATE FUNCTION req_file_ok(fid bigint, uid bigint, dept bigint, adm boolean) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT EXISTS (SELECT 1 FROM files f WHERE f.id = fid AND f.owner_id = uid)
    OR EXISTS (SELECT 1 FROM req_files rf WHERE rf.file_id = fid AND req_can_view(rf.request_id, uid, adm))
$$;


-- ############################################################################
-- ## 012_analytics.sql
-- ############################################################################

-- 012: аналитика для администратора — охват и вовлечение, поиск, аудитория, разделы.
-- Принцип: горячие пути (просмотр новости, поиск, переходы по страницам) пишут только в Redis или в буферизованную
-- очередь процесса; в PostgreSQL данные попадают пачками из фоновых задач (analytics.go). Отчёты читают rollup-таблицы.

-- ---- поиск -----------------------------------------------------------------------------------------------
-- Сырой журнал запросов. id генерирует приложение (монотонный, без обращения к sequence в горячем пути).
-- Хранится analytics_retention_days дней (ANALYTICS_RETENTION_DAYS, по умолчанию 400), чистится пакетами.
CREATE TABLE search_log (
    id            bigint PRIMARY KEY,
    user_id       bigint,                                   -- без FK: запись должна быть дешёвой; удалённые пользователи остаются в агрегатах
    scope         text   NOT NULL,                          -- global | news | people | groups | ideas | photos | videos | vacations | learning | …
    query         text   NOT NULL,                          -- как ввёл пользователь (обрезан до 200 символов)
    normalized    text   NOT NULL,                          -- нижний регистр, ё→е, схлопнутые пробелы
    results_count int    NOT NULL DEFAULT 0,
    took_ms       int    NOT NULL DEFAULT 0,
    clicked       boolean NOT NULL DEFAULT false,           -- был переход по результату
    click_entity  text   NOT NULL DEFAULT '',               -- например news:12, user:7
    created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX search_log_time ON search_log (created_at);
CREATE INDEX search_log_norm ON search_log (normalized, created_at);          -- «кто искал» по запросу (только админ)
CREATE INDEX search_log_open ON search_log (user_id, created_at DESC) WHERE NOT clicked;  -- привязка клика к запросу

-- Дневной rollup по запросам. Хранятся только повторяющиеся (searches >= 2) и нулевые запросы дня: одиночные запросы
-- с результатом — шум «длинного хвоста», на топы не влияют. Полные счётчики дня (с хвостом) — в stats_daily (search_*).
CREATE TABLE search_daily (
    day        date   NOT NULL,
    scope      text   NOT NULL,
    normalized text   NOT NULL,
    searches   int    NOT NULL,
    zero       int    NOT NULL DEFAULT 0,                   -- запросов без результатов
    noclick    int    NOT NULL DEFAULT 0,                   -- с результатами, но без перехода
    clicks     int    NOT NULL DEFAULT 0,
    users      int    NOT NULL DEFAULT 0,                   -- различных пользователей за день
    took_ms    bigint NOT NULL DEFAULT 0,                   -- сумма времени ответа
    sample     text   NOT NULL DEFAULT '',                  -- как запрос писали чаще всего (для показа)
    PRIMARY KEY (day, scope, normalized)
);
CREATE INDEX search_daily_zero ON search_daily (day) WHERE zero > 0;

-- Отметка администратора «обработано» для запросов без результатов (добавлен контент / синоним).
CREATE TABLE search_resolved (
    normalized  text PRIMARY KEY,
    resolved_by bigint,
    resolved_at timestamptz NOT NULL DEFAULT now(),
    note        text NOT NULL DEFAULT ''
);

-- ---- активность ------------------------------------------------------------------------------------------
-- Кто был активен в день (upsert не чаще раза в несколько минут на пользователя — дедуп в Redis).
CREATE TABLE user_daily_activity (
    day        date   NOT NULL,
    user_id    bigint NOT NULL,
    first_seen timestamptz NOT NULL DEFAULT now(),
    hits       int    NOT NULL DEFAULT 1,
    PRIMARY KEY (day, user_id)
);

-- Универсальные дневные метрики. dc — ЦОД, записавший счётчик: каждый ЦОД прибавляет только к своей строке
-- (никаких конфликтов между ЦОДами и повторов), при чтении значения суммируются по dc. Абсолютные значения,
-- пересчитываемые из PG (dau, wau, mau, лайки, комментарии, сообщения…), пишутся с dc = ''.
CREATE TABLE stats_daily (
    day    date   NOT NULL,
    metric text   NOT NULL,
    dim    text   NOT NULL DEFAULT '',
    dc     text   NOT NULL DEFAULT '',
    value  bigint NOT NULL DEFAULT 0,
    PRIMARY KEY (day, metric, dim, dc)
);
CREATE INDEX stats_daily_metric ON stats_daily (metric, day);

-- ---- новости ---------------------------------------------------------------------------------------------
ALTER TABLE news ADD COLUMN uniq_views int NOT NULL DEFAULT 0;   -- уникальные просмотревшие (сумма news_views)

-- Кто хоть раз открывал новость. Нужна, чтобы считать именно уникальных читателей; пишется пачкой из Redis-множества.
CREATE TABLE news_views (
    news_id   bigint NOT NULL REFERENCES news(id) ON DELETE CASCADE,
    user_id   bigint NOT NULL,
    viewed_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (news_id, user_id)
);
-- Читатели новости по подразделениям (dept_id = 0 — без подразделения).
CREATE TABLE news_dept_views (
    news_id bigint NOT NULL REFERENCES news(id) ON DELETE CASCADE,
    dept_id bigint NOT NULL,
    viewers int    NOT NULL DEFAULT 0,
    PRIMARY KEY (news_id, dept_id)
);
CREATE INDEX news_dept_views_dept ON news_dept_views (dept_id);

CREATE TABLE news_stats_daily (
    news_id    bigint NOT NULL REFERENCES news(id) ON DELETE CASCADE,
    day        date   NOT NULL,
    views      int    NOT NULL DEFAULT 0,    -- просмотры (с дедупликацией 30 минут на пользователя)
    uniq_views int    NOT NULL DEFAULT 0,    -- новые уникальные читатели за день
    likes      int    NOT NULL DEFAULT 0,
    comments   int    NOT NULL DEFAULT 0,
    PRIMARY KEY (news_id, day)
);
CREATE INDEX news_stats_daily_day ON news_stats_daily (day, news_id);

-- Индексы под пересчёт «сегодня/вчера» из первичных таблиц: BRIN крошечные и почти не стоят записи.
-- «лайки» живут в likes (до миграции 009) или в reactions (после): индексируем то, что есть; остальное (закладки,
-- упоминания, заявки, обучение, wiki) создаёт фоновая задача аналитики, когда эти таблицы появятся.
DO $$
BEGIN
    IF to_regclass('public.reactions') IS NOT NULL THEN
        CREATE INDEX IF NOT EXISTS reactions_created_brin ON reactions USING brin (created_at);
    ELSIF to_regclass('public.likes') IS NOT NULL THEN
        CREATE INDEX IF NOT EXISTS likes_created_brin ON likes USING brin (created_at);
    END IF;
END $$;
CREATE INDEX IF NOT EXISTS comments_created_brin ON comments USING brin (created_at);
CREATE INDEX IF NOT EXISTS messages_created_brin ON messages USING brin (created_at);
CREATE INDEX IF NOT EXISTS poll_votes_voted_brin ON poll_votes USING brin (voted_at);
CREATE INDEX IF NOT EXISTS group_posts_created_brin ON group_posts USING brin (created_at);
CREATE INDEX IF NOT EXISTS ideas_created_brin ON ideas USING brin (created_at);
CREATE INDEX IF NOT EXISTS users_created_brin ON users USING brin (created_at);


-- ############################################################################
-- ## 013_lms.sql
-- ############################################################################

-- 013: LMS — курсы с прогрессом, назначения и напоминания, сертификаты, роль «ответственный за обучение»,
--      расширение тестов (пул вопросов, matching/ordering, снимки вопросов в попытках)

-- ---- роль «ответственный за обучение» -------------------------------------------------------------
ALTER TABLE users
    ADD COLUMN learning_manager boolean     NOT NULL DEFAULT false,
    ADD COLUMN department_since timestamptz NOT NULL DEFAULT now();   -- когда сотрудник попал в текущее подразделение (приём/перевод)

-- Область ответственного = его подразделение и все дочерние + эти подразделения (с поддеревьями). Админ видит всё.
CREATE TABLE learning_manager_departments (
    user_id       bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id bigint NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, department_id)
);
CREATE INDEX learning_manager_departments_dept ON learning_manager_departments (department_id);
CREATE INDEX users_learning_manager ON users (id) WHERE learning_manager AND NOT blocked;
CREATE INDEX users_dept_since ON users (department_since) WHERE department_id IS NOT NULL;

CREATE FUNCTION lms_user_dept_bi() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP = 'INSERT' OR NEW.department_id IS DISTINCT FROM OLD.department_id THEN NEW.department_since := now(); END IF;
    RETURN NEW;
END $$;
CREATE TRIGGER lms_user_dept_bi BEFORE INSERT OR UPDATE OF department_id ON users FOR EACH ROW EXECUTE FUNCTION lms_user_dept_bi();

-- ---- папки курсов (тот же механизм ACL, что у материалов и тестов) -----------------------------------
DO $$
DECLARE c record; vals text[];
BEGIN
    FOR c IN SELECT conname, pg_get_constraintdef(oid) AS d FROM pg_constraint
             WHERE conrelid = 'learn_folders'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) LIKE '%kind%' LOOP
        SELECT array_agg(DISTINCT m[1]) INTO vals FROM regexp_matches(c.d, '''([a-z_]+)''', 'g') m;
        EXECUTE format('ALTER TABLE learn_folders DROP CONSTRAINT %I', c.conname);
    END LOOP;
    SELECT array_agg(DISTINCT x) INTO vals FROM unnest(coalesce(vals, '{}') || ARRAY['materials', 'tests', 'courses']) x;
    EXECUTE format('ALTER TABLE learn_folders ADD CONSTRAINT learn_folders_kind_check CHECK (kind = ANY (%L::text[]))', vals);
END $$;

-- ---- шаблоны сертификатов ----------------------------------------------------------------------------
CREATE TABLE learn_cert_templates (
    id           bigserial PRIMARY KEY,
    name         text   NOT NULL,
    title        text   NOT NULL DEFAULT 'Сертификат',
    body         text   NOT NULL DEFAULT 'Настоящим подтверждается, что {ФИО} успешно прошёл(ла) обучение по программе «{курс}» {дата} с результатом {балл}.',
    color        text   NOT NULL DEFAULT '#1f5fa8',
    border       text   NOT NULL DEFAULT 'double' CHECK (border IN ('none', 'simple', 'double', 'ornate')),
    logo         text   NOT NULL DEFAULT '',
    signer_name  text   NOT NULL DEFAULT '',
    signer_title text   NOT NULL DEFAULT '',
    number_mask  text   NOT NULL DEFAULT 'CN-{YYYY}-{N:5}',
    expire_remind_days int NOT NULL DEFAULT 30 CHECK (expire_remind_days >= 0),   -- за сколько дней напомнить об окончании срока
    counter      bigint NOT NULL DEFAULT 0,          -- счётчик без дыр: увеличивается в транзакции выдачи
    created_by   bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at   timestamptz NOT NULL DEFAULT now(),
    updated_at   timestamptz NOT NULL DEFAULT now()
);

-- ---- курсы ------------------------------------------------------------------------------------------
CREATE TABLE learn_courses (
    id               bigserial PRIMARY KEY,
    folder_id        bigint NOT NULL REFERENCES learn_folders(id) ON DELETE CASCADE,
    title            text   NOT NULL,
    description      text   NOT NULL DEFAULT '',
    cover            text   NOT NULL DEFAULT '',
    tags             text[] NOT NULL DEFAULT '{}',
    status           text   NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
    est_minutes      int    NOT NULL DEFAULT 0,
    order_mode       text   NOT NULL DEFAULT 'free' CHECK (order_mode IN ('free', 'sequential')),
    pass_percent     int    NOT NULL DEFAULT 70 CHECK (pass_percent BETWEEN 0 AND 100),   -- порог теста внутри курса
    validity_months  int    NOT NULL DEFAULT 0 CHECK (validity_months >= 0),               -- 0 — бессрочно
    max_attempts     int    CHECK (max_attempts IS NULL OR max_attempts > 0),              -- попыток теста внутри курса
    version          int    NOT NULL DEFAULT 1,
    cert_template_id bigint REFERENCES learn_cert_templates(id) ON DELETE SET NULL,
    steps_count      int    NOT NULL DEFAULT 0,
    required_count   int    NOT NULL DEFAULT 0,
    sort             int    NOT NULL DEFAULT 0,
    author_id        bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX learn_courses_folder ON learn_courses (folder_id, sort, id);
CREATE INDEX learn_courses_title_trgm ON learn_courses USING gin (lower(title || ' ' || description) gin_trgm_ops);
CREATE INDEX learn_courses_tags ON learn_courses USING gin (tags);
CREATE INDEX learn_courses_tpl ON learn_courses (cert_template_id) WHERE cert_template_id IS NOT NULL;

CREATE TABLE learn_course_prereq (
    course_id bigint NOT NULL REFERENCES learn_courses(id) ON DELETE CASCADE,
    req_id    bigint NOT NULL REFERENCES learn_courses(id) ON DELETE CASCADE,
    PRIMARY KEY (course_id, req_id),
    CHECK (course_id <> req_id)
);
CREATE INDEX learn_course_prereq_req ON learn_course_prereq (req_id);

CREATE TABLE learn_course_sections (
    id        bigserial PRIMARY KEY,
    course_id bigint NOT NULL REFERENCES learn_courses(id) ON DELETE CASCADE,
    title     text   NOT NULL,
    sort      int    NOT NULL DEFAULT 0
);
CREATE INDEX learn_course_sections_course ON learn_course_sections (course_id, sort, id);

CREATE TABLE learn_course_steps (
    id           bigserial PRIMARY KEY,
    course_id    bigint NOT NULL REFERENCES learn_courses(id) ON DELETE CASCADE,
    section_id   bigint REFERENCES learn_course_sections(id) ON DELETE SET NULL,
    sort         int    NOT NULL DEFAULT 0,
    kind         text   NOT NULL CHECK (kind IN ('item', 'test', 'link', 'video', 'wiki', 'ack')),
    ref_id       bigint,                              -- материал (item) / тест (test)
    title        text   NOT NULL,
    body         text   NOT NULL DEFAULT '',          -- текст ознакомления (ack)
    url          text   NOT NULL DEFAULT '',          -- link / video / wiki
    required     boolean NOT NULL DEFAULT true,
    pass_percent int    CHECK (pass_percent IS NULL OR pass_percent BETWEEN 0 AND 100),
    est_minutes  int    NOT NULL DEFAULT 0
);
CREATE INDEX learn_course_steps_course ON learn_course_steps (course_id, sort, id);
CREATE INDEX learn_course_steps_ref ON learn_course_steps (kind, ref_id) WHERE ref_id IS NOT NULL;

-- ---- прогресс ---------------------------------------------------------------------------------------
-- запись одного шага: единственный upsert по первичному ключу, без блокировок соседей
CREATE TABLE learn_step_progress (
    user_id   bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    step_id   bigint NOT NULL REFERENCES learn_course_steps(id) ON DELETE CASCADE,
    course_id bigint NOT NULL,
    status    smallint NOT NULL DEFAULT 1,            -- 0 не начат, 1 в процессе, 2 завершён
    first_at  timestamptz NOT NULL DEFAULT now(),
    last_at   timestamptz NOT NULL DEFAULT now(),
    done_at   timestamptz,
    time_sec  int NOT NULL DEFAULT 0,
    beat_at   timestamptz,
    score     numeric(5,1),                           -- результат теста, %
    attempt_id bigint,
    PRIMARY KEY (user_id, step_id)
);
CREATE INDEX learn_step_progress_course ON learn_step_progress (course_id, step_id, status);
CREATE INDEX learn_step_progress_user ON learn_step_progress (user_id, course_id);

-- прохождение курса пользователем (денормализовано: подразделение, % и время — отчёты читают только эту таблицу)
CREATE TABLE learn_enrollments (
    user_id           bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    course_id         bigint NOT NULL REFERENCES learn_courses(id) ON DELETE CASCADE,
    dept_id           bigint,
    status            smallint NOT NULL DEFAULT 0,    -- 0 не начат, 1 в процессе, 2 завершён
    cycle             int NOT NULL DEFAULT 1,
    started_at        timestamptz,
    last_at           timestamptz,
    completed_at      timestamptz,
    expires_at        timestamptz,
    started_version   int NOT NULL DEFAULT 1,
    completed_version int,
    steps_done        int NOT NULL DEFAULT 0,
    steps_total       int NOT NULL DEFAULT 0,
    percent           smallint NOT NULL DEFAULT 0,
    time_sec          int NOT NULL DEFAULT 0,
    score             numeric(5,1),
    cert_id           bigint,
    soon_notified     boolean NOT NULL DEFAULT false,
    PRIMARY KEY (user_id, course_id)
);
CREATE INDEX learn_enrollments_course ON learn_enrollments (course_id, status);
CREATE INDEX learn_enrollments_dept ON learn_enrollments (dept_id, course_id, status);
CREATE INDEX learn_enrollments_recent ON learn_enrollments (user_id, last_at DESC);
CREATE INDEX learn_enrollments_done ON learn_enrollments (course_id, completed_at) WHERE status = 2;
CREATE INDEX learn_enrollments_exp ON learn_enrollments (expires_at) WHERE status = 2 AND expires_at IS NOT NULL;

-- история завершений (рекертификация не стирает прошлые результаты)
CREATE TABLE learn_completions (
    id           bigserial PRIMARY KEY,
    user_id      bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    course_id    bigint NOT NULL REFERENCES learn_courses(id) ON DELETE CASCADE,
    cycle        int NOT NULL,
    version      int NOT NULL,
    completed_at timestamptz NOT NULL DEFAULT now(),
    expires_at   timestamptz,
    score        numeric(5,1),
    time_sec     int NOT NULL DEFAULT 0,
    cert_id      bigint
);
CREATE INDEX learn_completions_user ON learn_completions (user_id, completed_at DESC);
CREATE INDEX learn_completions_course ON learn_completions (course_id, completed_at);

-- ---- сертификаты ------------------------------------------------------------------------------------
CREATE TABLE learn_certs (
    id          bigserial PRIMARY KEY,
    number      text   NOT NULL,
    code        text   NOT NULL,                      -- проверочный код (публичная страница проверки)
    user_id     bigint REFERENCES users(id) ON DELETE SET NULL,
    dept_id     bigint,
    course_id   bigint REFERENCES learn_courses(id) ON DELETE SET NULL,
    test_id     bigint REFERENCES learn_tests(id) ON DELETE SET NULL,
    template_id bigint REFERENCES learn_cert_templates(id) ON DELETE SET NULL,
    title       text   NOT NULL,                      -- название курса/теста на момент выдачи
    user_name   text   NOT NULL,
    score       numeric(5,1),
    issued_at   timestamptz NOT NULL DEFAULT now(),
    expires_at  timestamptz,
    status      text   NOT NULL DEFAULT 'valid' CHECK (status IN ('valid', 'revoked')),
    revoked_at  timestamptz,
    revoked_by  bigint REFERENCES users(id) ON DELETE SET NULL,
    revoke_reason text NOT NULL DEFAULT '',
    soon_notified boolean NOT NULL DEFAULT false,
    look        jsonb  NOT NULL DEFAULT '{}'          -- снимок оформления и текста (шаблон можно менять — выданные не меняются)
);
CREATE UNIQUE INDEX learn_certs_number ON learn_certs (number);
CREATE UNIQUE INDEX learn_certs_code ON learn_certs (code);
CREATE INDEX learn_certs_user ON learn_certs (user_id, issued_at DESC);
CREATE INDEX learn_certs_dept ON learn_certs (dept_id, issued_at DESC);
CREATE INDEX learn_certs_course ON learn_certs (course_id, issued_at DESC);
CREATE INDEX learn_certs_exp ON learn_certs (expires_at) WHERE status = 'valid' AND expires_at IS NOT NULL;
ALTER TABLE learn_enrollments ADD CONSTRAINT learn_enrollments_cert_fk FOREIGN KEY (cert_id) REFERENCES learn_certs(id) ON DELETE SET NULL;

-- ---- назначения -------------------------------------------------------------------------------------
CREATE TABLE learn_assignments (
    id                  bigserial PRIMARY KEY,
    target_type         text   NOT NULL CHECK (target_type IN ('course', 'test')),
    target_id           bigint NOT NULL,
    created_by          bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at          timestamptz NOT NULL DEFAULT now(),
    priority            text   NOT NULL DEFAULT 'normal' CHECK (priority IN ('normal', 'high')),
    mandatory           boolean NOT NULL DEFAULT true,
    due_mode            text   NOT NULL DEFAULT 'days' CHECK (due_mode IN ('none', 'date', 'days')),
    due_date            timestamptz,
    due_days            int    CHECK (due_days IS NULL OR due_days > 0),     -- срок: N дней с момента назначения
    remind_days         int[]  NOT NULL DEFAULT '{7,3,1,0}',                  -- за сколько дней до срока напоминать (0 — в день срока)
    remind_overdue_days int    NOT NULL DEFAULT 3 CHECK (remind_overdue_days >= 0),   -- после просрочки — каждые N дней, 0 — не напоминать
    recur_months        int    NOT NULL DEFAULT 0 CHECK (recur_months >= 0),  -- периодическое переназначение
    follow              boolean NOT NULL DEFAULT false,                       -- правило: назначать и новым сотрудникам цели
    new_within_days     int    CHECK (new_within_days IS NULL OR new_within_days > 0),   -- ... появившимся в подразделении за последние N дней
    limit_depts         bigint[],                                             -- область создателя-ответственного (NULL — без ограничений)
    note                text   NOT NULL DEFAULT '',
    status              text   NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled'))
);
CREATE INDEX learn_assignments_target ON learn_assignments (target_type, target_id);
CREATE INDEX learn_assignments_follow ON learn_assignments (id) WHERE status = 'active' AND follow;
CREATE INDEX learn_assignments_recur ON learn_assignments (id) WHERE status = 'active' AND recur_months > 0;

CREATE TABLE learn_assign_targets (
    id            bigserial PRIMARY KEY,
    assignment_id bigint NOT NULL REFERENCES learn_assignments(id) ON DELETE CASCADE,
    subject_type  text   NOT NULL CHECK (subject_type IN ('user', 'department', 'group', 'role', 'all')),
    subject_id    bigint NOT NULL DEFAULT 0,
    subject_key   text   NOT NULL DEFAULT ''           -- для role: user | editor | admin | head | learning_manager
);
CREATE UNIQUE INDEX learn_assign_targets_uq ON learn_assign_targets (assignment_id, subject_type, subject_id, subject_key);

-- кто и что должен пройти (по строке на пользователя и цикл переназначения)
CREATE TABLE learn_assignees (
    id             bigserial PRIMARY KEY,
    assignment_id  bigint NOT NULL REFERENCES learn_assignments(id) ON DELETE CASCADE,
    user_id        bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    dept_id        bigint,
    target_type    text   NOT NULL,
    target_id      bigint NOT NULL,
    cycle          int    NOT NULL DEFAULT 1,
    assigned_at    timestamptz NOT NULL DEFAULT now(),
    due_at         timestamptz,
    status         smallint NOT NULL DEFAULT 0,          -- 0 назначено, 1 в процессе, 2 выполнено, 3 отозвано
    started_at     timestamptz,
    done_at        timestamptz,
    score          numeric(5,1),
    high           boolean NOT NULL DEFAULT false,
    mandatory      boolean NOT NULL DEFAULT true,
    manual_remind_at timestamptz
);
CREATE UNIQUE INDEX learn_assignees_uq ON learn_assignees (assignment_id, user_id, cycle);
CREATE INDEX learn_assignees_user ON learn_assignees (user_id, status, due_at);
CREATE INDEX learn_assignees_dept ON learn_assignees (dept_id, status, due_at);
CREATE INDEX learn_assignees_target ON learn_assignees (target_type, target_id, status);
CREATE INDEX learn_assignees_due ON learn_assignees (due_at) WHERE status < 2 AND due_at IS NOT NULL;
CREATE INDEX learn_assignees_done ON learn_assignees (done_at) WHERE status = 2;

-- идемпотентные ключи напоминаний: повторный запуск джоба не создаёт дубль
CREATE TABLE learn_reminders (
    assignee_id bigint NOT NULL REFERENCES learn_assignees(id) ON DELETE CASCADE,
    key         text   NOT NULL,
    sent_at     timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (assignee_id, key)
);
CREATE TABLE learn_digests (
    user_id bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day     date   NOT NULL,
    PRIMARY KEY (user_id, day)
);
CREATE TABLE learn_assign_log (
    id            bigserial PRIMARY KEY,
    assignee_id   bigint REFERENCES learn_assignees(id) ON DELETE CASCADE,
    assignment_id bigint REFERENCES learn_assignments(id) ON DELETE CASCADE,
    actor_id      bigint REFERENCES users(id) ON DELETE SET NULL,
    action        text   NOT NULL,                         -- create | extend | revoke | restore | remind | cancel
    data          jsonb  NOT NULL DEFAULT '{}',
    at            timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX learn_assign_log_assignee ON learn_assign_log (assignee_id, at DESC);
CREATE INDEX learn_assign_log_assignment ON learn_assign_log (assignment_id, at DESC);

-- подразделение пользователя продублировано в отчётных таблицах
CREATE FUNCTION lms_user_dept_ai() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    UPDATE learn_assignees SET dept_id = NEW.department_id WHERE user_id = NEW.id;
    UPDATE learn_enrollments SET dept_id = NEW.department_id WHERE user_id = NEW.id;
    UPDATE learn_certs SET dept_id = NEW.department_id WHERE user_id = NEW.id;
    RETURN NULL;
END $$;
CREATE TRIGGER lms_user_dept_ai AFTER UPDATE OF department_id ON users FOR EACH ROW
    WHEN (OLD.department_id IS DISTINCT FROM NEW.department_id) EXECUTE FUNCTION lms_user_dept_ai();

-- ---- тесты: пул вопросов, новые типы, снимки -------------------------------------------------------------
ALTER TABLE learn_tests
    ADD COLUMN pool_size int CHECK (pool_size IS NULL OR pool_size > 0),            -- N вопросов из M случайно
    ADD COLUMN cert_template_id bigint REFERENCES learn_cert_templates(id) ON DELETE SET NULL,   -- сертификат за сдачу теста
    ADD COLUMN cert_validity_months int NOT NULL DEFAULT 0 CHECK (cert_validity_months >= 0);

DO $$
DECLARE c record;
BEGIN
    FOR c IN SELECT conname FROM pg_constraint WHERE conrelid = 'learn_questions'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) LIKE '%single%' LOOP
        EXECUTE format('ALTER TABLE learn_questions DROP CONSTRAINT %I', c.conname);
    END LOOP;
    ALTER TABLE learn_questions ADD CONSTRAINT learn_questions_type_check CHECK (type IN ('single', 'multiple', 'text', 'matching', 'ordering'));
END $$;

-- версии набора вопросов теста (содержимое хэшируется; попытка ссылается на версию, а не копирует вопросы)
CREATE TABLE learn_test_versions (
    id         bigserial PRIMARY KEY,
    test_id    bigint NOT NULL REFERENCES learn_tests(id) ON DELETE CASCADE,
    hash       text   NOT NULL,
    questions  jsonb  NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX learn_test_versions_uq ON learn_test_versions (test_id, hash);

ALTER TABLE learn_attempts
    ADD COLUMN version_id bigint REFERENCES learn_test_versions(id) ON DELETE SET NULL,
    ADD COLUMN qids       bigint[],                    -- выбранные вопросы (пул N из M) в порядке показа
    ADD COLUMN course_id  bigint,
    ADD COLUMN step_id    bigint;
CREATE INDEX learn_attempts_step ON learn_attempts (user_id, step_id) WHERE step_id IS NOT NULL;
CREATE INDEX learn_attempts_course ON learn_attempts (course_id, finished_at) WHERE course_id IS NOT NULL;
CREATE INDEX learn_attempts_version ON learn_attempts (version_id) WHERE version_id IS NOT NULL;
CREATE INDEX learn_attempts_fin ON learn_attempts (finished_at DESC) WHERE finished_at IS NOT NULL;

-- ---- доступ к материалам/тестам через курс или назначение -------------------------------------------------------
-- курс доступен: опубликован и папка видна, либо назначен; администратор — всегда
CREATE FUNCTION lms_course_ok(cid bigint, uid bigint, dept bigint, adm boolean) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT EXISTS (SELECT 1 FROM learn_courses c WHERE c.id = cid AND (adm OR (c.status = 'published' AND (
        learn_level(c.folder_id, uid, dept, adm) > 0
        OR EXISTS (SELECT 1 FROM learn_assignees a WHERE a.user_id = uid AND a.target_type = 'course' AND a.target_id = c.id AND a.status < 3)))))
$$;

-- материал/тест доступен как шаг доступного курса (или тест назначен напрямую)
CREATE FUNCTION lms_ref_ok(k text, rid bigint, uid bigint, dept bigint, adm boolean) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT EXISTS (SELECT 1 FROM learn_course_steps s JOIN learn_courses c ON c.id = s.course_id
               WHERE s.kind = k AND s.ref_id = rid AND c.status = 'published' AND lms_course_ok(c.id, uid, dept, adm))
    OR (k = 'test' AND EXISTS (SELECT 1 FROM learn_assignees a WHERE a.user_id = uid AND a.target_type = 'test' AND a.target_id = rid AND a.status < 3))
$$;

CREATE OR REPLACE FUNCTION learn_file_ok(fid bigint, uid bigint, dept bigint, adm boolean) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT adm
    OR EXISTS (SELECT 1 FROM files f WHERE f.id = fid AND f.owner_id = uid)
    OR EXISTS (SELECT 1 FROM learn_item_files lf JOIN learn_items i ON i.id = lf.item_id
               WHERE lf.file_id = fid AND (learn_level(i.folder_id, uid, dept, adm) > 0 OR lms_ref_ok('item', i.id, uid, dept, adm)))
    OR EXISTS (SELECT 1 FROM learn_questions q JOIN learn_tests t ON t.id = q.test_id
               WHERE q.file_id = fid AND (learn_level(t.folder_id, uid, dept, adm) >= 3
                  OR (t.status = 'published' AND (learn_level(t.folder_id, uid, dept, adm) > 0 OR lms_ref_ok('test', t.id, uid, dept, adm)))))
$$;

-- счётчики курсов в папке (как для тестов: items_count — всего, pub_count — опубликованных)
CREATE FUNCTION learn_count_courses() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE pn int := 0; po int := 0;
BEGIN
    IF TG_OP IN ('INSERT', 'UPDATE') AND NEW.status = 'published' THEN pn := 1; END IF;
    IF TG_OP IN ('DELETE', 'UPDATE') AND OLD.status = 'published' THEN po := 1; END IF;
    IF TG_OP = 'UPDATE' AND OLD.folder_id = NEW.folder_id AND pn = po THEN RETURN NULL; END IF;
    IF TG_OP IN ('DELETE', 'UPDATE') THEN
        UPDATE learn_folders SET items_count = items_count - 1, pub_count = pub_count - po WHERE id = OLD.folder_id;
    END IF;
    IF TG_OP IN ('INSERT', 'UPDATE') THEN
        UPDATE learn_folders SET items_count = items_count + 1, pub_count = pub_count + pn WHERE id = NEW.folder_id;
    END IF;
    RETURN NULL;
END $$;
CREATE TRIGGER learn_courses_cnt AFTER INSERT OR DELETE OR UPDATE OF folder_id, status ON learn_courses FOR EACH ROW EXECUTE FUNCTION learn_count_courses();


-- ############################################################################
-- ## 014_wiki.sql
-- ############################################################################

-- 014: базы знаний (Wiki) в разделе «Обучение → Материалы»
--   wiki_spaces      — база знаний (корневой раздел), привязана к папке материалов (learn_folders) или лежит в корне;
--   wiki_pages       — страницы любой вложенности (parent_id, sort), markdown, версия для оптимистичной блокировки;
--   wiki_acl         — права на базу (page_id IS NULL) и на отдельные страницы/ветки;
--   wiki_versions    — полные снимки страниц; wiki_page_files — вложения; wiki_comments — комментарии.

-- файлы вложений хранятся в files с context = 'wiki'
DO $$
DECLARE d text;
BEGIN
    SELECT pg_get_constraintdef(oid) INTO d FROM pg_constraint WHERE conrelid = 'files'::regclass AND conname = 'files_context_check';
    IF d IS NOT NULL AND d NOT LIKE '%''wiki''%' THEN
        ALTER TABLE files DROP CONSTRAINT files_context_check;
        EXECUTE 'ALTER TABLE files ADD CONSTRAINT files_context_check ' || replace(d, '''comment''::text', '''comment''::text, ''wiki''::text');
    END IF;
END $$;

CREATE TABLE wiki_spaces (
    id          bigserial PRIMARY KEY,
    folder_id   bigint REFERENCES learn_folders(id) ON DELETE CASCADE,   -- NULL — в корне вкладки «Материалы»
    title       text   NOT NULL,
    slug        text   NOT NULL DEFAULT '',
    description text   NOT NULL DEFAULT '',
    icon        text   NOT NULL DEFAULT '',     -- эмодзи / короткий символ
    cover       text   NOT NULL DEFAULT '',     -- адрес картинки или ключ цветовой схемы (c1..c8)
    visibility  text   NOT NULL DEFAULT 'company' CHECK (visibility IN ('company', 'restricted')),
    owner_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    sort        int    NOT NULL DEFAULT 0,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX wiki_spaces_folder ON wiki_spaces (folder_id, sort, lower(title));

CREATE TABLE wiki_pages (
    id             bigserial PRIMARY KEY,
    space_id       bigint NOT NULL REFERENCES wiki_spaces(id) ON DELETE CASCADE,
    parent_id      bigint REFERENCES wiki_pages(id) ON DELETE CASCADE,
    title          text   NOT NULL,
    slug           text   NOT NULL DEFAULT '',
    body           text   NOT NULL DEFAULT '',
    sort           int    NOT NULL DEFAULT 0,
    visibility     text   NOT NULL DEFAULT 'inherit' CHECK (visibility IN ('inherit', 'restricted')),
    owner_id       bigint REFERENCES users(id) ON DELETE SET NULL,
    responsible_id bigint REFERENCES users(id) ON DELETE SET NULL,
    review_until   date,
    tags           text[] NOT NULL DEFAULT '{}',
    icon           text   NOT NULL DEFAULT '',
    version        int    NOT NULL DEFAULT 1,
    views_count    int    NOT NULL DEFAULT 0,
    created_by     bigint REFERENCES users(id) ON DELETE SET NULL,
    updated_by     bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at     timestamptz NOT NULL DEFAULT now(),
    updated_at     timestamptz NOT NULL DEFAULT now(),
    search         tsvector GENERATED ALWAYS AS (
        setweight(to_tsvector('simple', title), 'A') || setweight(to_tsvector('simple', left(body, 200000)), 'B')) STORED
);
CREATE INDEX wiki_pages_tree ON wiki_pages (space_id, parent_id, sort, id);
CREATE INDEX wiki_pages_parent ON wiki_pages (parent_id);
CREATE INDEX wiki_pages_fts ON wiki_pages USING gin (search);
CREATE INDEX wiki_pages_title_trgm ON wiki_pages USING gin (lower(title) gin_trgm_ops);
CREATE INDEX wiki_pages_recent ON wiki_pages (space_id, updated_at DESC);
CREATE INDEX wiki_pages_review ON wiki_pages (review_until) WHERE review_until IS NOT NULL;
CREATE INDEX wiki_pages_resp ON wiki_pages (responsible_id) WHERE responsible_id IS NOT NULL;
CREATE INDEX wiki_pages_tags ON wiki_pages USING gin (tags);

-- права: page_id NULL — на всю базу; subject_type: user | department (с дочерними) | group | role | all
-- role: user (любой сотрудник) | editor | head (руководитель подразделения) | admin
-- level: 1 чтение, 3 редактирование, 4 управление (права, удаление)
CREATE TABLE wiki_acl (
    id           bigserial PRIMARY KEY,
    space_id     bigint   NOT NULL REFERENCES wiki_spaces(id) ON DELETE CASCADE,
    page_id      bigint   REFERENCES wiki_pages(id) ON DELETE CASCADE,
    subject_type text     NOT NULL CHECK (subject_type IN ('user', 'department', 'group', 'role', 'all')),
    subject_id   bigint   NOT NULL DEFAULT 0,
    subject_key  text     NOT NULL DEFAULT '',
    level        smallint NOT NULL CHECK (level IN (1, 3, 4))
);
CREATE UNIQUE INDEX wiki_acl_uq ON wiki_acl (space_id, coalesce(page_id, 0), subject_type, subject_id, subject_key);
CREATE INDEX wiki_acl_page ON wiki_acl (page_id) WHERE page_id IS NOT NULL;

CREATE TABLE wiki_versions (
    id         bigserial PRIMARY KEY,
    page_id    bigint NOT NULL REFERENCES wiki_pages(id) ON DELETE CASCADE,
    version    int    NOT NULL,
    title      text   NOT NULL,
    body       text   NOT NULL,
    author_id  bigint REFERENCES users(id) ON DELETE SET NULL,
    comment    text   NOT NULL DEFAULT '',
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (page_id, version)
);

CREATE TABLE wiki_page_files (
    page_id bigint NOT NULL REFERENCES wiki_pages(id) ON DELETE CASCADE,
    file_id bigint NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    sort    int    NOT NULL DEFAULT 0,
    PRIMARY KEY (page_id, file_id)
);
CREATE INDEX wiki_page_files_file ON wiki_page_files (file_id);

CREATE TABLE wiki_comments (
    id         bigserial PRIMARY KEY,
    page_id    bigint NOT NULL REFERENCES wiki_pages(id) ON DELETE CASCADE,
    user_id    bigint REFERENCES users(id) ON DELETE SET NULL,
    body       text   NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX wiki_comments_page ON wiki_comments (page_id, id);

-- ---- права ---------------------------------------------------------------------------------------
-- Подходит ли запись ACL пользователю (подразделения: своё и вышестоящие; группы: подтверждённые участники).
CREATE FUNCTION wiki_acl_match(st text, sid bigint, sk text, uid bigint, depts bigint[], groups bigint[], roles text[]) RETURNS boolean
LANGUAGE sql IMMUTABLE AS $$
SELECT st = 'all'
    OR (st = 'user' AND sid = uid)
    OR (st = 'department' AND sid = ANY(depts))
    OR (st = 'group' AND sid = ANY(groups))
    OR (st = 'role' AND sk = ANY(roles))
$$;

-- Уровень пользователя на корне базы знаний (0 — нет доступа). Администратор — 4; база в папке материалов
-- недоступна тому, кто не видит папку (learn_level = 0). «Ограниченная» база видна только по списку.
CREATE FUNCTION wiki_space_level(sid bigint, uid bigint, dept bigint, depts bigint[], groups bigint[], roles text[], adm boolean) RETURNS int
LANGUAGE plpgsql STABLE AS $$
DECLARE s wiki_spaces; acl int;
BEGIN
    SELECT * INTO s FROM wiki_spaces WHERE id = sid;
    IF NOT FOUND THEN RETURN 0; END IF;
    IF adm THEN RETURN 4; END IF;
    IF s.folder_id IS NOT NULL AND learn_level(s.folder_id, uid, dept, false) = 0 THEN RETURN 0; END IF;
    SELECT coalesce(max(a.level), 0) INTO acl FROM wiki_acl a
        WHERE a.space_id = sid AND a.page_id IS NULL AND wiki_acl_match(a.subject_type, a.subject_id, a.subject_key, uid, depts, groups, roles);
    IF s.owner_id = uid THEN acl := 4; END IF;
    IF s.visibility = 'restricted' THEN RETURN acl; END IF;
    RETURN greatest(acl, 1);
END $$;

-- Уровень пользователя на странице. Правила:
--   • администратор и управляющие базой (4) видят и правят всё;
--   • «ограниченная» страница/ветка (visibility = 'restricted') заменяет список доступа: права чтения/редактирования
--     от базы и от вышестоящих страниц на неё не распространяются (кроме управляющих базой);
--   • права редактирования/управления, выданные на странице, и владение страницей действуют на всю ветку вниз;
--   • страница доступна, только если доступны все её предки.
CREATE FUNCTION wiki_level(pid bigint, uid bigint, dept bigint, depts bigint[], groups bigint[], roles text[], adm boolean) RETURNS int
LANGUAGE plpgsql STABLE AS $$
DECLARE sid bigint; sl int; vis int; mng int; own int; lvl int := 0; n record;
BEGIN
    SELECT space_id INTO sid FROM wiki_pages WHERE id = pid;
    IF sid IS NULL THEN RETURN 0; END IF;
    sl := wiki_space_level(sid, uid, dept, depts, groups, roles, adm);
    IF sl = 0 THEN RETURN 0; END IF;
    IF sl >= 4 THEN RETURN 4; END IF;
    vis := sl; mng := CASE WHEN sl >= 3 THEN sl ELSE 0 END;
    FOR n IN
        WITH RECURSIVE up AS (
            SELECT id, parent_id, visibility, owner_id, 0 AS d FROM wiki_pages WHERE id = pid
            UNION ALL
            SELECT p.id, p.parent_id, p.visibility, p.owner_id, up.d + 1 FROM wiki_pages p JOIN up ON p.id = up.parent_id WHERE up.d < 60)
        SELECT up.*, coalesce((SELECT max(a.level) FROM wiki_acl a WHERE a.page_id = up.id
                AND wiki_acl_match(a.subject_type, a.subject_id, a.subject_key, uid, depts, groups, roles)), 0) AS acl
        FROM up ORDER BY d DESC
    LOOP
        own := greatest(n.acl, CASE WHEN n.owner_id = uid THEN 3 ELSE 0 END);
        IF n.visibility = 'restricted' THEN
            vis := own; mng := CASE WHEN own >= 3 THEN own ELSE 0 END;
        ELSE
            mng := greatest(mng, CASE WHEN own >= 3 THEN own ELSE 0 END);
        END IF;
        lvl := greatest(vis, mng);
        IF lvl = 0 THEN RETURN 0; END IF;
    END LOOP;
    RETURN lvl;
END $$;

-- То же по одному пользователю: субъекты (подразделения, группы, роли) берутся из БД. Для доступа к файлам и т. п.
CREATE FUNCTION wiki_level_u(pid bigint, uid bigint, adm boolean) RETURNS int
LANGUAGE plpgsql STABLE AS $$
DECLARE u record; depts bigint[]; groups bigint[]; roles text[];
BEGIN
    SELECT department_id, role, is_head INTO u FROM users WHERE id = uid;
    IF NOT FOUND THEN RETURN 0; END IF;
    WITH RECURSIVE dc AS (SELECT id, parent_id FROM departments WHERE id = u.department_id
        UNION ALL SELECT x.id, x.parent_id FROM departments x JOIN dc ON x.id = dc.parent_id)
    SELECT coalesce(array_agg(id), '{}') INTO depts FROM dc;
    SELECT coalesce(array_agg(group_id), '{}') INTO groups FROM group_members WHERE user_id = uid AND role <> 'pending';
    roles := ARRAY['user'];
    IF u.role IN ('editor', 'admin') THEN roles := roles || 'editor'; END IF;
    IF u.role = 'admin' THEN roles := roles || 'admin'; END IF;
    IF u.is_head THEN roles := roles || 'head'; END IF;
    RETURN wiki_level(pid, uid, coalesce(u.department_id, 0), depts, groups, roles, adm OR u.role = 'admin');
END $$;

-- доступ к файлу вложения: загрузивший или читатель страницы, к которой он прикреплён
CREATE FUNCTION wiki_file_ok(fid bigint, uid bigint, adm boolean) RETURNS boolean
LANGUAGE sql STABLE AS $$
SELECT adm
    OR EXISTS (SELECT 1 FROM files f WHERE f.id = fid AND f.owner_id = uid)
    OR EXISTS (SELECT 1 FROM wiki_page_files wf WHERE wf.file_id = fid AND wiki_level_u(wf.page_id, uid, false) > 0)
$$;


-- ############################################################################
-- ## 015_users_audit.sql
-- ############################################################################

-- 015: управление пользователями редакторами + расширенный журнал аудита.
-- Мягкое удаление: строка остаётся (авторство новостей, комментариев и т. п. сохраняется), вход закрыт, из списков скрыта.
ALTER TABLE users ADD COLUMN deleted_at timestamptz;
CREATE INDEX users_dept_active ON users (department_id) WHERE deleted_at IS NULL;

-- Журнал: идентификатор запроса и роль исполнителя на момент действия; индексы под фильтры раздела «Журнал».
ALTER TABLE audit_log ADD COLUMN request_id text NOT NULL DEFAULT '';
ALTER TABLE audit_log ADD COLUMN actor_role text NOT NULL DEFAULT '';
CREATE INDEX audit_action ON audit_log (action, id DESC);
CREATE INDEX audit_actor ON audit_log (user_id, id DESC);
CREATE INDEX audit_entity ON audit_log (entity, entity_id, id DESC);


-- ############################################################################
-- ## 016_kerberos.sql
-- ############################################################################

-- 040: Kerberos (SPNEGO) — переопределения настроек из админки и статус последних входов.
-- Одна строка (id = 1). NULL в настройке означает «взять значение из переменной окружения KRB5_*».
-- Секреты (keytab) в БД не хранятся: файл монтируется в контейнер, путь задаётся в KRB5_KEYTAB.
CREATE TABLE krb_settings (
    id             int PRIMARY KEY CHECK (id = 1),
    enabled        boolean,
    user_map       text CHECK (user_map IS NULL OR user_map IN ('sam', 'upn', 'auto')),
    auto_create    boolean,
    clock_skew_sec int CHECK (clock_skew_sec IS NULL OR clock_skew_sec BETWEEN 30 AND 3600),
    ok_count       bigint      NOT NULL DEFAULT 0,
    last_ok_at     timestamptz,
    last_ok_user   text        NOT NULL DEFAULT '',   -- principal последнего успешного входа
    last_ok_ip     text        NOT NULL DEFAULT '',
    last_error_at  timestamptz,
    last_error     text        NOT NULL DEFAULT '',   -- причина последнего отказа (для диагностики; клиенту не показывается)
    updated_at     timestamptz NOT NULL DEFAULT now()
);
INSERT INTO krb_settings (id) VALUES (1);


-- ############################################################################
-- ## 017_news_versions.sql
-- ############################################################################

-- 017: новости — история версий, комментарии к редакциям, филиалы (сегментация), аналитика чтения.
-- Таблицы названы news_revisions* и т. п., чтобы не пересекаться с возможными старыми news_versions в уже развёрнутых базах.

-- ---- филиалы ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS branches (
    id         serial PRIMARY KEY,
    name       text NOT NULL UNIQUE,
    sort       int  NOT NULL DEFAULT 0,
    created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE users ADD COLUMN IF NOT EXISTS branch_id int REFERENCES branches(id) ON DELETE SET NULL;
ALTER TABLE news  ADD COLUMN IF NOT EXISTS branch_id int REFERENCES branches(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS users_branch ON users (branch_id) WHERE branch_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS news_branch  ON news  (branch_id) WHERE branch_id IS NOT NULL;

-- ---- версии ----------------------------------------------------------------------------------------------
-- Снимок новости на момент сохранения. autosave = true — черновик, сохранённый автоматически (хранится одна
-- последняя автосохранённая версия на автора: старые автосохранения заменяются приложением).
CREATE TABLE news_revisions (
    id          bigserial PRIMARY KEY,
    news_id     bigint NOT NULL REFERENCES news(id) ON DELETE CASCADE,
    version     int    NOT NULL,
    title       text   NOT NULL,
    summary     text   NOT NULL DEFAULT '',
    body        text   NOT NULL DEFAULT '',
    cover       text   NOT NULL DEFAULT '',
    category_id int,
    department_id bigint,
    branch_id   int,
    status      text   NOT NULL DEFAULT 'published',
    published_at timestamptz,
    change_note text   NOT NULL DEFAULT '',
    autosave    boolean NOT NULL DEFAULT false,
    author_id   bigint REFERENCES users(id) ON DELETE SET NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    UNIQUE (news_id, version)
);
CREATE INDEX IF NOT EXISTS news_revisions_news ON news_revisions (news_id, version DESC);

-- Комментарии редакторов к версии (внутренние, читателям не показываются).
CREATE TABLE news_revision_comments (
    id         bigserial PRIMARY KEY,
    version_id bigint NOT NULL REFERENCES news_revisions(id) ON DELETE CASCADE,
    author_id  bigint REFERENCES users(id) ON DELETE SET NULL,
    body       text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS news_revision_comments_v ON news_revision_comments (version_id, id);

-- ---- аналитика чтения ------------------------------------------------------------------------------------
-- Одна строка на (новость, пользователь): максимальная глубина прокрутки, суммарное активное время чтения.
CREATE TABLE news_read_stats (
    news_id    bigint NOT NULL REFERENCES news(id) ON DELETE CASCADE,
    user_id    bigint NOT NULL,
    max_depth  smallint NOT NULL DEFAULT 0 CHECK (max_depth BETWEEN 0 AND 100),
    seconds    int NOT NULL DEFAULT 0,
    opens      int NOT NULL DEFAULT 1,
    first_at   timestamptz NOT NULL DEFAULT now(),
    last_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (news_id, user_id)
);

-- Дневные счётчики показов карточек в ленте и переходов по категориям.
CREATE TABLE news_feed_impressions (
    news_id     bigint NOT NULL REFERENCES news(id) ON DELETE CASCADE,
    day         date   NOT NULL DEFAULT current_date,
    impressions int    NOT NULL DEFAULT 0,
    clicks      int    NOT NULL DEFAULT 0,
    PRIMARY KEY (news_id, day)
);

CREATE TABLE news_category_clicks (
    category_id int NOT NULL,   -- 0 = «Все»
    day         date NOT NULL DEFAULT current_date,
    clicks      int NOT NULL DEFAULT 0,
    PRIMARY KEY (category_id, day)
);


-- ############################################################################
-- ## 018_vacation_calendars.sql
-- ############################################################################

-- 018: календари отпусков. Каждая запись графика принадлежит календарю; календарь видят все («company») либо только
-- перечисленные в vac_calendar_acl (сотрудники, группы сотрудников, подразделения с потомками). Владелец и админ управляют доступом.
-- level: 1 = просмотр, 2 = ведение записей. Управление (3) — только владелец/админ, в таблице не хранится.

CREATE TABLE vac_calendars (
    id          bigserial PRIMARY KEY,
    name        text    NOT NULL CHECK (length(btrim(name)) BETWEEN 1 AND 100),
    description text    NOT NULL DEFAULT '',
    color       text    NOT NULL DEFAULT '#3b82f6' CHECK (color ~ '^#[0-9a-fA-F]{6}$'),
    owner_id    bigint  REFERENCES users(id) ON DELETE SET NULL,
    is_default  boolean NOT NULL DEFAULT false,            -- «График отпусков руководящего состава» (как до появления календарей)
    visibility  text    NOT NULL DEFAULT 'restricted' CHECK (visibility IN ('company','restricted')),
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX vac_calendars_default ON vac_calendars (is_default) WHERE is_default;
CREATE INDEX vac_calendars_owner ON vac_calendars (owner_id);

CREATE TABLE vac_calendar_acl (
    calendar_id  bigint   NOT NULL REFERENCES vac_calendars(id) ON DELETE CASCADE,
    subject_type text     NOT NULL CHECK (subject_type IN ('user','group','department')),
    subject_id   bigint   NOT NULL,
    level        smallint NOT NULL DEFAULT 1 CHECK (level IN (1, 2)),
    PRIMARY KEY (calendar_id, subject_type, subject_id)
);
CREATE INDEX vac_calendar_acl_subject ON vac_calendar_acl (subject_type, subject_id);

-- бэкфил: календарь по умолчанию, виден всем; все существующие записи — в него
INSERT INTO vac_calendars (name, description, color, is_default, visibility)
VALUES ('График отпусков руководящего состава', 'Общий график руководителей подразделений', '#3b82f6', true, 'company');

ALTER TABLE vacations ADD COLUMN calendar_id bigint REFERENCES vac_calendars(id) ON DELETE CASCADE;
UPDATE vacations SET calendar_id = (SELECT id FROM vac_calendars WHERE is_default);
ALTER TABLE vacations ALTER COLUMN calendar_id SET NOT NULL;
CREATE INDEX vacations_calendar ON vacations (calendar_id, ends_on, starts_on);

-- Уровень доступа пользователя к календарю: 0 нет, 1 просмотр, 2 ведение записей, 3 управление (владелец/админ).
CREATE FUNCTION vac_cal_level(cid bigint, uid bigint, is_admin boolean) RETURNS int
LANGUAGE sql STABLE AS $$
    SELECT CASE
        WHEN is_admin OR c.owner_id = uid THEN 3
        ELSE greatest(
            CASE WHEN c.visibility = 'company' THEN 1 ELSE 0 END,
            coalesce((SELECT max(a.level) FROM vac_calendar_acl a WHERE a.calendar_id = c.id AND (
                (a.subject_type = 'user' AND a.subject_id = uid)
                OR (a.subject_type = 'group' AND EXISTS (SELECT 1 FROM group_members m WHERE m.group_id = a.subject_id AND m.user_id = uid AND m.role <> 'pending'))
                OR (a.subject_type = 'department' AND a.subject_id IN (
                    WITH RECURSIVE up(id) AS (SELECT department_id FROM users WHERE id = uid
                        UNION SELECT d.parent_id FROM departments d JOIN up ON d.id = up.id WHERE d.parent_id IS NOT NULL)
                    SELECT id FROM up WHERE id IS NOT NULL)))), 0))
    END
    FROM vac_calendars c WHERE c.id = cid
$$;

-- BRIN-индексы по времени для аналитики (раньше создавались кодом приложения при старте)
CREATE INDEX IF NOT EXISTS reactions_created_brin ON reactions USING brin (created_at);
CREATE INDEX IF NOT EXISTS bookmarks_created_brin ON bookmarks USING brin (created_at);
CREATE INDEX IF NOT EXISTS mentions_created_brin ON mentions USING brin (created_at);
CREATE INDEX IF NOT EXISTS req_requests_submitted_brin ON req_requests USING brin (submitted_at);
CREATE INDEX IF NOT EXISTS req_requests_closed_brin ON req_requests USING brin (closed_at);
CREATE INDEX IF NOT EXISTS learn_attempts_started_brin ON learn_attempts USING brin (started_at);
CREATE INDEX IF NOT EXISTS learn_attempts_finished_brin ON learn_attempts USING brin (finished_at);
CREATE INDEX IF NOT EXISTS learn_assignees_assigned_brin ON learn_assignees USING brin (assigned_at);
CREATE INDEX IF NOT EXISTS learn_completions_completed_brin ON learn_completions USING brin (completed_at);
CREATE INDEX IF NOT EXISTS wiki_pages_created_brin ON wiki_pages USING brin (created_at);
CREATE INDEX IF NOT EXISTS wiki_versions_created_brin ON wiki_versions USING brin (created_at);
CREATE INDEX IF NOT EXISTS wiki_comments_created_brin ON wiki_comments USING brin (created_at);
CREATE INDEX IF NOT EXISTS learn_progress_opened_brin ON learn_progress USING brin (opened_at);
