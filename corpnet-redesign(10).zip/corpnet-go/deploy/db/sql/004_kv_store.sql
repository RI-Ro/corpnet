-- 004: хранилище «ключ–значение» в PostgreSQL (замена Redis, когда REDIS_URL не задан).
-- UNLOGGED: не пишется в WAL и не реплицируется — это сессии, кэши, присутствие, счётчики.
CREATE UNLOGGED TABLE IF NOT EXISTS kv_store (
  k     text NOT NULL,
  f     text NOT NULL DEFAULT '',
  v     text NOT NULL DEFAULT '',
  score double precision NOT NULL DEFAULT 0,
  exp   timestamptz,
  PRIMARY KEY (k, f)
);
CREATE INDEX IF NOT EXISTS kv_store_exp   ON kv_store (exp) WHERE exp IS NOT NULL;
CREATE INDEX IF NOT EXISTS kv_store_score ON kv_store (k, score);
