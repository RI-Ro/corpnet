-- 005: домены каталогов. Пользователи ii-ivanov@DOMAIN1.LOCAL и ii-ivanov@DOMAIN2.LOCAL — РАЗНЫЕ пользователи.
-- Логин пользователя каталога с заданным доменом хранится целиком: «sam@domain» (в нижнем регистре),
-- поэтому уникальность users.login (lower(login)) разводит одноимённые учётки разных доменов.
ALTER TABLE ldap_servers
    ADD COLUMN IF NOT EXISTS domain  text NOT NULL DEFAULT '',   -- DNS-имя домена / Kerberos-realm: domain1.local
    ADD COLUMN IF NOT EXISTS netbios text NOT NULL DEFAULT '',   -- короткое имя для DOMAIN1\ivanov (пусто — первая метка домена)
    ADD COLUMN IF NOT EXISTS aliases text NOT NULL DEFAULT '';   -- другие имена домена через запятую (UPN-суффиксы)
CREATE UNIQUE INDEX IF NOT EXISTS ldap_servers_domain_uq ON ldap_servers (lower(domain)) WHERE domain <> '';

ALTER TABLE users ADD COLUMN IF NOT EXISTS domain text NOT NULL DEFAULT '';
CREATE INDEX IF NOT EXISTS users_domain_idx ON users (domain) WHERE domain <> '';
