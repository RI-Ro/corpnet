-- Журнал удалений файлов («надгробия»). Запись делает площадка, где файл удалили; таблица реплицируется вместе с БД,
-- поэтому остальные площадки читают её у себя (с реплики) и удаляют файл с диска. Записи старше 90 дней чистятся задачей.
CREATE TABLE IF NOT EXISTS file_tombstones (
    id    bigserial PRIMARY KEY,
    kind  text        NOT NULL CHECK (kind IN ('pub', 'prv')),
    name  text        NOT NULL,
    dc    text        NOT NULL DEFAULT '',
    at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS file_tombstones_at_idx   ON file_tombstones (at);
CREATE INDEX IF NOT EXISTS file_tombstones_name_idx ON file_tombstones (kind, name);
