#!/usr/bin/env bash
# Применение SQL-миграций и (по желанию) данных. Приложение само БД не меняет — всё делается здесь.
#   DATABASE_URL=postgres://... ./migrate.sh                          # применить новые миграции из sql/
#   DATABASE_URL=... ./migrate.sh --seed admin@corp.example 'Пароль'   # + начальные данные (только администратор)
#   DATABASE_URL=... ./migrate.sh --seed admin@corp.example 'Пароль' --demo   # + тестовые данные (для стендов)
# Учёт применённых файлов — таблица schema_migrations; параллельный запуск блокируется advisory-lock.
set -euo pipefail
cd "$(dirname "$0")"
: "${DATABASE_URL:?укажите DATABASE_URL}"
PSQL=(psql "$DATABASE_URL" -X -q -v ON_ERROR_STOP=1)

for f in sql/*.sql; do
  v=$(basename "$f" .sql)
  "${PSQL[@]}" -v ver="$v" -v file="$f" <<'SQL'
SELECT pg_advisory_lock(7243901) \g /dev/null
CREATE TABLE IF NOT EXISTS schema_migrations (version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now());
SELECT EXISTS (SELECT 1 FROM schema_migrations WHERE version = :'ver') AS done \gset
\if :done
  \echo пропуск :ver (уже применена)
\else
  BEGIN;
  \i :file
  INSERT INTO schema_migrations (version) VALUES (:'ver');
  COMMIT;
  \echo применена :ver
\endif
SQL
done

if [ "${1:-}" = "--seed" ]; then
  EMAIL="${2:?--seed <email> <пароль> [--demo]}"; PASS="${3:?--seed <email> <пароль> [--demo]}"
  DEMO=(); [ "${4:-}" = "--demo" ] && DEMO=(-v demo=1)
  if [ "$("${PSQL[@]}" -tAc 'SELECT count(*) FROM users')" != "0" ]; then echo "в базе уже есть пользователи — данные не добавлены"; exit 0; fi
  # хэш bcrypt считает сама БД (pgcrypto), пароль идёт через окружение psql (нужен psql 15+), а не в аргументах процесса
  CP_PASS="$PASS" "${PSQL[@]}" -1 -v admin_email="$EMAIL" "${DEMO[@]}" <<'SQL'
CREATE EXTENSION IF NOT EXISTS pgcrypto;
\getenv pw CP_PASS
SELECT crypt(:'pw', gen_salt('bf', 10)) AS admin_hash \gset
\i seed.sql
SQL
  echo "данные добавлены"
fi
