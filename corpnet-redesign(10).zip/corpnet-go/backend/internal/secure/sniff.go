// Package secure — проверки безопасности без внешних зависимостей: определение типа загружаемого файла по сигнатуре
// (а не по расширению), CSRF-токены и сборка Content-Security-Policy. Пакет намеренно только на stdlib, чтобы тестироваться отдельно.
package secure

import (
	"bytes"
	"errors"
	"path/filepath"
	"strings"
	"unicode/utf8"
)

// ErrMismatch — расширение/заявленный тип не соответствуют содержимому файла.
var ErrMismatch = errors.New("тип файла не соответствует его содержимому")

const (
	MimeBinary = "application/octet-stream" // тип «только скачать»: сервер отдаёт такие файлы как attachment
	MimeText   = "text/plain"
)

// Kind — семейство, определённое по сигнатуре.
type Kind string

const (
	KJPEG, KPNG, KGIF, KWEBP, KPDF            Kind = "jpeg", "png", "gif", "webp", "pdf"
	KZip, KOLE, KMP4, KWebM, KOgg, KMP3, KWAV Kind = "zip", "ole", "mp4", "webm", "ogg", "mp3", "wav"
	KRTF, K7z, KRar, KGzip, KBMP              Kind = "rtf", "7z", "rar", "gzip", "bmp"
	KText, KMarkup, KUnknown                  Kind = "text", "markup", "unknown" // markup — html/svg/xml/js: активное содержимое
)

// Sniff определяет семейство файла по первым байтам (достаточно 512).
func Sniff(head []byte) Kind {
	h := head
	switch {
	case len(h) >= 3 && h[0] == 0xFF && h[1] == 0xD8 && h[2] == 0xFF:
		return KJPEG
	case bytes.HasPrefix(h, []byte("\x89PNG\r\n\x1a\n")):
		return KPNG
	case bytes.HasPrefix(h, []byte("GIF87a")), bytes.HasPrefix(h, []byte("GIF89a")):
		return KGIF
	case IsWebP(h):
		return KWEBP
	case bytes.HasPrefix(h, []byte("%PDF-")):
		return KPDF
	case bytes.HasPrefix(h, []byte("PK\x03\x04")), bytes.HasPrefix(h, []byte("PK\x05\x06")):
		return KZip
	case bytes.HasPrefix(h, []byte{0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1}):
		return KOLE
	case len(h) >= 12 && string(h[4:8]) == "ftyp":
		return KMP4
	case bytes.HasPrefix(h, []byte{0x1A, 0x45, 0xDF, 0xA3}):
		return KWebM
	case bytes.HasPrefix(h, []byte("OggS")):
		return KOgg
	case bytes.HasPrefix(h, []byte("ID3")), len(h) >= 2 && h[0] == 0xFF && (h[1]&0xE0) == 0xE0 && h[1] != 0xFF:
		return KMP3
	case len(h) >= 12 && string(h[:4]) == "RIFF" && string(h[8:12]) == "WAVE":
		return KWAV
	case bytes.HasPrefix(h, []byte("{\\rtf")):
		return KRTF
	case bytes.HasPrefix(h, []byte("7z\xBC\xAF\x27\x1C")):
		return K7z
	case bytes.HasPrefix(h, []byte("Rar!\x1A\x07")):
		return KRar
	case bytes.HasPrefix(h, []byte{0x1F, 0x8B}):
		return KGzip
	case len(h) >= 2 && h[0] == 'B' && h[1] == 'M' && len(h) >= 14:
		return KBMP
	}
	if looksText(h) {
		if looksMarkup(h) {
			return KMarkup
		}
		return KText
	}
	return KUnknown
}

// IsWebP — корректная сигнатура WebP: «RIFF» + размер + «WEBP» + первый чанк VP8 / VP8L / VP8X.
func IsWebP(h []byte) bool {
	if len(h) < 16 || string(h[:4]) != "RIFF" || string(h[8:12]) != "WEBP" {
		return false
	}
	switch string(h[12:16]) {
	case "VP8 ", "VP8L", "VP8X":
		return true
	}
	return false
}

func looksText(h []byte) bool {
	if len(h) == 0 {
		return false
	}
	if bytes.IndexByte(h, 0) >= 0 {
		return false
	}
	b := bytes.TrimPrefix(h, []byte{0xEF, 0xBB, 0xBF})
	// обрезанный в середине символ в конце буфера не должен делать текст «невалидным»
	for i := 0; i < 3 && len(b) > 0 && !utf8.Valid(b); i++ {
		b = b[:len(b)-1]
	}
	if !utf8.Valid(b) {
		return false
	}
	for _, c := range b {
		if c < 0x09 || (c > 0x0D && c < 0x20) {
			return false
		}
	}
	return true
}

func looksMarkup(h []byte) bool {
	s := strings.ToLower(strings.TrimSpace(strings.TrimPrefix(string(h), "\xEF\xBB\xBF")))
	for _, p := range []string{"<!doctype", "<html", "<svg", "<?xml", "<script", "<head", "<body", "<iframe", "<a ", "<img", "<style", "<meta", "<link", "<math", "<object", "<embed"} {
		if strings.HasPrefix(s, p) {
			return true
		}
	}
	return strings.Contains(s, "<script") || strings.Contains(s, "<svg") || strings.Contains(s, "javascript:") || strings.Contains(s, "<iframe")
}

// расширение → MIME для каждого семейства. Расширение НЕ определяет тип: оно лишь уточняет контейнер (zip → docx/xlsx…)
// и проверяется на согласованность с сигнатурой.
var (
	imageByKind = map[Kind]string{KJPEG: "image/jpeg", KPNG: "image/png", KGIF: "image/gif", KWEBP: "image/webp"}
	extImage    = map[string]Kind{".jpg": KJPEG, ".jpeg": KJPEG, ".jpe": KJPEG, ".png": KPNG, ".gif": KGIF, ".webp": KWEBP}

	zipExt = map[string]string{
		".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
		".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
		".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
		".odt":  "application/vnd.oasis.opendocument.text", ".ods": "application/vnd.oasis.opendocument.spreadsheet",
		".odp": "application/vnd.oasis.opendocument.presentation", ".zip": "application/zip",
		".docm": MimeBinary, ".xlsm": MimeBinary, ".pptm": MimeBinary, ".jar": MimeBinary, ".apk": MimeBinary, ".epub": "application/epub+zip",
	}
	oleExt = map[string]string{
		".doc": "application/msword", ".xls": "application/vnd.ms-excel", ".ppt": "application/vnd.ms-powerpoint",
		".msg": "application/vnd.ms-outlook", ".vsd": MimeBinary, ".pub": MimeBinary,
	}
	mp4Ext  = map[string]string{".mp4": "video/mp4", ".m4v": "video/mp4", ".mov": "video/quicktime", ".m4a": "audio/mp4", ".3gp": "video/3gpp"}
	textExt = map[string]string{
		".txt": "text/plain", ".csv": "text/csv", ".tsv": "text/tab-separated-values", ".md": "text/markdown", ".json": "application/json",
		".log": "text/plain", ".ini": "text/plain", ".yml": "text/plain", ".yaml": "text/plain", ".conf": "text/plain", ".sql": "text/plain",
	}
	// активное содержимое: никогда не отдаётся как страница — только как скачиваемый файл
	activeExt = map[string]bool{".html": true, ".htm": true, ".xhtml": true, ".svg": true, ".svgz": true, ".xml": true, ".js": true, ".mjs": true, ".css": true, ".php": true, ".jsp": true, ".asp": true, ".aspx": true, ".swf": true, ".xsl": true, ".xslt": true}
)

func ext(name string) string { return strings.ToLower(filepath.Ext(name)) }

// family — семейство, которое «заявляет» расширение ("" — расширение ничего не заявляет / неизвестно).
func family(e string) string {
	switch {
	case extImage[e] != "":
		return "img:" + string(extImage[e])
	case e == ".pdf":
		return "pdf"
	case zipExt[e] != "":
		return "zip"
	case oleExt[e] != "":
		return "ole"
	case mp4Ext[e] != "":
		return "mp4"
	case textExt[e] != "":
		return "text"
	}
	return ""
}

// ResolveUpload возвращает MIME загружаемого файла, определённый ПО СОДЕРЖИМОМУ, а не по расширению:
//   - тип берётся из сигнатуры; расширение, заявляющее другое семейство (photo.png с PDF/HTML внутри, report.pdf с PNG), → ErrMismatch;
//   - zip/OLE/mp4-контейнеры: расширение лишь уточняет формат (docx, xlsx, mov…) из списка, согласованного с контейнером;
//   - текст: расширение из белого списка даёт text/*, остальное (html, svg, js, xml…) и любая разметка — «только скачать» (application/octet-stream);
//   - содержимое без известной сигнатуры → application/octet-stream (скачивание); тип по расширению не выводится.
func ResolveUpload(head []byte, name string) (string, error) {
	k, e := Sniff(head), ext(name)
	fam := family(e)
	if len(head) == 0 { // пустой файл: допустим только как текст/неизвестный тип
		if fam == "" || fam == "text" {
			if m, ok := textExt[e]; ok {
				return m, nil
			}
			return MimeBinary, nil
		}
		return "", ErrMismatch
	}
	var own string // семейство самого содержимого
	switch k {
	case KJPEG, KPNG, KGIF, KWEBP:
		own = "img:" + string(k)
	case KPDF:
		own = "pdf"
	case KZip:
		own = "zip"
	case KOLE:
		own = "ole"
	case KMP4:
		own = "mp4"
	case KText, KMarkup:
		own = "text"
	}
	if fam != "" && fam != own {
		return "", ErrMismatch
	}
	switch k {
	case KJPEG, KPNG, KGIF, KWEBP:
		return imageByKind[k], nil
	case KPDF:
		return "application/pdf", nil
	case KZip:
		if m, ok := zipExt[e]; ok {
			return m, nil
		}
		return MimeBinary, nil
	case KOLE:
		if m, ok := oleExt[e]; ok {
			return m, nil
		}
		return MimeBinary, nil
	case KMP4:
		if m, ok := mp4Ext[e]; ok {
			return m, nil
		}
		return "video/mp4", nil
	case KWebM:
		if e == ".mkv" {
			return "video/x-matroska", nil
		}
		return "video/webm", nil
	case KOgg:
		return "audio/ogg", nil
	case KMP3:
		return "audio/mpeg", nil
	case KWAV:
		return "audio/wav", nil
	case KRTF:
		return "application/rtf", nil
	case KText:
		if m, ok := textExt[e]; ok {
			return m, nil
		}
		if activeExt[e] {
			return MimeBinary, nil
		}
		return MimeText, nil
	}
	// разметка (html/svg/xml), архивы, bmp и всё без известной сигнатуры — только скачивание
	return MimeBinary, nil
}

// ResolveImage — для мест, где допустимы только JPG/PNG/GIF/WebP (аватары, обложки, публичные картинки).
func ResolveImage(head []byte) (mime, ext string, ok bool) {
	switch Sniff(head) {
	case KJPEG:
		return "image/jpeg", ".jpg", true
	case KPNG:
		return "image/png", ".png", true
	case KGIF:
		return "image/gif", ".gif", true
	case KWEBP:
		return "image/webp", ".webp", true
	}
	return "", "", false
}

// Inline — типы, которые безопасно показывать в браузере (inline); остальное отдаётся как скачивание.
func Inline(mime string) bool {
	switch mime {
	case "image/jpeg", "image/png", "image/gif", "image/webp", "video/mp4", "video/webm", "audio/mpeg", "audio/ogg", "audio/wav", "application/pdf":
		return true
	}
	return false
}
