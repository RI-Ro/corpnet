package secure

import (
	"strings"
	"testing"
)

var (
	jpeg = []byte{0xFF, 0xD8, 0xFF, 0xE0, 0, 0x10, 'J', 'F', 'I', 'F'}
	png  = []byte("\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR")
	gif  = []byte("GIF89a\x01\x00\x01\x00")
	pdf  = []byte("%PDF-1.7\n1 0 obj")
	zip  = []byte("PK\x03\x04\x14\x00\x00\x00")
	html = []byte("<!DOCTYPE html><html><script>alert(1)</script>")
	svg  = []byte("<svg xmlns='http://www.w3.org/2000/svg' onload='alert(1)'></svg>")
)

func webp(chunk string) []byte {
	return append([]byte("RIFF\x24\x00\x00\x00WEBP"), []byte(chunk+"\x00\x00\x00\x00")...)
}

func TestWebPSignature(t *testing.T) {
	for _, c := range []string{"VP8 ", "VP8L", "VP8X"} {
		if !IsWebP(webp(c)) {
			t.Errorf("%q должен быть WebP", c)
		}
	}
	for name, b := range map[string][]byte{
		"неверный чанк": webp("XXXX"), "RIFF/WAVE": []byte("RIFF\x24\x00\x00\x00WAVEfmt \x10\x00"), "короткий": []byte("RIFF\x00\x00\x00\x00WEBP"),
		"RIFF без WEBP": []byte("RIFF\x24\x00\x00\x00AVI LIST\x00\x00"),
	} {
		if IsWebP(b) {
			t.Errorf("%s: не должен считаться WebP", name)
		}
	}
	if m, err := ResolveUpload(webp("VP8X"), "a.webp"); err != nil || m != "image/webp" {
		t.Errorf("webp: %q %v", m, err)
	}
	if _, err := ResolveUpload(webp("XXXX"), "a.webp"); err == nil {
		t.Error("битый webp с расширением .webp должен отклоняться")
	}
}

func TestResolveUpload(t *testing.T) {
	cases := []struct {
		name string
		head []byte
		file string
		want string
		bad  bool
	}{
		{"jpeg", jpeg, "a.JPG", "image/jpeg", false},
		{"png", png, "a.png", "image/png", false},
		{"gif", gif, "a.gif", "image/gif", false},
		{"png без расширения", png, "image", "image/png", false},
		{"png под видом jpg", png, "a.jpg", "", true},
		{"html под видом png", html, "x.png", "", true},
		{"svg под видом jpg", svg, "x.jpg", "", true},
		{"pdf под видом png", pdf, "x.png", "", true},
		{"png под видом pdf", png, "x.pdf", "", true},
		{"pdf", pdf, "doc.pdf", "application/pdf", false},
		{"docx", zip, "a.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", false},
		{"zip с расширением png", zip, "a.png", "", true},
		{"zip", zip, "a.zip", "application/zip", false},
		{"zip с неизвестным расширением", zip, "a.bin", MimeBinary, false},
		{"html — только скачать", html, "page.html", MimeBinary, false},
		{"html как .txt — только скачать", html, "page.txt", MimeBinary, false},
		{"svg — только скачать", svg, "pic.svg", MimeBinary, false},
		{"txt", []byte("привет, мир\nстрока"), "a.txt", "text/plain", false},
		{"csv", []byte("a,b\n1,2\n"), "a.csv", "text/csv", false},
		{"бинарь под .txt", []byte{0, 1, 2, 3, 0xFE}, "a.txt", "", true},
		{"бинарь под .docx", []byte{0, 1, 2, 3, 0xFE}, "a.docx", "", true},
		{"неизвестный бинарь", []byte{0, 1, 2, 3, 0xFE}, "a.dwg", MimeBinary, false},
		{"пустой .txt", nil, "a.txt", "text/plain", false},
		{"пустой .png", nil, "a.png", "", true},
		{"mp4", append([]byte{0, 0, 0, 0x18}, []byte("ftypmp42\x00\x00\x00\x00")...), "v.mp4", "video/mp4", false},
	}
	for _, c := range cases {
		got, err := ResolveUpload(c.head, c.file)
		if c.bad {
			if err == nil {
				t.Errorf("%s: ожидалась ошибка, получили %q", c.name, got)
			}
			continue
		}
		if err != nil || got != c.want {
			t.Errorf("%s: got %q err=%v, want %q", c.name, got, err, c.want)
		}
	}
}

func TestResolveImage(t *testing.T) {
	if m, e, ok := ResolveImage(webp("VP8 ")); !ok || m != "image/webp" || e != ".webp" {
		t.Error("webp")
	}
	if _, _, ok := ResolveImage(html); ok {
		t.Error("html не картинка")
	}
	if _, _, ok := ResolveImage(svg); ok {
		t.Error("svg не принимается как картинка")
	}
}

func TestInline(t *testing.T) {
	if !Inline("image/png") || Inline("text/html") || Inline(MimeBinary) || Inline("image/svg+xml") {
		t.Error("inline-список")
	}
}

func TestCSRFToken(t *testing.T) {
	a, b := NewToken(), NewToken()
	if a == b || len(a) < 32 {
		t.Fatal("токены должны быть случайными и длинными")
	}
	if !ValidToken(a, a) {
		t.Error("одинаковые токены должны проходить")
	}
	for _, c := range [][2]string{{a, b}, {a, ""}, {"", ""}, {"short", "short"}, {a, a + "x"}} {
		if ValidToken(c[0], c[1]) {
			t.Errorf("не должно проходить: %q %q", c[0], c[1])
		}
	}
	if Unsafe("get") || Unsafe("HEAD") || !Unsafe("POST") || !Unsafe("delete") || !Unsafe("PUT") {
		t.Error("Unsafe")
	}
}

func TestSameOrigin(t *testing.T) {
	al := []string{"https://portal.corp.ru/"}
	cases := []struct {
		o, r, h string
		want    bool
	}{
		{"https://intranet:8080", "", "intranet:8080", true},
		{"https://evil.com", "", "intranet:8080", false},
		{"", "https://intranet:8080/news", "intranet:8080", true},
		{"", "https://evil.com/x", "intranet:8080", false},
		{"", "", "intranet:8080", true},
		{"null", "", "intranet:8080", false},
		{"https://portal.corp.ru", "", "intranet:8080", true},
		{"http://portal.corp.ru", "", "intranet:8080", false},
		{"not a url", "", "intranet:8080", false},
	}
	for _, c := range cases {
		if got := SameOrigin(c.o, c.r, c.h, al); got != c.want {
			t.Errorf("origin=%q referer=%q host=%q: got %v", c.o, c.r, c.h, got)
		}
	}
}

func TestCSP(t *testing.T) {
	p := CSP(CSPOptions{})
	for _, must := range []string{"default-src 'self'", "script-src 'self' 'wasm-unsafe-eval'", "object-src 'none'", "frame-ancestors 'self'", "base-uri 'self'"} {
		if !strings.Contains(p, must) {
			t.Errorf("в CSP нет %q: %s", must, p)
		}
	}
	if strings.Contains(p, "script-src 'self' 'unsafe-inline'") || strings.Contains(p, "unsafe-eval'") && !strings.Contains(p, "wasm-unsafe-eval") {
		t.Error("inline/eval-скрипты разрешены")
	}
	x := CSP(CSPOptions{Extra: "img-src 'self' https://cdn.example.com; report-uri /csp"})
	if !strings.Contains(x, "img-src 'self' https://cdn.example.com") || strings.Contains(x, "data: blob:") || !strings.Contains(x, "report-uri /csp") {
		t.Errorf("Extra: %s", x)
	}
	if h := Headers(true); h["Strict-Transport-Security"] == "" || Headers(false)["Strict-Transport-Security"] != "" {
		t.Error("HSTS только для https")
	}
}
