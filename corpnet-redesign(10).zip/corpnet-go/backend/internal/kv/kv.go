// Package kv — небольшое хранилище «ключ–значение» с интерфейсом, совместимым с тем подмножеством Redis,
// которое использует портал: строки, хэши, множества, упорядоченные множества, TTL, счётчики, блокировки (SET NX).
//
// Три реализации:
//   - redis  — настоящий Redis (рекомендуется для нескольких площадок: свой Redis на каждой);
//   - pg     — таблица kv_store (UNLOGGED) в основной БД PostgreSQL: общая для всех процессов экземпляра (prefork) и
//     для нескольких экземпляров, отдельный сервис не нужен;
//   - memory — в памяти процесса (только для разработки и тестов: между процессами не делится).
//
// Команды задаются как обычные команды Redis ("SET", "HINCRBY", …), поэтому в Redis-реализации они уходят как есть.
package kv

import (
	"context"
	"errors"
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"
)

// Nil — «ключа нет» (аналог redis.Nil).
var Nil = errors.New("kv: nil")

// Z — элемент упорядоченного множества.
type Z struct {
	Score  float64
	Member any
}

// ZRangeBy — границы выборки по оценке: "-inf", "+inf", "(5" (исключая), "5".
type ZRangeBy struct {
	Min, Max string
	Offset   int64
	Count    int64
}

// Backend выполняет команды Redis-формата.
type Backend interface {
	// Do выполняет одну команду. Результат: nil (тогда ошибка Nil), string, int64, []any (строки).
	Do(ctx context.Context, args ...any) (any, error)
	// Pipe выполняет несколько команд; ошибка каждой возвращается отдельно.
	Pipe(ctx context.Context, cmds [][]any) ([]any, []error)
	Kind() string // redis | pg | memory
	Close() error
}

// Client — клиент, которым пользуется приложение.
type Client struct {
	cmdable
	b Backend
}

func New(b Backend) *Client {
	c := &Client{b: b}
	c.cmdable.proc = func(ctx context.Context, cmd *baseCmd) {
		cmd.val, cmd.err = c.b.Do(ctx, cmd.args...)
		if cmd.val == nil && cmd.err == nil {
			cmd.err = Nil
		}
	}
	return c
}

func (c *Client) Kind() string { return c.b.Kind() }
func (c *Client) Close() error { return c.b.Close() }

// Backend возвращает реализацию (для доступа к специфике, например Pub/Sub в Redis).
func (c *Client) Backend() Backend { return c.b }

// Pipeline накапливает команды и выполняет их одним обращением.
func (c *Client) Pipeline() *Pipeline {
	p := &Pipeline{c: c}
	p.cmdable.proc = func(ctx context.Context, cmd *baseCmd) { p.cmds = append(p.cmds, cmd) }
	return p
}

type Pipeline struct {
	cmdable
	c    *Client
	cmds []*baseCmd
}

// Exec выполняет накопленные команды. Ошибки отдельных команд смотрите у самих команд; «нет ключа» ошибкой Exec не считается.
func (p *Pipeline) Exec(ctx context.Context) ([]any, error) {
	if len(p.cmds) == 0 {
		return nil, nil
	}
	args := make([][]any, len(p.cmds))
	for i, c := range p.cmds {
		args[i] = c.args
	}
	vals, errs := p.c.b.Pipe(ctx, args)
	var first error
	for i, c := range p.cmds {
		c.val, c.err = vals[i], errs[i]
		if c.val == nil && c.err == nil {
			c.err = Nil
		}
		if c.err != nil && c.err != Nil && first == nil {
			first = c.err
		}
	}
	p.cmds = nil
	return vals, first
}

// ---------------------------------------------------------------- команды

type baseCmd struct {
	args []any
	val  any
	err  error
}

func (c *baseCmd) Err() error { return c.err }

type StringCmd struct{ baseCmd }
type IntCmd struct{ baseCmd }
type BoolCmd struct{ baseCmd }
type StatusCmd struct{ baseCmd }
type StringSliceCmd struct{ baseCmd }
type MapStringStringCmd struct{ baseCmd }

func toStr(v any) string {
	switch x := v.(type) {
	case nil:
		return ""
	case string:
		return x
	case []byte:
		return string(x)
	case int:
		return strconv.Itoa(x)
	case int64:
		return strconv.FormatInt(x, 10)
	case uint64:
		return strconv.FormatUint(x, 10)
	case float64:
		return strconv.FormatFloat(x, 'f', -1, 64)
	case bool:
		if x {
			return "1"
		}
		return "0"
	case time.Duration:
		return strconv.FormatInt(int64(x), 10)
	}
	return fmt.Sprint(v)
}

func toInt(v any) int64 {
	switch x := v.(type) {
	case int64:
		return x
	case int:
		return int64(x)
	case string:
		n, _ := strconv.ParseInt(x, 10, 64)
		return n
	}
	return 0
}

func (c *StringCmd) Result() (string, error) { return toStr(c.val), c.err }
func (c *StringCmd) Val() string             { return toStr(c.val) }
func (c *StringCmd) Bytes() ([]byte, error) {
	if c.err != nil {
		return nil, c.err
	}
	return []byte(toStr(c.val)), nil
}
func (c *StringCmd) Int() (int, error) {
	if c.err != nil {
		return 0, c.err
	}
	return strconv.Atoi(toStr(c.val))
}

func (c *IntCmd) Result() (int64, error) { return toInt(c.val), c.err }
func (c *IntCmd) Val() int64             { return toInt(c.val) }

func (c *BoolCmd) Result() (bool, error) { return c.Val(), c.err }
func (c *BoolCmd) Val() bool {
	switch x := c.val.(type) {
	case int64:
		return x == 1
	case string:
		return x == "OK" || x == "1"
	}
	return false
}

func (c *StatusCmd) Result() (string, error) { return toStr(c.val), c.err }
func (c *StatusCmd) Val() string             { return toStr(c.val) }

func (c *StringSliceCmd) Result() ([]string, error) { return c.Val(), c.err }
func (c *StringSliceCmd) Val() []string {
	l, _ := c.val.([]any)
	out := make([]string, 0, len(l))
	for _, v := range l {
		out = append(out, toStr(v))
	}
	return out
}

func (c *MapStringStringCmd) Result() (map[string]string, error) { return c.Val(), c.err }
func (c *MapStringStringCmd) Val() map[string]string {
	l, _ := c.val.([]any)
	m := make(map[string]string, len(l)/2)
	for i := 0; i+1 < len(l); i += 2 {
		m[toStr(l[i])] = toStr(l[i+1])
	}
	return m
}

// cmdable — набор команд; общий для Client и Pipeline.
type cmdable struct {
	proc func(ctx context.Context, cmd *baseCmd)
}

func ms(d time.Duration) string {
	m := d.Milliseconds()
	if m < 1 {
		m = 1
	}
	return strconv.FormatInt(m, 10)
}

func (c *cmdable) Get(ctx context.Context, key string) *StringCmd {
	cmd := &StringCmd{baseCmd{args: []any{"GET", key}}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) Set(ctx context.Context, key string, value any, ttl time.Duration) *StatusCmd {
	args := []any{"SET", key, toStr(value)}
	if ttl > 0 {
		args = append(args, "PX", ms(ttl))
	}
	cmd := &StatusCmd{baseCmd{args: args}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

// SetNX — «поставить, если ключа нет» (блокировки, дедупликация). Val() == true, если поставили.
func (c *cmdable) SetNX(ctx context.Context, key string, value any, ttl time.Duration) *BoolCmd {
	args := []any{"SET", key, toStr(value), "NX"}
	if ttl > 0 {
		args = append(args, "PX", ms(ttl))
	}
	cmd := &BoolCmd{baseCmd{args: args}}
	c.proc(ctx, &cmd.baseCmd)
	if cmd.err == Nil { // NX не сработал
		cmd.err = nil
		cmd.val = int64(0)
	}
	return cmd
}

func (c *cmdable) Del(ctx context.Context, keys ...string) *IntCmd {
	args := []any{"DEL"}
	for _, k := range keys {
		args = append(args, k)
	}
	cmd := &IntCmd{baseCmd{args: args}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) Expire(ctx context.Context, key string, ttl time.Duration) *BoolCmd {
	cmd := &BoolCmd{baseCmd{args: []any{"PEXPIRE", key, ms(ttl)}}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) Incr(ctx context.Context, key string) *IntCmd {
	cmd := &IntCmd{baseCmd{args: []any{"INCR", key}}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) HSet(ctx context.Context, key string, values ...any) *IntCmd {
	args := []any{"HSET", key}
	for _, v := range values {
		args = append(args, toStr(v))
	}
	cmd := &IntCmd{baseCmd{args: args}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) HGet(ctx context.Context, key, field string) *StringCmd {
	cmd := &StringCmd{baseCmd{args: []any{"HGET", key, field}}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) HGetAll(ctx context.Context, key string) *MapStringStringCmd {
	cmd := &MapStringStringCmd{baseCmd{args: []any{"HGETALL", key}}}
	c.proc(ctx, &cmd.baseCmd)
	if cmd.err == Nil {
		cmd.err = nil
	}
	return cmd
}

func (c *cmdable) HIncrBy(ctx context.Context, key, field string, n int64) *IntCmd {
	cmd := &IntCmd{baseCmd{args: []any{"HINCRBY", key, field, strconv.FormatInt(n, 10)}}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) SAdd(ctx context.Context, key string, members ...any) *IntCmd {
	args := []any{"SADD", key}
	for _, m := range members {
		args = append(args, toStr(m))
	}
	cmd := &IntCmd{baseCmd{args: args}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) SRem(ctx context.Context, key string, members ...any) *IntCmd {
	args := []any{"SREM", key}
	for _, m := range members {
		args = append(args, toStr(m))
	}
	cmd := &IntCmd{baseCmd{args: args}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) SMembers(ctx context.Context, key string) *StringSliceCmd {
	cmd := &StringSliceCmd{baseCmd{args: []any{"SMEMBERS", key}}}
	c.proc(ctx, &cmd.baseCmd)
	if cmd.err == Nil {
		cmd.err = nil
	}
	return cmd
}

func (c *cmdable) ZAdd(ctx context.Context, key string, members ...Z) *IntCmd {
	args := []any{"ZADD", key}
	for _, m := range members {
		args = append(args, strconv.FormatFloat(m.Score, 'f', -1, 64), toStr(m.Member))
	}
	cmd := &IntCmd{baseCmd{args: args}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) ZRem(ctx context.Context, key string, members ...any) *IntCmd {
	args := []any{"ZREM", key}
	for _, m := range members {
		args = append(args, toStr(m))
	}
	cmd := &IntCmd{baseCmd{args: args}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) ZCard(ctx context.Context, key string) *IntCmd {
	cmd := &IntCmd{baseCmd{args: []any{"ZCARD", key}}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) ZRangeByScore(ctx context.Context, key string, opt *ZRangeBy) *StringSliceCmd {
	args := []any{"ZRANGEBYSCORE", key, opt.Min, opt.Max}
	if opt.Count != 0 || opt.Offset != 0 {
		args = append(args, "LIMIT", strconv.FormatInt(opt.Offset, 10), strconv.FormatInt(opt.Count, 10))
	}
	cmd := &StringSliceCmd{baseCmd{args: args}}
	c.proc(ctx, &cmd.baseCmd)
	if cmd.err == Nil {
		cmd.err = nil
	}
	return cmd
}

func (c *cmdable) ZRemRangeByScore(ctx context.Context, key, min, max string) *IntCmd {
	cmd := &IntCmd{baseCmd{args: []any{"ZREMRANGEBYSCORE", key, min, max}}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) RenameNX(ctx context.Context, key, newkey string) *BoolCmd {
	cmd := &BoolCmd{baseCmd{args: []any{"RENAMENX", key, newkey}}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

// PFAdd/PFCount — счётчик уникальных значений (в Redis — HyperLogLog, в pg/memory — точное множество).
func (c *cmdable) PFAdd(ctx context.Context, key string, els ...any) *IntCmd {
	args := []any{"PFADD", key}
	for _, e := range els {
		args = append(args, toStr(e))
	}
	cmd := &IntCmd{baseCmd{args: args}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) PFCount(ctx context.Context, keys ...string) *IntCmd {
	args := []any{"PFCOUNT"}
	for _, k := range keys {
		args = append(args, k)
	}
	cmd := &IntCmd{baseCmd{args: args}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

func (c *cmdable) Ping(ctx context.Context) *StatusCmd {
	cmd := &StatusCmd{baseCmd{args: []any{"PING"}}}
	c.proc(ctx, &cmd.baseCmd)
	return cmd
}

// ---------------------------------------------------------------- общее для реализаций

// parseScore разбирает границу ZRANGEBYSCORE: "-inf", "+inf", "(12.5" (исключая), "12.5".
func parseScore(s string) (v float64, excl bool, err error) {
	s = strings.TrimSpace(s)
	if strings.HasPrefix(s, "(") {
		excl, s = true, s[1:]
	}
	switch strings.ToLower(s) {
	case "-inf":
		return negInf, excl, nil
	case "+inf", "inf":
		return posInf, excl, nil
	}
	v, err = strconv.ParseFloat(s, 64)
	return v, excl, err
}

var (
	posInf = math.Inf(1)
	negInf = math.Inf(-1)
)
