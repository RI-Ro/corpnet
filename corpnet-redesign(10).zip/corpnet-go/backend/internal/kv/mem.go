package kv

import (
	"context"
	"errors"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Memory — хранилище в памяти процесса. Для разработки и тестов: несколько процессов (prefork) его не делят.
type Memory struct {
	mu   sync.Mutex
	data map[string]*entry
	stop chan struct{}
}

type entry struct {
	str  string
	hash map[string]string
	set  map[string]struct{}
	z    map[string]float64
	exp  time.Time // нулевое значение — без срока
}

func (e *entry) dead(now time.Time) bool { return !e.exp.IsZero() && !e.exp.After(now) }

func NewMemory() *Memory {
	m := &Memory{data: map[string]*entry{}, stop: make(chan struct{})}
	go func() {
		t := time.NewTicker(time.Minute)
		defer t.Stop()
		for {
			select {
			case <-t.C:
				m.mu.Lock()
				now := time.Now()
				for k, e := range m.data {
					if e.dead(now) {
						delete(m.data, k)
					}
				}
				m.mu.Unlock()
			case <-m.stop:
				return
			}
		}
	}()
	return m
}

func (m *Memory) Kind() string { return "memory" }
func (m *Memory) Close() error {
	select {
	case <-m.stop:
	default:
		close(m.stop)
	}
	return nil
}

func (m *Memory) Pipe(ctx context.Context, cmds [][]any) ([]any, []error) {
	vals, errs := make([]any, len(cmds)), make([]error, len(cmds))
	for i, c := range cmds {
		vals[i], errs[i] = m.Do(ctx, c...)
	}
	return vals, errs
}

// live возвращает действующую запись (просроченную удаляет). Вызывать под m.mu.
func (m *Memory) live(k string) *entry {
	e := m.data[k]
	if e != nil && e.dead(time.Now()) {
		delete(m.data, k)
		return nil
	}
	return e
}

func (m *Memory) get(k string) *entry {
	e := m.live(k)
	if e == nil {
		e = &entry{}
		m.data[k] = e
	}
	return e
}

func (m *Memory) Do(ctx context.Context, args ...any) (any, error) {
	if len(args) == 0 {
		return nil, errors.New("kv: empty command")
	}
	cmd := strings.ToUpper(toStr(args[0]))
	a := make([]string, len(args)-1)
	for i, v := range args[1:] {
		a[i] = toStr(v)
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	need := func(n int) error {
		if len(a) < n {
			return errors.New("kv: wrong number of arguments for " + cmd)
		}
		return nil
	}
	if cmd == "PING" {
		return "PONG", nil
	}
	if err := need(1); err != nil {
		return nil, err
	}
	k := a[0]
	switch cmd {
	case "GET":
		e := m.live(k)
		if e == nil || e.hash != nil || e.set != nil || e.z != nil {
			return nil, nil
		}
		return e.str, nil
	case "SET":
		if err := need(2); err != nil {
			return nil, err
		}
		var nx bool
		var ttl time.Duration
		for i := 2; i < len(a); i++ {
			switch strings.ToUpper(a[i]) {
			case "NX":
				nx = true
			case "PX":
				i++
				n, _ := strconv.ParseInt(a[i], 10, 64)
				ttl = time.Duration(n) * time.Millisecond
			case "EX":
				i++
				n, _ := strconv.ParseInt(a[i], 10, 64)
				ttl = time.Duration(n) * time.Second
			}
		}
		if nx && m.live(k) != nil {
			return nil, nil
		}
		e := &entry{str: a[1]}
		if ttl > 0 {
			e.exp = time.Now().Add(ttl)
		}
		m.data[k] = e
		return "OK", nil
	case "DEL":
		var n int64
		for _, key := range a {
			if m.live(key) != nil {
				delete(m.data, key)
				n++
			}
		}
		return n, nil
	case "PEXPIRE":
		if err := need(2); err != nil {
			return nil, err
		}
		e := m.live(k)
		if e == nil {
			return int64(0), nil
		}
		n, _ := strconv.ParseInt(a[1], 10, 64)
		e.exp = time.Now().Add(time.Duration(n) * time.Millisecond)
		return int64(1), nil
	case "INCR":
		e := m.get(k)
		n, _ := strconv.ParseInt(e.str, 10, 64)
		n++
		e.str = strconv.FormatInt(n, 10)
		return n, nil
	case "HSET":
		if err := need(3); err != nil {
			return nil, err
		}
		e := m.get(k)
		if e.hash == nil {
			e.hash = map[string]string{}
		}
		var added int64
		for i := 1; i+1 < len(a); i += 2 {
			if _, ok := e.hash[a[i]]; !ok {
				added++
			}
			e.hash[a[i]] = a[i+1]
		}
		return added, nil
	case "HGET":
		if err := need(2); err != nil {
			return nil, err
		}
		if e := m.live(k); e != nil {
			if v, ok := e.hash[a[1]]; ok {
				return v, nil
			}
		}
		return nil, nil
	case "HGETALL":
		out := []any{}
		if e := m.live(k); e != nil {
			keys := make([]string, 0, len(e.hash))
			for f := range e.hash {
				keys = append(keys, f)
			}
			sort.Strings(keys)
			for _, f := range keys {
				out = append(out, f, e.hash[f])
			}
		}
		return out, nil
	case "HINCRBY":
		if err := need(3); err != nil {
			return nil, err
		}
		e := m.get(k)
		if e.hash == nil {
			e.hash = map[string]string{}
		}
		cur, _ := strconv.ParseInt(e.hash[a[1]], 10, 64)
		d, _ := strconv.ParseInt(a[2], 10, 64)
		cur += d
		e.hash[a[1]] = strconv.FormatInt(cur, 10)
		return cur, nil
	case "SADD", "PFADD":
		e := m.get(k)
		if e.set == nil {
			e.set = map[string]struct{}{}
		}
		var added int64
		for _, mem := range a[1:] {
			if _, ok := e.set[mem]; !ok {
				added++
				e.set[mem] = struct{}{}
			}
		}
		return added, nil
	case "SREM":
		var n int64
		if e := m.live(k); e != nil {
			for _, mem := range a[1:] {
				if _, ok := e.set[mem]; ok {
					delete(e.set, mem)
					n++
				}
			}
		}
		return n, nil
	case "SMEMBERS":
		out := []any{}
		if e := m.live(k); e != nil {
			keys := make([]string, 0, len(e.set))
			for f := range e.set {
				keys = append(keys, f)
			}
			sort.Strings(keys)
			for _, f := range keys {
				out = append(out, f)
			}
		}
		return out, nil
	case "PFCOUNT":
		if e := m.live(k); e != nil {
			return int64(len(e.set)), nil
		}
		return int64(0), nil
	case "ZADD":
		e := m.get(k)
		if e.z == nil {
			e.z = map[string]float64{}
		}
		var added int64
		for i := 1; i+1 < len(a); i += 2 {
			sc, _ := strconv.ParseFloat(a[i], 64)
			if _, ok := e.z[a[i+1]]; !ok {
				added++
			}
			e.z[a[i+1]] = sc
		}
		return added, nil
	case "ZREM":
		var n int64
		if e := m.live(k); e != nil {
			for _, mem := range a[1:] {
				if _, ok := e.z[mem]; ok {
					delete(e.z, mem)
					n++
				}
			}
		}
		return n, nil
	case "ZCARD":
		if e := m.live(k); e != nil {
			return int64(len(e.z)), nil
		}
		return int64(0), nil
	case "ZRANGEBYSCORE", "ZREMRANGEBYSCORE":
		if err := need(3); err != nil {
			return nil, err
		}
		lo, loX, err := parseScore(a[1])
		if err != nil {
			return nil, err
		}
		hi, hiX, err := parseScore(a[2])
		if err != nil {
			return nil, err
		}
		type kvp struct {
			m string
			s float64
		}
		var hit []kvp
		if e := m.live(k); e != nil {
			for mem, sc := range e.z {
				if (sc > lo || (!loX && sc == lo)) && (sc < hi || (!hiX && sc == hi)) {
					hit = append(hit, kvp{mem, sc})
				}
			}
		}
		sort.Slice(hit, func(i, j int) bool {
			if hit[i].s != hit[j].s {
				return hit[i].s < hit[j].s
			}
			return hit[i].m < hit[j].m
		})
		if cmd == "ZREMRANGEBYSCORE" {
			e := m.live(k)
			for _, h := range hit {
				delete(e.z, h.m)
			}
			return int64(len(hit)), nil
		}
		off, cnt := 0, -1
		if len(a) >= 6 && strings.EqualFold(a[3], "LIMIT") {
			off, _ = strconv.Atoi(a[4])
			cnt, _ = strconv.Atoi(a[5])
		}
		out := []any{}
		for i, h := range hit {
			if i < off {
				continue
			}
			if cnt >= 0 && len(out) >= cnt {
				break
			}
			out = append(out, h.m)
		}
		return out, nil
	case "RENAMENX":
		if err := need(2); err != nil {
			return nil, err
		}
		e := m.live(k)
		if e == nil {
			return nil, errors.New("ERR no such key")
		}
		if m.live(a[1]) != nil {
			return int64(0), nil
		}
		delete(m.data, k)
		m.data[a[1]] = e
		return int64(1), nil
	}
	return nil, errors.New("kv: unsupported command " + cmd)
}
