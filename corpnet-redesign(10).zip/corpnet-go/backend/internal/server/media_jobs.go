package server

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

// Фоновая конвертация медиа. Фото получают превью (.t.jpg, 320 px) и «просмотр» (.v.jpg, 1728 px) сразу при загрузке
// (images.go); здесь обрабатывается то, что при загрузке не успели или не умеем сами:
//   - старые фото и фото, у которых при загрузке вариант не получился (в т.ч. WebP — через ffmpeg);
//   - видео: постер <имя>.t.jpg и облегчённая web-версия <имя>.v.mp4 (H.264, до 720p, faststart) — браузер начинает
//     воспроизведение сразу и не качает оригинал на 1–2 ГБ.
// Очередь — столбец files.media_state (deploy/db/sql/002_perf_media.sql); FOR UPDATE SKIP LOCKED позволяет запускать
// воркеры на любом числе экземпляров и площадок: файл обрабатывает тот, кто успел взять его первым. Готовые варианты
// затем разъезжаются по площадкам синхронизацией (filesync.go) или подтягиваются по требованию (ensureLocal).

const maxMediaTries = 3

var ffSem = make(chan struct{}, 1) // ffmpeg тяжёлый: на экземпляр — одно кодирование одновременно

func (s *Server) ffmpegPath() string {
	b := strings.TrimSpace(s.cfg.FFmpeg)
	if b == "" || strings.EqualFold(b, "off") {
		return ""
	}
	p, err := exec.LookPath(b)
	if err != nil {
		return ""
	}
	return p
}

func (s *Server) mediaLoop(ctx context.Context) {
	if s.cfg.MediaWorkers <= 0 {
		s.log.Info("media: фоновая конвертация выключена (MEDIA_WORKERS=0)")
		return
	}
	if s.ffmpegPath() == "" {
		s.log.Info("media: ffmpeg не найден — видео и WebP обрабатываться не будут (задайте FFMPEG_BIN)")
	}
	go s.every(ctx, 5*time.Minute, s.mediaRequeue)
	for i := 0; i < s.cfg.MediaWorkers; i++ {
		go func() {
			for ctx.Err() == nil {
				if s.mediaOne(ctx) {
					continue // очередь не пуста — сразу следующий файл
				}
				select {
				case <-ctx.Done():
					return
				case <-time.After(10 * time.Second):
				}
			}
		}()
	}
}

// mediaRequeue возвращает в очередь файлы, «зависшие» в работе (экземпляр перезапустили посреди кодирования).
func (s *Server) mediaRequeue(ctx context.Context) {
	s.db.Exec(ctx, `UPDATE files SET media_state = 0 WHERE media_state = 1 AND media_at < now() - interval '45 minutes'`)
}

type mediaJob struct {
	ID               int64
	Storage, Mime    string
	VideoAvail, Done bool
}

// mediaOne берёт один файл из очереди и обрабатывает его. Возвращает false, если очередь пуста.
func (s *Server) mediaOne(ctx context.Context) bool {
	ff := s.ffmpegPath()
	var j mediaJob
	// без ffmpeg видео из очереди не берём (оно дождётся экземпляра, где ffmpeg есть)
	err := s.db.QueryRow(ctx, `UPDATE files SET media_state = 1, media_at = now(), media_tries = media_tries + 1
		WHERE id = (SELECT id FROM files
		            WHERE media_state = 0 AND storage <> '' AND external_url = ''
		              AND (mime LIKE 'image/%' OR (mime LIKE 'video/%' AND $1))
		            ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED)
		RETURNING id, storage, mime`, ff != "").Scan(&j.ID, &j.Storage, &j.Mime)
	if err != nil {
		return false
	}
	thumb, view, w, h, perr := s.mediaProcess(ctx, ff, j)
	if perr != nil {
		s.log.Warn("media: не удалось обработать файл", "file", j.ID, "err", perr)
		s.db.Exec(ctx, `UPDATE files SET media_state = CASE WHEN media_tries >= $2 THEN 2 ELSE 0 END WHERE id = $1`, j.ID, maxMediaTries)
		return true
	}
	s.db.Exec(ctx, `UPDATE files SET thumb = $2, view = $3, width = CASE WHEN $4 > 0 THEN $4 ELSE width END,
		height = CASE WHEN $5 > 0 THEN $5 ELSE height END, media_state = 3 WHERE id = $1`, j.ID, thumb, view, w, h)
	return true
}

func (s *Server) mediaProcess(ctx context.Context, ffmpeg string, j mediaJob) (thumb, view string, w, h int, err error) {
	if strings.ContainsAny(j.Storage, "/\\") {
		return "", "", 0, 0, fmt.Errorf("недопустимое имя")
	}
	if err = s.ensureLocal(ctx, false, j.Storage); err != nil { // оригинал мог быть загружен на другой площадке
		return
	}
	src := filepath.Join(s.dir(false), j.Storage)
	if _, e := os.Stat(src); e != nil {
		return "", "", 0, 0, e
	}
	if strings.HasPrefix(j.Mime, "image/") {
		if j.Mime != "image/webp" {
			v := makeVariants(src, j.Mime, false)
			if v.Thumb != "" {
				return v.Thumb, v.View, v.W, v.H, nil
			}
		}
		if ffmpeg == "" {
			return "", "", 0, 0, fmt.Errorf("нет декодера (ffmpeg не найден)")
		}
		return s.ffImage(ctx, ffmpeg, src, j.Storage)
	}
	return s.ffVideo(ctx, ffmpeg, src, j.Storage)
}

func (s *Server) ffRun(ctx context.Context, ffmpeg string, args ...string) error {
	select {
	case ffSem <- struct{}{}:
		defer func() { <-ffSem }()
	case <-ctx.Done():
		return ctx.Err()
	}
	cctx, cancel := context.WithTimeout(ctx, s.cfg.FFmpegTimeout)
	defer cancel()
	full := append([]string{"-hide_banner", "-loglevel", "error", "-nostdin", "-y"}, args...)
	var cmd *exec.Cmd
	if nice, err := exec.LookPath("nice"); err == nil { // не мешаем обычным запросам
		cmd = exec.CommandContext(cctx, nice, append([]string{"-n", "19", ffmpeg}, full...)...)
	} else {
		cmd = exec.CommandContext(cctx, ffmpeg, full...)
	}
	if out, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("ffmpeg: %w: %s", err, strings.TrimSpace(cut(string(out), 300)))
	}
	return nil
}

// tmpOut — временный файл рядом с результатом: готовый вариант появляется атомарно (rename), недописанный никто не отдаст.
func tmpOut(dst string) string { return dst + ".part." + randName(3) + filepath.Ext(dst) }

func (s *Server) ffImage(ctx context.Context, ff, src, storage string) (thumb, view string, w, h int, err error) {
	dir := s.dir(false)
	tn := storage + ".t.jpg"
	tmp := tmpOut(filepath.Join(dir, tn))
	if err = s.ffRun(ctx, ff, "-i", src, "-frames:v", "1", "-vf", "scale='min(320,iw)':-2", "-q:v", "5", tmp); err != nil {
		os.Remove(tmp)
		return
	}
	if err = os.Rename(tmp, filepath.Join(dir, tn)); err != nil {
		return
	}
	vn := storage + ".v.jpg"
	vtmp := tmpOut(filepath.Join(dir, vn))
	if e := s.ffRun(ctx, ff, "-i", src, "-frames:v", "1", "-vf", "scale='min(1728,iw)':-2", "-q:v", "3", vtmp); e == nil {
		if os.Rename(vtmp, filepath.Join(dir, vn)) == nil {
			view = vn
		}
	} else {
		os.Remove(vtmp)
	}
	return tn, view, 0, 0, nil
}

func (s *Server) ffVideo(ctx context.Context, ff, src, storage string) (thumb, view string, w, h int, err error) {
	dir := s.dir(false)
	tn := storage + ".t.jpg"
	tmp := tmpOut(filepath.Join(dir, tn))
	// кадр на 1-й секунде; у совсем коротких роликов ffmpeg ничего не пишет — тогда берём первый кадр
	if e := s.ffRun(ctx, ff, "-ss", "1", "-i", src, "-frames:v", "1", "-vf", "scale='min(480,iw)':-2", "-q:v", "5", tmp); e != nil || fileSize(tmp) == 0 {
		os.Remove(tmp)
		if err = s.ffRun(ctx, ff, "-i", src, "-frames:v", "1", "-vf", "scale='min(480,iw)':-2", "-q:v", "5", tmp); err != nil {
			os.Remove(tmp)
			return
		}
	}
	if err = os.Rename(tmp, filepath.Join(dir, tn)); err != nil {
		return
	}
	thumb = tn
	vn := storage + ".v.mp4"
	vtmp := tmpOut(filepath.Join(dir, vn))
	if e := s.ffRun(ctx, ff, "-i", src,
		"-vf", "scale='min(1280,iw)':-2:flags=bicubic,format=yuv420p", "-c:v", "libx264", "-preset", "veryfast", "-crf", "27",
		"-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", vtmp); e != nil {
		os.Remove(vtmp)
		s.log.Warn("media: web-версия видео не создана (остался оригинал)", "storage", storage, "err", e)
		return thumb, "", 0, 0, nil
	}
	// если «лёгкая» версия не меньше оригинала — она бессмысленна
	if fileSize(vtmp) == 0 || fileSize(vtmp) >= fileSize(src)*9/10 {
		os.Remove(vtmp)
		return thumb, "", 0, 0, nil
	}
	if os.Rename(vtmp, filepath.Join(dir, vn)) == nil {
		view = vn
	}
	return thumb, view, 0, 0, nil
}

func fileSize(p string) int64 {
	if st, err := os.Stat(p); err == nil {
		return st.Size()
	}
	return 0
}

// variantMime — тип содержимого варианта по расширению имени (превью/просмотр бывают jpg и mp4).
func variantMime(name string) string {
	if strings.HasSuffix(name, ".mp4") {
		return "video/mp4"
	}
	return "image/jpeg"
}
