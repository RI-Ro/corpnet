package server

import (
	"strconv"
	"strings"
	"time"
)

// График отпусков. Записи принадлежат календарям (vacations_cal.go): в общем календаре руководящего состава вести могут администраторы
// и пользователи с ролью «ведёт график отпусков» (users.can_vacations), в остальных — по правам доступа календаря.

func (c *Ctx) canVacations() bool { return c.U.IsAdmin() || c.U.Vac }

func (s *Server) listVacations(c *Ctx) error {
	from, to := c.Q("from"), c.Q("to")
	if _, err := time.Parse("2006-01-02", from); err != nil {
		from = time.Now().AddDate(0, 0, -30).Format("2006-01-02")
	}
	if _, err := time.Parse("2006-01-02", to); err != nil {
		to = time.Now().AddDate(1, 0, 0).Format("2006-01-02")
	}
	w := &whereBuilder{}
	w.add("v.ends_on >= ?::date AND v.starts_on <= ?::date", from, to)
	// видны только записи доступных пользователю календарей (проверка на сервере, а не в интерфейсе)
	w.add("v.calendar_id IN (SELECT cc.id FROM vac_calendars cc WHERE vac_cal_level(cc.id, ?::bigint, ?::boolean) > 0)", c.U.ID, c.U.IsAdmin())
	if cal := c.QInt64("calendar"); cal > 0 {
		w.add("v.calendar_id = ?", cal)
	}
	if q := strings.ToLower(c.Q("q")); q != "" {
		s.userSearch(c.Context(), w, q)
	}
	if d := c.QInt64("department"); d > 0 {
		w.add("u.department_id IN "+deptSubtree("?"), d)
	}
	b, err := s.arr2(c.Context(), `SELECT v.id, v.calendar_id, v.user_id, u.full_name AS name, u.job_title, u.avatar, d.name AS department,
		to_char(v.starts_on, 'YYYY-MM-DD') AS starts_on, to_char(v.ends_on, 'YYYY-MM-DD') AS ends_on,
		v.deputy_id, du.full_name AS deputy, du.job_title AS deputy_title, v.city, v.note,
		(v.starts_on <= current_date AND v.ends_on >= current_date) AS active_now
		FROM vacations v JOIN users u ON u.id = v.user_id LEFT JOIN departments d ON d.id = u.department_id LEFT JOIN users du ON du.id = v.deputy_id
		WHERE `+w.String()+` ORDER BY v.starts_on, `+userOrder+` LIMIT 1000`, w.args...)
	if err != nil {
		return err
	}
	s.logSearch(c, "vacations", c.Q("q"), anCount(b)) // аналитика поиска
	cals, err := s.vacCalendarsFor(c)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": b, "can_manage": c.canVacations(), "calendars": rawJSON(cals)})
}

func (s *Server) saveVacation(c *Ctx) error {
	var in struct {
		CalendarID int64  `json:"calendar_id"`
		UserID     int64  `json:"user_id"`
		StartsOn   string `json:"starts_on"`
		EndsOn     string `json:"ends_on"`
		DeputyID   *int64 `json:"deputy_id"`
		City       string `json:"city"`
		Note       string `json:"note"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	st, e1 := time.Parse("2006-01-02", in.StartsOn)
	en, e2 := time.Parse("2006-01-02", in.EndsOn)
	if e1 != nil || e2 != nil || en.Before(st) {
		return badReq("Укажите корректные даты начала и окончания отпуска")
	}
	if len([]rune(in.City)) > 100 || len([]rune(in.Note)) > 500 {
		return badReq("Слишком длинный город или примечание")
	}
	ctx := c.Context()
	if in.CalendarID <= 0 { // без календаря — общий график по умолчанию (совместимость со старым клиентом)
		if err := s.db.QueryRow(ctx, `SELECT id FROM vac_calendars WHERE is_default`).Scan(&in.CalendarID); err != nil {
			return err
		}
	}
	lvl, isDef, err := s.vacCalLevel(ctx, c, in.CalendarID)
	if err != nil {
		return err
	}
	if lvl < 2 {
		return &apiError{403, "Вести записи в этом календаре могут только владелец и сотрудники с правом редактирования"}
	}
	var head, blocked bool
	if err := s.db.QueryRow(ctx, `SELECT is_head, blocked FROM users WHERE id = $1`, in.UserID).Scan(&head, &blocked); err != nil {
		return badReq("Сотрудник не найден")
	}
	if isDef && !head {
		return badReq("В общем графике ведётся только руководящий состав (отметка «руководитель подразделения»)")
	}
	if blocked {
		return badReq("Сотрудник заблокирован")
	}
	if in.DeputyID != nil && *in.DeputyID == in.UserID {
		return badReq("Сотрудник не может замещать сам себя")
	}
	var id int64
	if c.R.PathValue("id") != "" {
		if id, err = c.ID("id"); err != nil {
			return err
		}
		// менять можно только запись календаря, где есть право ведения (и переносить — только в такой же)
		var oldCal int64
		if err = s.db.QueryRow(ctx, `SELECT calendar_id FROM vacations WHERE id = $1`, id).Scan(&oldCal); err != nil {
			return err
		}
		if ol, _, e := s.vacCalLevel(ctx, c, oldCal); e != nil {
			return e
		} else if ol < 2 {
			return errForbidden
		}
		_, err = s.db.Exec(ctx, `UPDATE vacations SET calendar_id = $8, user_id = $2, starts_on = $3, ends_on = $4, deputy_id = $5, city = $6, note = $7 WHERE id = $1`,
			id, in.UserID, in.StartsOn, in.EndsOn, in.DeputyID, strings.TrimSpace(in.City), strings.TrimSpace(in.Note), in.CalendarID)
	} else {
		err = s.db.QueryRow(ctx, `INSERT INTO vacations (calendar_id, user_id, starts_on, ends_on, deputy_id, city, note, created_by)
			VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id`,
			in.CalendarID, in.UserID, in.StartsOn, in.EndsOn, in.DeputyID, strings.TrimSpace(in.City), strings.TrimSpace(in.Note), c.U.ID).Scan(&id)
	}
	if err != nil {
		return err
	}
	if in.DeputyID != nil {
		var name string
		s.db.QueryRow(ctx, `SELECT full_name FROM users WHERE id = $1`, in.UserID).Scan(&name)
		s.notify(ctx, []int64{*in.DeputyID}, "vacation", "Вы замещаете: "+name, st.Format("02.01.2006")+" — "+en.Format("02.01.2006"), "/vacations")
	}
	s.audit(c, "vacation.save", "vacation", id, map[string]string{"from": in.StartsOn, "to": in.EndsOn, "user": strconv.FormatInt(in.UserID, 10)})
	return c.JSON(200, map[string]int64{"id": id})
}

func (s *Server) deleteVacation(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var cal int64
	if err := s.db.QueryRow(c.Context(), `SELECT calendar_id FROM vacations WHERE id = $1`, id).Scan(&cal); err != nil {
		return err
	}
	if lvl, _, err := s.vacCalLevel(c.Context(), c, cal); err != nil {
		return err
	} else if lvl < 2 {
		return errForbidden
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM vacations WHERE id = $1`, id); err != nil {
		return err
	}
	return c.OK()
}
