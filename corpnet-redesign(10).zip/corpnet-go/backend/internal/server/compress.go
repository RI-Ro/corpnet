package server

import (
	"compress/gzip"
	"net/http"
	"strings"
	"sync"
)

// gzipAPI сжимает ответы /api/* (JSON) для клиентов, которые это умеют. Статика отдаётся предсжатой (static.go),
// файлы пользователей (/files, /media) не трогаем: они уже сжаты или отдаются с Range. Маленькие ответы
// (меньше gzMin байт) не сжимаются — для них заголовок gzip больше выигрыша.
func (s *Server) gzipAPI(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !strings.HasPrefix(r.URL.Path, "/api/") || strings.HasPrefix(r.URL.Path, "/api/files/") ||
			r.Method == http.MethodHead || r.Header.Get("Upgrade") != "" || r.Header.Get("Range") != "" ||
			!strings.Contains(r.Header.Get("Accept-Encoding"), "gzip") {
			next.ServeHTTP(w, r)
			return
		}
		gw := &gzWriter{ResponseWriter: w}
		defer gw.finish()
		next.ServeHTTP(gw, r)
	})
}

const gzMin = 1024

var gzPool = sync.Pool{New: func() any { z, _ := gzip.NewWriterLevel(nil, gzip.BestSpeed); return z }}

type gzWriter struct {
	http.ResponseWriter
	zw      *gzip.Writer
	buf     []byte // начало тела, пока не ясно, стоит ли сжимать
	code    int    // отложенный код ответа (0 — не задан)
	decided bool
}

func (g *gzWriter) eligible() bool {
	h := g.Header()
	ct := h.Get("Content-Type")
	return g.code != http.StatusNoContent && g.code != http.StatusNotModified && g.code >= 200 && h.Get("Content-Encoding") == "" &&
		(strings.HasPrefix(ct, "application/json") || strings.HasPrefix(ct, "text/"))
}

// decide фиксирует решение: gzip (compress=true) или отдача как есть; отправляет заголовки и накопленное начало тела.
func (g *gzWriter) decide(compress bool) {
	if g.decided {
		return
	}
	g.decided = true
	if compress && g.eligible() {
		h := g.Header()
		h.Add("Vary", "Accept-Encoding")
		h.Del("Content-Length")
		h.Set("Content-Encoding", "gzip")
		g.zw = gzPool.Get().(*gzip.Writer)
		g.zw.Reset(g.ResponseWriter)
	}
	if g.code != 0 {
		g.ResponseWriter.WriteHeader(g.code)
	}
	if len(g.buf) > 0 {
		if g.zw != nil {
			_, _ = g.zw.Write(g.buf)
		} else {
			_, _ = g.ResponseWriter.Write(g.buf)
		}
		g.buf = nil
	}
}

func (g *gzWriter) WriteHeader(code int) {
	if g.decided {
		g.ResponseWriter.WriteHeader(code)
		return
	}
	if g.code == 0 {
		g.code = code
	}
}

func (g *gzWriter) Write(b []byte) (int, error) {
	if !g.decided {
		if g.code == 0 {
			g.code = http.StatusOK
		}
		if !g.eligible() {
			g.decide(false)
		} else {
			g.buf = append(g.buf, b...)
			if len(g.buf) < gzMin {
				return len(b), nil
			}
			g.decide(true)
			return len(b), nil
		}
	}
	if g.zw != nil {
		return g.zw.Write(b)
	}
	return g.ResponseWriter.Write(b)
}

func (g *gzWriter) Flush() {
	g.decide(true) // потоковый ответ (SSE и т.п.) — не копим
	if g.zw != nil {
		_ = g.zw.Flush()
	}
	if f, ok := g.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

// Unwrap нужен http.ResponseController (Hijack, SetWriteDeadline…).
func (g *gzWriter) Unwrap() http.ResponseWriter { return g.ResponseWriter }

func (g *gzWriter) finish() {
	if !g.decided {
		g.decide(false) // короткий ответ: отдаём без сжатия
	}
	if g.zw != nil {
		_ = g.zw.Close()
		g.zw.Reset(nil)
		gzPool.Put(g.zw)
		g.zw = nil
	}
}
