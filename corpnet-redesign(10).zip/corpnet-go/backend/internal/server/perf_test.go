package server

import (
	"compress/gzip"
	"context"
	"encoding/json"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func testServer(t *testing.T) *Server {
	t.Helper()
	dir := t.TempDir()
	os.MkdirAll(filepath.Join(dir, "pub"), 0o755)
	os.MkdirAll(filepath.Join(dir, "prv"), 0o755)
	return &Server{cfg: Config{DataDir: dir, InternalToken: "tok", FileSyncJobs: 2, FileSyncEvery: time.Second, FFmpeg: "ffmpeg", FFmpegTimeout: time.Minute}, log: slog.Default()}
}

func TestGzipAPI(t *testing.T) {
	s := testServer(t)
	body := strings.Repeat(`{"a":"bbbbbbbbbbbbbbbb"},`, 200)
	h := s.gzipAPI(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		io.WriteString(w, body)
	}))
	rq := httptest.NewRequest("GET", "/api/news", nil)
	rq.Header.Set("Accept-Encoding", "gzip")
	rr := httptest.NewRecorder()
	h.ServeHTTP(rr, rq)
	if rr.Header().Get("Content-Encoding") != "gzip" || rr.Code != 200 {
		t.Fatal("ответ не сжат")
	}
	zr, err := gzip.NewReader(rr.Body)
	if err != nil {
		t.Fatal(err)
	}
	got, _ := io.ReadAll(zr)
	if string(got) != body {
		t.Fatal("после распаковки тело отличается")
	}
	if rr.Body.Len() >= len(body) {
		t.Fatal("сжатие не уменьшило размер")
	}
	// короткий ответ не сжимаем; код ответа и заголовки сохраняются
	small := s.gzipAPI(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(201)
		io.WriteString(w, `{"ok":true}`)
	}))
	rq = httptest.NewRequest("POST", "/api/x", nil)
	rq.Header.Set("Accept-Encoding", "gzip")
	rr = httptest.NewRecorder()
	small.ServeHTTP(rr, rq)
	if rr.Code != 201 || rr.Header().Get("Content-Encoding") != "" || rr.Body.String() != `{"ok":true}` {
		t.Fatalf("короткий ответ: code=%d enc=%q body=%q", rr.Code, rr.Header().Get("Content-Encoding"), rr.Body.String())
	}
	// 204 без тела не ломается
	nc := s.gzipAPI(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(204) }))
	rr = httptest.NewRecorder()
	nc.ServeHTTP(rr, rq)
	if rr.Code != 204 {
		t.Fatalf("204: %d", rr.Code)
	}
	// файлы, WebSocket и клиенты без gzip не трогаем
	for _, c := range []struct{ path, ae, up string }{{"/files/1", "gzip", ""}, {"/api/ws", "gzip", "websocket"}, {"/api/news", "", ""}, {"/api/files/1", "gzip", ""}} {
		rq := httptest.NewRequest("GET", c.path, nil)
		rq.Header.Set("Accept-Encoding", c.ae)
		if c.up != "" {
			rq.Header.Set("Upgrade", c.up)
		}
		rr := httptest.NewRecorder()
		h.ServeHTTP(rr, rq)
		if rr.Header().Get("Content-Encoding") != "" {
			t.Fatalf("%s не должен сжиматься", c.path)
		}
	}
}

func TestManifestAndSync(t *testing.T) {
	a, b := testServer(t), testServer(t)
	mux := http.NewServeMux()
	mux.HandleFunc("GET /internal/manifest/{kind}", a.internalManifest)
	mux.HandleFunc("GET /internal/blob/{kind}/{name}", a.internalBlob)
	srv := httptest.NewServer(mux)
	defer srv.Close()
	b.cfg.FilePeers = []string{srv.URL}

	// у A три файла и один недокачанный (его отдавать нельзя)
	for i, n := range []string{"one.jpg", "two.mp4", "three.bin"} {
		p := filepath.Join(a.dir(true), n)
		os.WriteFile(p, []byte(strings.Repeat("x", 100*(i+1))), 0o644)
		ts := time.Now().Add(time.Duration(i-10) * time.Second)
		os.Chtimes(p, ts, ts)
	}
	os.WriteFile(filepath.Join(a.dir(true), "bad.part.1234"), []byte("partial"), 0o644)

	next, n, err := b.syncOnce(context.Background(), srv.URL, "pub", 0)
	if err != nil || n != 3 {
		t.Fatalf("syncOnce: n=%d err=%v", n, err)
	}
	for i, name := range []string{"one.jpg", "two.mp4", "three.bin"} {
		st, err := os.Stat(filepath.Join(b.dir(true), name))
		if err != nil || st.Size() != int64(100*(i+1)) {
			t.Fatalf("файл %s не доехал: %v", name, err)
		}
	}
	if _, err := os.Stat(filepath.Join(b.dir(true), "bad.part.1234")); err == nil {
		t.Fatal("недокачанный файл не должен копироваться")
	}
	if next <= 0 {
		t.Fatal("курсор не сдвинулся")
	}
	// второй круг: ничего нового
	if _, n, _ := b.syncOnce(context.Background(), srv.URL, "pub", next); n != 0 {
		t.Fatalf("повторная загрузка: %d", n)
	}
	// неверный токен
	rq := httptest.NewRequest("GET", "/internal/manifest/pub", nil)
	rr := httptest.NewRecorder()
	a.internalManifest(rr, rq)
	if rr.Code != 403 {
		t.Fatalf("без токена ожидали 403, получили %d", rr.Code)
	}
	var m manifestResp
	rq = httptest.NewRequest("GET", "/internal/manifest/pub?after=0", nil)
	rq.SetPathValue("kind", "pub")
	rq.Header.Set("X-Internal-Token", "tok")
	rr = httptest.NewRecorder()
	a.internalManifest(rr, rq)
	json.Unmarshal(rr.Body.Bytes(), &m)
	if len(m.Items) != 3 {
		t.Fatalf("в манифесте %d файлов, ждали 3", len(m.Items))
	}
}

func TestStaticBrotliAndETag(t *testing.T) {
	dir := t.TempDir()
	os.MkdirAll(filepath.Join(dir, "assets"), 0o755)
	os.WriteFile(filepath.Join(dir, "index.html"), []byte("<html>plain</html>"), 0o644)
	os.WriteFile(filepath.Join(dir, "assets", "app-abc.js"), []byte("console.log(1)"), 0o644)
	os.WriteFile(filepath.Join(dir, "assets", "app-abc.js.br"), []byte("BR-BYTES"), 0o644)
	os.WriteFile(filepath.Join(dir, "assets", "app-abc.js.gz"), []byte("GZ-BYTES"), 0o644)
	st := newStatic(dir)
	get := func(path, ae, inm string) *httptest.ResponseRecorder {
		rq := httptest.NewRequest("GET", path, nil)
		rq.Header.Set("Accept-Encoding", ae)
		if inm != "" {
			rq.Header.Set("If-None-Match", inm)
		}
		rr := httptest.NewRecorder()
		st.serve(rr, rq)
		return rr
	}
	if r := get("/assets/app-abc.js", "gzip, br", ""); r.Header().Get("Content-Encoding") != "br" || r.Body.String() != "BR-BYTES" {
		t.Fatalf("ждали brotli, получили %q %q", r.Header().Get("Content-Encoding"), r.Body.String())
	}
	if r := get("/assets/app-abc.js", "gzip", ""); r.Header().Get("Content-Encoding") != "gzip" {
		t.Fatal("ждали gzip")
	}
	if r := get("/assets/app-abc.js", "", ""); r.Header().Get("Content-Encoding") != "" || r.Body.String() != "console.log(1)" {
		t.Fatal("без сжатия — исходный файл")
	}
	if !strings.Contains(get("/assets/app-abc.js", "br", "").Header().Get("Cache-Control"), "immutable") {
		t.Fatal("assets/* должны быть immutable")
	}
	r := get("/", "", "")
	et := r.Header().Get("ETag")
	if et == "" || r.Header().Get("Cache-Control") != "no-cache" {
		t.Fatalf("index.html: ETag=%q CC=%q", et, r.Header().Get("Cache-Control"))
	}
	if r := get("/", "", et); r.Code != 304 {
		t.Fatalf("ждали 304 по ETag, получили %d", r.Code)
	}
}

func TestFFmpegMedia(t *testing.T) {
	ff, err := exec.LookPath("ffmpeg")
	if err != nil {
		t.Skip("ffmpeg не установлен")
	}
	s := testServer(t)
	dir := s.dir(false)
	// видео 5 с, 1280x720, «тяжёлое» (mpeg4 с высоким битрейтом) → web-версия должна получиться меньше
	src := filepath.Join(dir, "vid.mp4")
	if out, err := exec.Command(ff, "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=size=1920x1080:rate=25:duration=3",
		"-f", "lavfi", "-i", "sine=frequency=440:duration=3", "-c:v", "mpeg4", "-q:v", "1", "-c:a", "aac", "-shortest", "-y", src).CombinedOutput(); err != nil {
		t.Skipf("не удалось создать видео: %v %s", err, out)
	}
	th, vw, _, _, err := s.ffVideo(context.Background(), ff, src, "vid.mp4")
	if err != nil || th != "vid.mp4.t.jpg" {
		t.Fatalf("видео: thumb=%q err=%v", th, err)
	}
	if fileSize(filepath.Join(dir, th)) == 0 {
		t.Fatal("постер пустой")
	}
	if vw != "" && fileSize(filepath.Join(dir, vw)) >= fileSize(src) {
		t.Fatal("web-версия не меньше оригинала")
	}
	t.Logf("оригинал %d Б, web-версия %q %d Б, постер %d Б", fileSize(src), vw, fileSize(filepath.Join(dir, vw)), fileSize(filepath.Join(dir, th)))
	// WebP → превью через ffmpeg
	wp := filepath.Join(dir, "pic.webp")
	if out, err := exec.Command(ff, "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=size=2400x1600", "-frames:v", "1", "-y", wp).CombinedOutput(); err != nil {
		t.Skipf("нет кодировщика webp: %v %s", err, out)
	}
	th, vw, _, _, err = s.ffImage(context.Background(), ff, wp, "pic.webp")
	if err != nil || th == "" || vw == "" {
		t.Fatalf("webp: thumb=%q view=%q err=%v", th, vw, err)
	}
}

func TestVariantMime(t *testing.T) {
	if variantMime("a.v.mp4") != "video/mp4" || variantMime("a.t.jpg") != "image/jpeg" {
		t.Fatal("variantMime")
	}
}

func TestTombstoneBaseNameAndRemoveLocal(t *testing.T) {
	for in, want := range map[string]string{"a.mp4.v.mp4": "a.mp4", "a.jpg.t.jpg": "a.jpg", "a.jpg.v.jpg": "a.jpg", "a.pdf": "a.pdf"} {
		if got := baseName(in); got != want {
			t.Fatalf("baseName(%q)=%q, ждали %q", in, got, want)
		}
	}
	s := testServer(t)
	for _, n := range []string{"x.jpg", "x.jpg.t.jpg", "x.jpg.v.jpg", "keep.jpg"} {
		os.WriteFile(filepath.Join(s.dir(false), n), []byte("1"), 0o644)
	}
	s.removeLocal(false, "x.jpg", "../keep.jpg", ".hidden")
	if s.localExists(false, "x.jpg") || s.localExists(false, "x.jpg.t.jpg") || s.localExists(false, "x.jpg.v.jpg") {
		t.Fatal("файл и варианты должны быть удалены")
	}
	if !s.localExists(false, "keep.jpg") {
		t.Fatal("посторонний файл не должен затрагиваться")
	}
}
