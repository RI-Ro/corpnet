package main

import (
	"crypto/tls"
	"log/slog"
	"net"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"

	"corpnet/internal/server"
)

// certReloader отдаёт сертификат из файлов и перечитывает их при изменении (продление без перезапуска).
type certReloader struct {
	cert, key string
	mu        sync.Mutex
	pair      *tls.Certificate
	mt        time.Time
	checked   time.Time
}

func (c *certReloader) get(*tls.ClientHelloInfo) (*tls.Certificate, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.pair != nil && time.Since(c.checked) < time.Minute {
		return c.pair, nil
	}
	c.checked = time.Now()
	st, err := os.Stat(c.cert)
	if err == nil && c.pair != nil && st.ModTime().Equal(c.mt) {
		return c.pair, nil
	}
	p, err := tls.LoadX509KeyPair(c.cert, c.key)
	if err != nil {
		if c.pair != nil {
			return c.pair, nil // файл на мгновение недоступен — продолжаем со старым
		}
		return nil, err
	}
	c.pair = &p
	if st != nil {
		c.mt = st.ModTime()
	}
	return c.pair, nil
}

// tlsConfig — настройки TLS (HTTP/2 включается через ALPN автоматически). nil, если TLS не настроен.
func tlsConfig(cfg server.Config) (*tls.Config, error) {
	if cfg.TLSCert == "" {
		return nil, nil
	}
	r := &certReloader{cert: cfg.TLSCert, key: cfg.TLSKey}
	if _, err := r.get(nil); err != nil {
		return nil, err
	}
	return &tls.Config{GetCertificate: r.get, MinVersion: tls.VersionTLS12, NextProtos: []string{"h2", "http/1.1"}}, nil
}

// redirectHandler: http → https (308, метод и тело сохраняются). Проверки здоровья остаются доступными по http.
func redirectHandler(httpsAddr string) http.Handler {
	_, port, _ := net.SplitHostPort(httpsAddr)
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/healthz" {
			w.WriteHeader(200)
			_, _ = w.Write([]byte("ok"))
			return
		}
		host := r.Host
		if h, _, err := net.SplitHostPort(host); err == nil {
			host = h
		}
		if strings.Contains(host, ":") && !strings.HasPrefix(host, "[") {
			host = "[" + host + "]"
		}
		if port != "" && port != "443" {
			host += ":" + port
		}
		http.Redirect(w, r, "https://"+host+r.URL.RequestURI(), http.StatusPermanentRedirect)
	})
}

func newHTTPServer(h http.Handler, tc *tls.Config) *http.Server {
	return &http.Server{
		Handler:           h,
		TLSConfig:         tc,
		ReadHeaderTimeout: 10 * time.Second, // без nginx: защита от медленных заголовков (slowloris)
		IdleTimeout:       120 * time.Second,
		// ReadTimeout/WriteTimeout не задаём: загрузка до MAX_UPLOAD_MB, раздача видео и WebSocket живут долго.
	}
}

func logListen(log *slog.Logger, cfg server.Config, tc *tls.Config) {
	scheme := "http"
	if tc != nil {
		scheme = "https"
	}
	log.Info("listening", "addr", cfg.Addr, "scheme", scheme, "instance", cfg.InstanceID, "worker", cfg.WorkerID, "prefork", cfg.Prefork)
}
