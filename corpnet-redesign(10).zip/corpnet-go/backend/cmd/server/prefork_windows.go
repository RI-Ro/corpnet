//go:build windows

package main

import (
	"errors"
	"log/slog"
	"net"
	"os"

	"corpnet/internal/server"
)

func runMaster(cfg server.Config, log *slog.Logger) error {
	return errors.New("PREFORK не поддерживается в Windows: запустите несколько экземпляров на разных портах")
}

func inherited() (main, redirect net.Listener, ready *os.File) { return nil, nil, nil }
