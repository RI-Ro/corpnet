package main

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"log/slog"
	"net"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"

	_ "time/tzdata"

	"corpnet/internal/kv"
	"github.com/jackc/pgx/v5/pgxpool"

	"corpnet/internal/author"
	"corpnet/internal/server"
)

func main() {
	if err := author.Verify(); err != nil { // автор вшивается при сборке (build.sh --author); без него процесс не стартует
		fmt.Fprintln(os.Stderr, "fatal:", err)
		os.Exit(1)
	}
	if len(os.Args) > 1 && (os.Args[1] == "version" || os.Args[1] == "--version") {
		fmt.Println(author.String())
		return
	}
	loadDotEnv(".env") // необязательный файл KEY=VALUE в текущем каталоге; реальные переменные окружения приоритетнее
	cfg := server.LoadConfig()
	if len(os.Args) > 1 && os.Args[1] == "healthcheck" { // used by Docker HEALTHCHECK
		addr := cfg.Addr
		if addr[0] == ':' {
			addr = "127.0.0.1" + addr
		}
		cl := http.Client{Timeout: 3 * time.Second}
		scheme := "http"
		if cfg.TLSCert != "" {
			scheme = "https"
			cl.Transport = &http.Transport{TLSClientConfig: &tls.Config{InsecureSkipVerify: true}} // проверка своего же процесса по localhost
		}
		resp, err := cl.Get(scheme + "://" + addr + "/healthz")
		if err != nil || resp.StatusCode != 200 {
			os.Exit(1)
		}
		return
	}

	log := server.NewLogger(os.Stdout, cfg) // JSON: ts, level, service, instance, dc (+ request_id в запросах)
	slog.SetDefault(log)
	log.Info("starting", "project", author.Project, "author", author.Name())
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	if os.Getenv("CORPNET_WORKER") != "" { // рабочий не переживает мастера (Pdeathsig ненадёжен с потоками Go)
		ppid := os.Getppid()
		go func() {
			for range time.Tick(2 * time.Second) {
				if os.Getppid() != ppid {
					log.Warn("мастер prefork исчез, завершаюсь")
					stop()
					return
				}
			}
		}()
	}

	if cfg.Prefork >= 1 && os.Getenv("CORPNET_WORKER") == "" {
		if err := runMaster(cfg, log); err != nil {
			log.Error("fatal", "err", err)
			os.Exit(1)
		}
		return
	}
	if err := run(ctx, cfg, log); err != nil {
		log.Error("fatal", "err", err)
		os.Exit(1)
	}
}

func run(ctx context.Context, cfg server.Config, log *slog.Logger) error {
	pcfg, err := pgxpool.ParseConfig(cfg.DatabaseURL)
	if err != nil {
		return fmt.Errorf("DATABASE_URL: %w", err)
	}
	pcfg.MaxConns = int32(cfg.PGPoolMax)
	pcfg.ConnConfig.Tracer = server.NewPGTracer("primary", cfg, log)                    // время SQL на запрос, /metrics
	pcfg.ConnConfig.RuntimeParams["application_name"] = "corpnet-app-" + cfg.InstanceID // виден в логах и pg_stat_activity
	pcfg.MinConns = 2
	pcfg.MaxConnLifetime = time.Hour
	pcfg.MaxConnIdleTime = 10 * time.Minute

	var db *pgxpool.Pool
	for i := 0; ; i++ { // wait for Postgres to come up
		db, err = pgxpool.NewWithConfig(ctx, pcfg)
		if err == nil {
			if err = db.Ping(ctx); err == nil {
				break
			}
			db.Close()
		}
		if i >= 60 || ctx.Err() != nil {
			return fmt.Errorf("postgres: %w", err)
		}
		log.Info("waiting for postgres", "err", err)
		time.Sleep(time.Second)
	}
	defer db.Close()

	// Локальная read-реплика (необязательно): тяжёлое чтение — ленты, поиск, списки — идёт на неё.
	var ro *pgxpool.Pool
	if cfg.ReplicaURL != "" {
		rcfg, err := pgxpool.ParseConfig(cfg.ReplicaURL)
		if err != nil {
			return fmt.Errorf("DATABASE_REPLICA_URL: %w", err)
		}
		rcfg.MaxConns = int32(cfg.PGPoolMax)
		rcfg.ConnConfig.Tracer = server.NewPGTracer("replica", cfg, log)
		rcfg.ConnConfig.RuntimeParams["application_name"] = "corpnet-app-ro-" + cfg.InstanceID
		rcfg.MinConns = 1
		rcfg.MaxConnLifetime = time.Hour
		rcfg.MaxConnIdleTime = 10 * time.Minute
		if ro, err = pgxpool.NewWithConfig(ctx, rcfg); err != nil {
			return fmt.Errorf("replica: %w", err)
		}
		defer ro.Close()
		log.Info("read replica enabled")
	}

	kvc, err := openKV(ctx, cfg, db, log)
	if err != nil {
		return err
	}
	defer kvc.Close()
	// Pub/Sub есть только у Redis; без него события между процессами и площадками идут через PostgreSQL (outbox).
	if cfg.Realtime == "auto" || (cfg.Realtime == "redis" && kvc.Kind() != "redis") {
		cfg.Realtime = "pg"
		if kvc.Kind() == "redis" {
			cfg.Realtime = "redis"
		}
	}
	if cfg.SessionStore == "redis" {
		cfg.SessionStore = "kv"
	}
	log.Info("storage", "kv", kvc.Kind(), "realtime", cfg.Realtime, "sessions", cfg.SessionStore)

	srv, err := server.New(cfg, db, ro, kvc, log)
	if err != nil {
		return err
	}
	srv.Run(ctx)

	tc, err := tlsConfig(cfg)
	if err != nil {
		return fmt.Errorf("TLS_CERT/TLS_KEY: %w", err)
	}
	ln, rln, ready := inherited() // в режиме prefork сокеты открыл мастер
	if ln == nil {
		if ln, err = net.Listen("tcp", cfg.Addr); err != nil {
			return err
		}
		if cfg.RedirectAddr != "" {
			if rln, err = net.Listen("tcp", cfg.RedirectAddr); err != nil {
				return fmt.Errorf("HTTP_REDIRECT_ADDR: %w", err)
			}
		}
	}
	hs := newHTTPServer(srv.Handler(), tc)
	errc := make(chan error, 3)
	go func() {
		if tc != nil {
			errc <- hs.ServeTLS(ln, "", "")
		} else {
			errc <- hs.Serve(ln)
		}
	}()
	var extra []*http.Server
	if rln != nil && tc != nil {
		rs := newHTTPServer(redirectHandler(cfg.Addr), nil)
		extra = append(extra, rs)
		go func() { errc <- rs.Serve(rln) }()
	}
	if cfg.MetricsAddr != "" { // отдельный порт наблюдения у каждого процесса (в prefork: порт + номер рабочего)
		addr := cfg.MetricsAddr
		if cfg.Prefork >= 1 {
			if h, p, err := net.SplitHostPort(addr); err == nil {
				if pn, err := strconv.Atoi(p); err == nil {
					addr = net.JoinHostPort(h, strconv.Itoa(pn+cfg.WorkerID))
				}
			}
		}
		ms := newHTTPServer(srv.ObservabilityHandler(), nil)
		ms.Addr = addr
		extra = append(extra, ms)
		go func() {
			if err := ms.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
				log.Warn("metrics listener", "addr", addr, "err", err)
			}
		}()
	}
	logListen(log, cfg, tc)
	if ready != nil {
		_, _ = ready.Write([]byte{1})
		ready.Close()
	}
	select {
	case err := <-errc:
		if !errors.Is(err, http.ErrServerClosed) {
			return err
		}
	case <-ctx.Done():
		sctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		for _, x := range extra {
			_ = x.Shutdown(sctx)
		}
		return hs.Shutdown(sctx)
	}
	return nil
}

// loadDotEnv читает простой .env (KEY=VALUE, # комментарии, значения можно брать в кавычки) и не перезаписывает уже заданные переменные.
func loadDotEnv(file string) {
	b, err := os.ReadFile(file)
	if err != nil {
		return
	}
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(line), "export "))
		if line == "" || line[0] == '#' {
			continue
		}
		k, v, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		k, v = strings.TrimSpace(k), strings.TrimSpace(v)
		if len(v) >= 2 && (v[0] == '"' && v[len(v)-1] == '"' || v[0] == '\'' && v[len(v)-1] == '\'') {
			v = v[1 : len(v)-1]
		} else if i := strings.Index(v, " #"); i >= 0 {
			v = strings.TrimSpace(v[:i])
		}
		if _, set := os.LookupEnv(k); !set && k != "" {
			os.Setenv(k, v)
		}
	}
}

// openKV выбирает хранилище «ключ–значение»: Redis (если задан REDIS_URL), иначе таблица kv_store в PostgreSQL.
func openKV(ctx context.Context, cfg server.Config, db *pgxpool.Pool, log *slog.Logger) (*kv.Client, error) {
	kind := cfg.KVBackend
	if kind == "" || kind == "auto" {
		kind = "pg"
		if cfg.RedisURL != "" {
			kind = "redis"
		}
	}
	switch kind {
	case "memory":
		log.Warn("KV_BACKEND=memory: данные не делятся между процессами; только для разработки")
		return kv.New(kv.NewMemory()), nil
	case "pg":
		b := kv.NewPG(db)
		if err := b.Init(ctx); err != nil {
			return nil, fmt.Errorf("kv_store: %w", err)
		}
		return kv.New(b), nil
	case "redis":
		if cfg.RedisURL == "" {
			return nil, fmt.Errorf("KV_BACKEND=redis требует REDIS_URL")
		}
		r, err := kv.NewRedis(cfg.RedisURL)
		if err != nil {
			return nil, fmt.Errorf("REDIS_URL: %w", err)
		}
		for i := 0; ; i++ {
			if err = r.C.Ping(ctx).Err(); err == nil {
				break
			}
			if i >= 60 || ctx.Err() != nil {
				return nil, fmt.Errorf("redis: %w", err)
			}
			log.Info("waiting for redis", "err", err)
			time.Sleep(time.Second)
		}
		return kv.New(r), nil
	}
	return nil, fmt.Errorf("KV_BACKEND: неизвестное значение %q (auto|redis|pg|memory)", kind)
}
