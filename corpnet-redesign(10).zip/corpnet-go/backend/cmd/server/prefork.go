//go:build !windows

package main

import (
	"fmt"
	"log/slog"
	"net"
	"os"
	"os/exec"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"

	"corpnet/internal/server"
)

// Prefork: мастер открывает порт один раз и запускает N рабочих процессов того же бинарника; все они принимают
// соединения с одного сокета (его делит ядро). Рабочие независимы: у каждого свой пул PostgreSQL, свои
// горутины и своя сборка мусора — отсюда выигрыш на многоядерных машинах и устойчивость (упал один — остальные работают).
//
//	PREFORK=4        — четыре рабочих; PREFORK=auto — по числу ядер; 0 — один процесс без мастера
//	kill -HUP <мастер> — плавный перезапуск по одному (обновление бинарника без потери запросов)
//	kill -TERM <мастер> — корректная остановка всех
//
// Файловые дескрипторы рабочего: 3 — основной сокет, 4 — сокет редиректа http→https (если включён),
// 5 — канал «готов» (рабочий пишет туда байт, когда начал принимать соединения).

const readyFD = 5

type worker struct {
	id    int
	cmd   *exec.Cmd
	ready *os.File // читающий конец канала готовности
	done  chan error
	start time.Time
}

func runMaster(cfg server.Config, log *slog.Logger) error {
	n := cfg.Prefork
	ln, err := net.Listen("tcp", cfg.Addr)
	if err != nil {
		return err
	}
	lf, err := ln.(*net.TCPListener).File()
	if err != nil {
		return err
	}
	var rf *os.File
	if cfg.RedirectAddr != "" {
		rl, err := net.Listen("tcp", cfg.RedirectAddr)
		if err != nil {
			return fmt.Errorf("HTTP_REDIRECT_ADDR: %w", err)
		}
		if rf, err = rl.(*net.TCPListener).File(); err != nil {
			return err
		}
	}
	hasRedirect := "0"
	if rf != nil {
		hasRedirect = "1"
	} else if rf, err = os.Open(os.DevNull); err != nil { // fd 4 должен быть занят: пустые слоты Go-рантайм заполняет своими дескрипторами
		return err
	}
	exe := executablePath()
	base := cfg.InstanceID
	// PG_POOL_MAX в режиме prefork — общий предел на экземпляр: делим между рабочими.
	pool := (cfg.PGPoolMax + n - 1) / n
	if pool < 4 {
		pool = 4
	}
	log.Info("prefork: мастер запущен", "pid", os.Getpid(), "workers", n, "addr", cfg.Addr, "pg_pool_per_worker", pool, "exe", exe)

	spawn := func(id int) (*worker, error) {
		pr, pw, err := os.Pipe()
		if err != nil {
			return nil, err
		}
		cmd := exec.Command(exe, os.Args[1:]...)
		cmd.Stdout, cmd.Stderr = os.Stdout, os.Stderr
		cmd.Env = append(os.Environ(),
			"CORPNET_WORKER="+strconv.Itoa(id),
			"INSTANCE_ID="+base+"-w"+strconv.Itoa(id),
			"PG_POOL_MAX="+strconv.Itoa(pool),
			"PREFORK="+strconv.Itoa(n),
			"CORPNET_REDIRECT="+hasRedirect,
		)
		cmd.ExtraFiles = []*os.File{lf, rf, pw} // fd 3, 4, 5
		if err := cmd.Start(); err != nil {
			pr.Close()
			pw.Close()
			return nil, err
		}
		pw.Close()
		w := &worker{id: id, cmd: cmd, ready: pr, done: make(chan error, 1), start: time.Now()}
		go func() { w.done <- cmd.Wait(); pr.Close() }()
		return w, nil
	}
	waitReady := func(w *worker, d time.Duration) bool {
		ok := make(chan bool, 1)
		go func() { b := make([]byte, 1); k, _ := w.ready.Read(b); ok <- k == 1 }()
		select {
		case v := <-ok:
			return v
		case <-w.done:
			w.done <- nil
			return false
		case <-time.After(d):
			return false
		}
	}

	workers := make([]*worker, n)
	for i := 0; i < n; i++ {
		w, err := spawn(i)
		if err != nil {
			return err
		}
		workers[i] = w
		if i == 0 { // первый поднимаем отдельно: он применяет миграции/инициализацию, остальным не нужно с ним соревноваться
			waitReady(w, 60*time.Second)
		}
	}

	sig := make(chan os.Signal, 4)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM, syscall.SIGHUP)
	type exit struct {
		w   *worker
		err error
	}
	exits := make(chan exit, n*2)
	watch := func(w *worker) {
		go func() { err := <-w.done; exits <- exit{w, err} }()
	}
	for _, w := range workers {
		watch(w)
	}
	backoff := make([]time.Duration, n)
	rolling := false

	stopAll := func() {
		for _, w := range workers {
			if w != nil && w.cmd.Process != nil {
				_ = w.cmd.Process.Signal(syscall.SIGTERM)
			}
		}
		deadline := time.After(25 * time.Second)
		for alive := len(workers); alive > 0; {
			select {
			case <-exits:
				alive--
			case <-deadline:
				for _, w := range workers {
					if w != nil {
						_ = w.cmd.Process.Kill()
					}
				}
				return
			}
		}
	}

	for {
		select {
		case s := <-sig:
			switch s {
			case syscall.SIGHUP:
				if rolling {
					continue
				}
				rolling = true
				log.Info("prefork: плавный перезапуск рабочих")
				go func() {
					for i := 0; i < n; i++ {
						old := workers[i]
						nw, err := spawn(i)
						if err != nil {
							log.Error("prefork: не удалось запустить рабочего", "id", i, "err", err)
							continue
						}
						if !waitReady(nw, 60*time.Second) {
							log.Error("prefork: новый рабочий не стал готовым, оставляю старого", "id", i)
							_ = nw.cmd.Process.Kill()
							continue
						}
						workers[i] = nw
						watch(nw)
						// старого останавливаем «тихо»: его выход не считается аварией
						old.start = time.Time{}
						_ = old.cmd.Process.Signal(syscall.SIGTERM)
					}
					rolling = false
					log.Info("prefork: перезапуск завершён")
				}()
			default:
				log.Info("prefork: остановка", "signal", s.String())
				stopAll()
				return nil
			}
		case e := <-exits:
			if e.w.start.IsZero() { // плановая замена при плавном перезапуске
				continue
			}
			if workers[e.w.id] != e.w {
				continue
			}
			i := e.w.id
			life := time.Since(e.w.start)
			if life > time.Minute {
				backoff[i] = 0
			} else if backoff[i] == 0 {
				backoff[i] = time.Second
			} else if backoff[i] < 30*time.Second {
				backoff[i] *= 2
			}
			log.Error("prefork: рабочий завершился, перезапускаю", "id", i, "err", fmt.Sprint(e.err), "через", backoff[i].String())
			go func(i int, d time.Duration) {
				time.Sleep(d)
				w, err := spawn(i)
				if err != nil {
					log.Error("prefork: перезапуск не удался", "id", i, "err", err)
					exits <- exit{&worker{id: i, start: time.Now()}, err}
					return
				}
				workers[i] = w
				watch(w)
			}(i, backoff[i])
		}
	}
}

// executablePath — путь к бинарнику; после замены файла на диске Linux добавляет " (deleted)" — отрезаем,
// чтобы плавный перезапуск запускал уже новую версию.
func executablePath() string {
	p, err := os.Executable()
	if err != nil {
		return os.Args[0]
	}
	return strings.TrimSuffix(p, " (deleted)")
}

// inherited возвращает сокеты, переданные мастером (рабочий процесс), либо nil.
func inherited() (main, redirect net.Listener, ready *os.File) {
	if os.Getenv("CORPNET_WORKER") == "" {
		return nil, nil, nil
	}
	if f := os.NewFile(3, "listener"); f != nil {
		main, _ = net.FileListener(f)
		f.Close()
	}
	if os.Getenv("CORPNET_REDIRECT") == "1" {
		f := os.NewFile(4, "redirect")
		if l, err := net.FileListener(f); err == nil {
			redirect = l
		}
		f.Close()
	}
	ready = os.NewFile(readyFD, "ready")
	return
}
